---
name: feedback-repowiki-hybrid-format
description: REPOWIKI 必须使用 .qoder/repowiki/ 标准格式，含 wiki_plan.yaml + knowledge 卡片 + zh/content 嵌套内容
metadata:
  type: feedback
---

REPOWIKI 必须使用 Qoder 标准 `.qoder/repowiki/` 目录格式（以下述四层结构为准）。

**目录结构：**
1. `wiki_plan.yaml` — 项目 scope（include/exclude）、template、notes 描述
2. `knowledge/zh/_index.yaml` — 模块索引（dir_name, title, scope, children, depends_on, related_to）
3. `knowledge/zh/[模块名]/` — 每个模块的知识卡片：`_module.yaml` + `概述.md`（一句话）+ `技术栈.md`（一句话）+ `架构设计.md`（1-3段）+ `编码规范.md`（bullet list）+ `特殊配置与命令.md`
4. `zh/content/` — 按功能主题嵌套的内容目录（项目概述、系统架构设计、后端服务、前端应用、数据库设计、API 接口文档、开发指南、部署运维、配置管理等）

**content 文件格式要求：**
- 顶部 `<cite>` 块列出引用文件（`file://` 相对路径）
- `## 目录` 章节
- 详细内容 + mermaid 图表
- 每章节末尾 `**章节来源**` + `**图表来源**` 引用

**Why:** 格式经多次纠正收敛：不要单文件、不要按技术层分，最终以 Qoder 标准 `.qoder/repowiki/` 格式为准；`REPOWIKI.md + wiki/` 平铺格式是错误做法。

**How to apply:** 生成 repowiki 时，永远使用 `.qoder/repowiki/` 路径，按上述四层结构创建文件。不要创建 REPOWIKI.md 或 wiki/ 目录。

## 手写 repowiki 的补充要点（实测）

- **目录锚点按 github-slugger 语义算，别自己发明**：小写 → 去标点（**保留 `_` 与 `-` 和字母数字/CJK**）→ **每个空格替换为 `-`（不折叠连续空格）**；`：`/`（）`/`/` 被删后相邻词**直接相连**（故 `## 症状 B：点了没反应 / 没有报错` → `#症状-b点了没反应--没有报错`，双横线是对的）。上一版校验脚本用 `\s+→-` 且剥掉 `_`，一次性误报 21 处"锚点无对应标题"——**红先归因自己算错**。
- **两个可复用脚本**（改一次两侧同步）：`~/.qoder-cn/scripts/validate-repowiki.js` —— 四层结构合规、`file://` 引用存在性（实测 3168 条 / 3 秒）、目录锚点对齐、代码围栏闭合、疑似截断与占位文字、凭据泄漏扫描（`password:`/`ftp://u:p@`/`ENC(...)`，并白名单化"占位与整改说明"避免误报）、wiki_plan.yaml 的 tab 与"双引号标量内含 ASCII 引号"检查；`~/.qoder-cn/scripts/fix-repowiki-toc.js` —— 按 slug 反查自动改写目录锚点（norm 兜底匹配），改前 `--dry` 预览。知识卡片长度阈值另设（概述/技术栈本就只有 200–400 B，不可套用正文的 800 B 下限）。
- **多写手成文后要做"事实传播扫描"**，而不是只扫引用：`grep` 关键错误说法是否被复用（如把 adapter 的 Boot 2.6.13 写成后端版本、把已注释的 `@Aspect` 说成鉴权生效、把整文件注释的 `DataSourceConfig` 说成生效配置、把只在依赖里的 MyBatis-Plus/easypoi 说成在用）。本轮靠这一步揪出旧骨架页里**真实泄漏的 Jasypt 主口令**并清除。
- **被取代的旧页用隔离而非删除**：`mv` 到 `~/.qoder-cn/_backups/<工程>-repowiki-superseded-<date>/<章节>/<文件>`（本轮 18 个 1–3 KB 的无 `<cite>` 骨架页），汇报里给可恢复路径；重写前先 `tar` 快照整个 repowiki 目录。
- **写手代理常在"自检/复核"阶段撞 maxTurns 而报 failed**：判定完成度要用**差集**（assigned 文件清单 vs 磁盘存在 + 校验通过），不要凭 status=failed 重投整章；本轮 3 个 failed 代理的 31 份文件其实全部落地。
- **子代理报的行数/类数要复验再四处引用**：`wc -l`、`grep -c` 实测与报告一致才写进多页共享的事实（本轮复核 10 个类行数、mapper 44+4/43+4、Controller 46/30、client 45/21 全部吻合）。
- `wiki_plan.yaml` 的 `scope`：官方生成器不解析，但**既有文件里已存在的 scope 不静默删**（保留 + 在文件头注释声明"仅记录范围意图、当前不生效"），新建文件则按前一条经验**不要写** scope。

## 手写 repowiki 的补充要点（另一轮实测）

- **`documents` 是"白名单 = 上限"，不是必选项**：写了它就受硬约束（`≤50 页`、顶级 `≤12`、每顶级 `≤8` 子页、**仅 1 层嵌套**，超出静默截断）。**需要更多页或两级子目录时，正确做法是删掉 `repowiki.documents` 整块**（实测：无白名单的 plan 磁盘 262 页、205 页在三层目录）。删后要补两件事：① 用 notes 写"章节地图"（固定一级章节名单、允许两级子目录、每个目录要有同名索引页、新页必须被本目录索引页提及）；② 让校验脚本切到"无白名单模式"——改为校验章节名单合规 / 索引页存在 / **每页被本目录索引页提到（防孤儿页）**。代价：页级 `goal`/`hints` 随白名单一起消失 ⇒ 加一条 note 声明"结构以磁盘目录树为准、引用以各页 `<cite>` 为准、就地更新不要另起章节"。（曾误记为"只能靠合并成更厚的页解决"，已纠正。）
- notes 仍受 `≤50 条`、单条 `≤10000` 字符；`scope.include/exclude` **当前版本不解析**（写了也无效，别写）。
- **`scope.include/exclude` 当前版本不生效**（解析后忽略并告警）——不要写进文件；`repowiki.template: architecture` 是有效预设。
- **`zh/meta/repowiki-metadata.json` 不要手写**：它是工具生成物，含 `repo_id`/catalog UUID 与 `WikiEncrypted:` 加密 blob，伪造无意义且可能干扰面板。手写文档的权威面是 `wiki_plan.yaml` + `knowledge/` + `zh/content/`；要在 Repo Wiki 面板以"生成态"呈现需跑官方生成器，届时 plan 会成为强先验。
- **知识卡 schema**：`knowledge/zh/_index.yaml` 的模块键须与各 `_module.yaml` 的 `module_path` 一致，`dir_name` 为目录名；独立卡放 `<标题>/<标题>.md` 且 frontmatter 必含 `kind/name/category/scope`（category 取 overview / architecture_design / tech_stack / coding_conventions / unique_setup_and_commands / configuration_system / dependency_management / logging_system / error_handling / build_system / frontend_style / business_term）。
- **写前先落"单一事实源"**：把并行调研的已核验事实浓缩成一份 `_FACTS.md`（含精确路径行号、冲突结论的裁决），再由它派生所有页面——并行写作时给每个写手同一份事实源 + 一份"金标准样页"，可显著降低编造率。
- **收尾必做机器校验**：脚本化检查 plan↔磁盘一致性、`file://` 引用存在性、`#Lx-Ly` 行号越界、内链可达、mermaid 围栏闭合、疑似明文凭据。校验脚本可自行实现（支持 `--only <章节>` 分段自查）；YAML 解析可复用被测工程 `node_modules` 里的 `js-yaml`（本机无可用 python）。
- **改前先备份**：`.qoder/` 通常未被 SVN/git 纳管，重写整个 wiki 目录前先在 `.qoder/` 下做 `repowiki.bak-<date>` 快照（本次经验：既有 wiki 含错误结论与明文口令，重写顺带清污）。

