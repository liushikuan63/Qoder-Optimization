---
name: reference-npm-registry-mirror
description: 本机 npm 源两类问题：全局装包默认源超时（走 npmmirror）；lockfile 的 resolved 指向内网 Nexus 时 npm ci 502/404，replace-registry-host=always 只换主机不够（路径仍带 /repository/itsom_npm/），须整体改写锁内前缀后还原
metadata:
  type: reference
---

本机（企业网）npm 有两类互不相同的源问题，先分清再处置。

## 情况一：全局装包超时（2026-09-22 实测）

- **现象**：`npm install -g` 长时间无输出 / 超时，包迟迟不出现在 `<node 目录>/node_modules`。
- **根因**：默认 registry（registry.npmjs.org）在该网络下不可达或极慢。
- **做法**：显式带镜像源，`npm install -g <包> --registry=https://registry.npmmirror.com --no-audit --no-fund`（实测 34 秒装完 146 包）。
- **边界**：只影响下载源，装完加载路径不变。排查先 `npm config get registry`。

## 情况二：lockfile 的 resolved 指向内网 Nexus（2026-11-26 实测）

- **现象**：`npm ci` 报 `E502 Bad Gateway - GET http://<内网Nexus>/repository/itsom_npm/vue-awesome-swiper/-/vue-awesome-swiper-4.1.1.tgz`，失败后 npm 回滚整个 node_modules。
- **根因**：`npm ci` 按 lockfile 的 `resolved` 直连内网 Nexus；本机 registry 虽是公网，`replace-registry-host` 默认 `npmjs` 只把 registry.npmjs.org 主机替换成配置源，**不会反向改写 lock 里的内网 URL**。
- **做法**：`npm_config_registry=https://registry.npmjs.org npm_config_replace_registry_host=always npm ci --legacy-peer-deps --no-audit --no-fund --ignore-scripts`——`always` 把 lockfile 里任意主机都改写成配置源，同时保留 lock 的确定性版本。先 `curl -sI <公网 tgz>` 验证 tarball 可达（实测 200）。
- **注意**：`lockfileVersion: 1` 会触发 npm 一次 "one-time fix-up"，逐包拉 packument，耗时数分钟，不是卡死。
- **进度判断（2026-11-26 实测）**：安装中 `node_modules` 顶层目录数剧烈波动（1→694→1），不能当进度；以 npm debug log（`_logs/*-debug-0.log`）里的 `http fetch`/`inflate` 行为准。包目录存在≠可用：`vue-template-compiler` 目录已建但 `index.js` 未落盘时 `require` 报 main 缺失，别在安装中途跑校验。
- **`replace-registry-host=always` 不够（2026-11-26 第二次实测，已否证）**：它只替换主机名，**保留 URL 路径**，于是变成 `https://registry.npmjs.org/repository/itsom_npm/vue-awesome-swiper/-/…` → **404**，npm ci 再次整体回滚。凡内网源带私有路径前缀（如 `/repository/itsom_npm/`）时该开关无效。
- **已验证做法（2026-11-26 实测 npm ci EXIT=0，lock 字节还原）**：把 lock 内网前缀整体替换为公网根、`npm ci`、再还原原 lock：
  `node -e "…写 D:/tmp/package-lock.orig.json，replace('http://<内网>:8081/repository/itsom_npm/','https://registry.npmjs.org/')…"` → `npm_config_registry=https://registry.npmjs.org npm ci --legacy-peer-deps --no-audit --no-fund --ignore-scripts` → `cp` 还原 + `cmp -s` 断言一致（HIITSOM_VUEV 实测 6 处内网 URL，LOCK_IDENTICAL）。
- **判定安装真完成**：`node_modules` 目录数波动不可作准；以后台任务退出码 + 关键 bin（如 `node_modules/webpack/bin/webpack.js`）落盘 + 原 lock 已还原三项同时成立。
- **备选（慎用）**：`npm install --package-lock=false` 会完全重新解析依赖，可能拉到 semver 范围内的新版本且更慢，仅在 lock 不可用时使用。
