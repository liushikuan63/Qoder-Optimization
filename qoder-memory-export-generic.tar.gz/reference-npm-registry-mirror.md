---
name: reference-npm-registry-mirror
description: 本机 npm 默认源装全局包会超时；改用 registry.npmmirror.com 镜像可在几十秒内装完（2026-09-22 实测 146 包 / 34 秒）
metadata:
  type: reference
---

在**本机（企业网环境）**执行 `npm install -g <包>` 时，默认源经常慢到超过两分钟甚至无输出（第一次装 `exceljs docx mammoth adm-zip` 就是如此，任务被迫转后台）。

- **现象**：`npm install -g` 长时间无输出 / 超时；包迟迟不出现在 `<node 目录>/node_modules`。
- **根因**：默认 registry（registry.npmjs.org）在本网络下不可达或极慢。
- **正确做法**：显式带镜像源安装，例如 `npm install -g exceljs docx mammoth adm-zip --registry=https://registry.npmmirror.com --no-audit --no-fund`——2026-09-22 实测 **34 秒装完 146 个包**（exceljs 4.4.0 / docx 9.7.1 / mammoth 1.12.3 / adm-zip 0.6.1）。
- **适用边界**：只影响 npm 下载源；装完后包的加载路径与官方源一致（全局包仍在 `<node 安装目录>/node_modules`，脚本用绝对路径 `require` 即可，见 `~/.qoder/scripts/office.js` 的 `load()`）。
- **排查顺序**：先 `npm config get registry` 看当前源，再决定是否显式覆盖；不要因为"超时"就以为包不可用或网络全断。
