---
name: python-real-path
description: 本机 Python 3.14.6 的真实路径与"Python 不可用"误判的成因（python/py 命中 WindowsApps Store 别名）；何时该用完整路径、pip 装库要点
metadata:
  type: reference
---

# 本机 Python：真实路径与误判成因

**结论：Python 往往一直在，只是命令别名指向了坏的 Store 版本，才会被误判成"Python 不可用"。**

## 真实解释器
```
%LOCALAPPDATA%\Programs\Python\Python314\python.exe
```
- Python **3.14.6** / 64bit，pip 26.1.2；三方库目前只有 pip（`openpyxl`/`python-docx`/`pandas` 等都未装）。
- 调用一律用**完整路径**（写脚本时同理），别依赖 `python` / `py`。

## 为什么会误判
- `where python` → `…\WindowsApps\python.exe`（Store 别名）；`where py` → 该目录下的 `Launcher\py.exe`。
- `py.exe -0` 报的默认是 **Store 版 3.13**：`C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.13_…\python3.13.exe`，注册表 `HKLM\SOFTWARE\Python\PythonCore\3.13\InstallPath` 也指向它。
- 该 Store 包在**非交互进程**里启动即失败：`Unable to create process using '"…WindowsApps…python3.13.exe" -c …'`；`py -3.14` 同样报 "No suitable Python runtime found"。
- ⇒ 现象（命令没输出 / 报无法创建进程）**不等于 Python 没装**；`WindowsApps` 别名与 `py` launcher 都不能作为判据，要按目录找真身（`%LOCALAPPDATA%\Programs\Python\Python314\`）。

## 装库
- 需要 `openpyxl` / `python-docx` 等时：
  `"<上面的 python.exe>" -m pip install <包> --index-url https://pypi.tuna.tsinghua.edu.cn/simple`
  （默认 PyPI 在企业网下可能超时；npm 侧同样问题见 `reference-npm-registry-mirror`）
- 装完自验：`<python.exe> -c "import 包; print(包.__version__)"`。

## 现状与边界
- 办公文档**默认走 Node 路线**（`skills/office-docs` + `~/.qoder/scripts/office.js`）：零安装即用，已验证。
- Python 路线留给需要专用库的场景；**未装库前不要假设能 import**。

**Why**：曾据 `python --version` 无输出 + `py` 报错，写下"本机 Python 不可用"的规则与技能结论，被用户一句"其实本机有 Python 你只是没找到正确位置"推翻。
**How to apply**：任何"某工具在本机不可用"的结论，先找真身目录 + 用完整路径实测一次再下；`WindowsApps` 别名、`py` launcher 的报错都不算证据。
