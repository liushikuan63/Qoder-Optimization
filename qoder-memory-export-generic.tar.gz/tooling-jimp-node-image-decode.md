---
name: tooling-jimp-node-image-decode
description: Node 侧解码图片取颜色的可用姿势：jimp 1.6 的 CJS API、探针脚本必须放在技能目录内才找得到 node_modules、process.exit 会跳过 finally
metadata:
  type: reference
---

在纯 Node 环境（不能引 Python）里读像素 / 做主色提取时，`jimp` 1.6.1 实测可用形状（CommonJS）：

```js
const { Jimp, JimpMime } = require('jimp');
const img = await Jimp.fromBuffer(buf);          // 解 png/jpeg/gif/bmp/tiff/webp；async
const { data, width, height } = img.bitmap;      // data 是 RGBA Buffer，长度 = width*height*4
const out = await new Jimp({ data, width, height }).getBuffer(JimpMime.png);   // 反向：自己造测试图
```

- **不是** jimp 0.x 的 `require('jimp')` 直接可调用、也不是 `Jimp.read` 同步版；`new Jimp({data,...})` 要求 data 恰好是 `width*height*4` 的 RGBA。
- 非图片输入抛的 `Error.message` 可能为空串，别拿它当用户提示——自己做文件头魔数预检（PNG/JPEG/GIF/BMP/TIFF/WEBP），报可行动的中文错误。
- 4K 图（3840×2400 ≈ 920 万像素）全量遍历慢，按步长采样到 ≤20 万像素后整链路 2.4 秒。

**Why:** 本机整套规则与分享包刻意只依赖 Node（Python 走完整路径、不进 PATH），图像解码只能靠 npm 纯 JS 包；`npmmirror` 源装 jimp 29 秒（默认源超时，见 [[reference-npm-registry-mirror]]）。

**How to apply:**
1. 临时探针脚本**不要放 `%TEMP%`**：`require('jimp')` 从脚本所在目录往上找 `node_modules`，放在 TEMP 里必然 `MODULE_NOT_FOUND`。要验 API 就把探针落到 `<技能>/scripts/` 或 `<技能>/.probe/` 下（跑完删）。
2. 同理，自测要在临时目录里生成测试图 → 断言取色，比依赖外部真图更可复现；测"色真的写进产物"时，测试图的颜色必须与内置默认值**不同色**，否则 XML 断言会撞默认值变假绿。
3. `process.exit()` **不会执行 `finally`**（也不等异步句柄）——用 try/finally 清理临时文件的探针一旦在 try 里 `process.exit`，垃圾就留在原地（实测在技能 `scripts/` 下留下 `*.mut-probe.js`）。改成先算好退出码、在 `finally` 之后再 exit。
4. 对比度修正的方向判据不能写"文字比背景亮就压暗"：白字配浅灰底时文字本就比背景亮，往白推只会一路走到 1:1 死循环。要按**两端谁对比更高**选方向（`contrast(black,bg) >= contrast(white,bg) ? 往黑 : 往白`）；"底色已定、字要看得见"的成对场景（表头）在中间调是死区，必须改**底纹**明度而不是硬留白字。
