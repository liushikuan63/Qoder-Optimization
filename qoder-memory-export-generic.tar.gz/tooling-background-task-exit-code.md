---
name: tooling-background-task-exit-code
description: 后台任务通知里的 exit code 属于整条复合命令链，不是被判的那个命令——`cmd > log; echo $?; tail` 会让失败也报成 exit 0；判绿必须回读日志里显式记录的退出码
metadata:
  type: reference
---

用 `run_in_background` 跑"构建/测试 + 打印结果"这类复合命令时，**完成通知里的 exit code 是整条命令链最后一条的退出码，不是被判命令的**。

实测踩坑（2026-09-19）：命令写成

```
bash scripts/build.sh > build.log 2>&1; echo "exit=$?"; tail -3 build.log
```

通知报 **exit 0**，而 `build.sh` 其实**编译失败**了——0 来自最后那个 `tail`。差点据此汇报"全绿"。

- **Why:** shell 的退出码只反映最后一条简单命令；`set -e` 也救不了显式的 `;` 串联。
- **How to apply:**
  1. 判绿依据只认**日志里显式记录的那一行**：把退出码写进日志（`cmd > log 2>&1; echo "exit=$?" >> log`），完成后 `grep` 出来看；
  2. 或者干脆只跑单条命令（`cmd > log 2>&1`），让通知的状态码就是它；
  3. 汇报"全绿"前，先确认这个"绿"来自哪个命令的退出码——**通知状态 ≠ 被测命令状态**。

**门禁与"消费动作"必须分成两步（2026-09-20 实测）**：把「构建（自带自检）→ 拷进交付目录 → 打包」写在**同一条** `;` 串联命令里，构建自检失败（exit 1）后命令链照样往下跑，**未经验证的产物就被拷进交付目录并打了包**——门禁成了装饰。做法：① 门禁步骤单独跑并判定 `EXIT=0`；② 通过后才执行拷贝 / 打包；③ 收尾再补一道独立复验（从 zip 解出副本做逐文件哈希比对最佳）。

**2026-10-29 再次复现**：后台命令写成 `node download.cjs > dl.log 2>&1; echo "exit=$?"`，通知报 exit 0，而日志最后一行是 `INCOMPLETE 13/19`、状态文件 `completed=false`——判绿仍只能回读日志与状态文件。

**顺带一条同场景的口径教训**：`check.sh` 这类"全量检查"可能只含静态门、不含编译与测试。宣称"全量通过"前先读脚本确认它到底跑了什么，别把 18 道静态门说成"全套测试"。

**管道版（2026-11-05 实测）**：`node run-tests.js 2>&1 | tail -40` 在后台跑，通知报 **exit 0**，而日志里明确有
`release, suggestion, scan and tiering contracts EXIT=1`——0 来自 `tail`。判据：**读输出里的 `EXIT=` 行**，
不要看通知状态；要拿真实退出码就去掉管道（`cmd > log 2>&1`）或用 `${PIPESTATUS[0]}`。
