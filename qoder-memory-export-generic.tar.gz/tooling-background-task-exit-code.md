---
name: tooling-background-task-exit-code
description: 后台任务通知里的 exit code 属于整条复合命令链，不是被判的那个命令——`cmd > log; echo $?; tail` 会让失败也报成 exit 0；判绿必须回读日志里显式记录的退出码
metadata:
  type: reference
---

用 `run_in_background` 跑"构建/测试 + 打印结果"这类复合命令时，**完成通知里的 exit code 是整条命令链最后一条的退出码，不是被判命令的**。

实测踩坑（2026-09-19）：命令写成

```
bash scripts/build.sh > build.log 2>&1; echo "exit=$?"; tail -3 build.log
```

通知报 **exit 0**，而 `build.sh` 其实**编译失败**了——0 来自最后那个 `tail`。差点据此汇报"全绿"。

- **Why:** shell 的退出码只反映最后一条简单命令；`set -e` 也救不了显式的 `;` 串联。
- **How to apply:**
  1. 判绿依据只认**日志里显式记录的那一行**：把退出码写进日志（`cmd > log 2>&1; echo "exit=$?" >> log`），完成后 `grep` 出来看；
  2. 或者干脆只跑单条命令（`cmd > log 2>&1`），让通知的状态码就是它；
  3. 汇报"全绿"前，先确认这个"绿"来自哪个命令的退出码——**通知状态 ≠ 被测命令状态**。

**门禁与"消费动作"必须分成两步（2026-09-20 实测）**：把「构建（自带自检）→ 拷进交付目录 → 打包」写在**同一条** `;` 串联命令里，构建自检失败（exit 1）后命令链照样往下跑，**未经验证的产物就被拷进交付目录并打了包**——门禁成了装饰。做法：① 门禁步骤单独跑并判定 `EXIT=0`；② 通过后才执行拷贝 / 打包；③ 收尾再补一道独立复验（从 zip 解出副本做逐文件哈希比对最佳）。

**2026-10-29 再次复现**：后台命令写成 `node download.cjs > dl.log 2>&1; echo "exit=$?"`，通知报 exit 0，而日志最后一行是 `INCOMPLETE 13/19`、状态文件 `completed=false`——判绿仍只能回读日志与状态文件。

**顺带一条同场景的口径教训**：`check.sh` 这类"全量检查"可能只含静态门、不含编译与测试。宣称"全量通过"前先读脚本确认它到底跑了什么，别把 18 道静态门说成"全套测试"。

**管道版（2026-11-05 实测）**：`node run-tests.js 2>&1 | tail -40` 在后台跑，通知报 **exit 0**，而日志里明确有
`release, suggestion, scan and tiering contracts EXIT=1`——0 来自 `tail`。判据：**读输出里的 `EXIT=` 行**，
不要看通知状态；要拿真实退出码就去掉管道（`cmd > log 2>&1`）或用 `${PIPESTATUS[0]}`。

**2026-11-09 再次复现 + 自动清理新坑**：后台跑 `node .github/run-tests.js > "D:/tmp/qoder-push-tests.log" 2>&1; echo "TESTS_EXIT=$?"`，通知报 exit 0，任务输出文件里却是 `TESTS_EXIT=1`。

- **长跑后台测试不要结束回合**：`~/.qoder/tmp-sweeper.json` 的 `autoClean.enabled=true` 时，Stop 钩子会按本轮清理 `D:\tmp` 顶层条目——正在写的日志和测试隔离 HOME/TEMP 会一起被删，失败详情丢失，测试还可能因 ENOENT 被干扰。要保留证据：把 `HOME/USERPROFILE/TMP/TEMP/RELEASE_TEST_HOME_PARENT` 指到非 canonical 根（如 `D:/Temp/qoder-cli/...`），日志写到不被清理的目录，收尾再删。
- 判绿仍只认日志/任务输出里显式记录的 `TESTS_EXIT=`／`EXIT=` 行；通知状态可能来自外层 `echo`。

**2026-11-10 复现（新成因＝并行会话按时间窗清理，不是 Stop 钩子）**：后台 `node .github/run-tests.js` 的日志写在 canonical 根 `D:/tmp/qo-014-local-run-tests.log`，任务返回 exit 1 时日志与 `D:/tmp/qo-test-tmp` 夹具目录都已不存在——并行会话清理"它本轮"产物时按时间窗整根删，把本会话正在写的证据一起带走；harness 的任务输出文件只存命令自身 stdout（这里仅 `RUN_TESTS_EXIT=1` 与 tail 的 ENOENT），失败明细永久丢失，只能再花 10+ 分钟重跑。做法升级：① 长跑验证的日志与 TEMP/HOME 夹具落在**本任务独占、不在 canonical 临时根**的目录（本轮改用 `D:/qoder-logs` + `D:/qoder-testtmp-014`）；② 退出码同时 `tee` 成独立 `.exit` 文件，日志被删也能判定"跑过且红"；③ 并行会话共用 `D:/tmp` 时，任何清理只按精确路径 `--only`，不按时间窗。

**后台任务 `completed` 对长跑服务而言＝服务已结束（2026-11-23 实测）**：`run_in_background` 起的 dev server 在约 1.5 小时后才回 `completed (exit code 0)`，任务输出文件只有 16 字节 `DEV_TASK_EXIT=0`——真正的死因写在被重定向的 dev 日志末尾：`Error: listen EADDRINUSE: address already in use :::8082` 后面跟 `Node.js v24.16.0` 崩溃页脚（容易被读成"正常退出"）。根因是并行会话先抢下同端口，我这个 `npm start` 起不来就退出，外层包装照样打 0。

- **How to apply:** 长跑服务类后台任务收到 `completed` 通知时，别当"它一直好好的"，立刻按端口只读复查（`netstat` 取当前监听 PID → `Win32_Process` 的 `CommandLine`/`CreationDate` 判归属）并 grep 重定向日志里的 `EADDRINUSE` / `Error:` / 版本页脚；`npm start` → `cross-env` → `max.js` → `forkedDev.js` 这种多层子进程链，通知状态码与真实服务状态无关。
**2026-11-11 长套件 + 轮次门禁（新坑）**：本机 `node .github/run-tests.js` 超过 10 分钟，`run_in_background` 的任务会在 stop-gate 回合结束时被中断；同一日志被两次复跑覆盖，前一次明细丢失。做法：① 用 `cmd` 包装脚本 + `Start-Process` 启动分离进程，把 `%ERRORLEVEL%` 写到独立 `*.exit`；② 只保留一个实例、一个日志；③ 判定只认 `.exit` 或任务输出文件里的 `EXIT=` 行；④ 定向测试不要接 `| tail`，`$?` 是 tail 的；用 `cmd > log 2>&1; echo EXIT=$?` 再 tail。2026-11-11 实测 `TARGETED_EXIT=0` 就是去掉管道取得的。

**并行分段下载 + cat 合并的静默截断（2026-11-25 实测）**：后台跑 `for i in 0..7; curl -r ... -o parts/part$i & done; wait; cat parts/part*>iso; sha256sum; echo DONE`，通知报 exit 0，但其中 part6 因 `curl: (28) SSL/TLS connection timeout` 失败，`cat` 跳过缺失段生成 7.37GB 的截断 ISO（应为 8.42GB）——0 来自末尾 sha256sum。
- **How to apply:** 分段下载必须：① 每段结束后核对该段字节数（=ceil(total/N) 或 Content-Range 长度）；② 合并后核对总字节==Content-Length；③ `ls parts/` 确认无缺段；④ 失败段单独重下再合并。`completed/exit 0` ≠ 文件完整。
- **补段也要再分段**（2026-11-25 同日实测）：用单个大 range `curl -r <1GB范围>` 补缺失段时速率掉到 13KB/s（同 CDN 其他分片 0.5MB/s），改为把该段再切 8 个子段并行下载再合并才恢复；按连接限速的 CDN，重试无法提速，切段才行。

**2026-11-27 再次复现（同型）**：后台 `node .github/run-tests.js > D:/tmp/qo-0.2.6-tests.log 2>&1; echo "SUITE_EXIT=$?" >> D:/tmp/qo-0.2.6-tests.log` 的通知报 `completed (exit code 0)`，日志末行却是 `SUITE_EXIT=1`——0 来自外层 echo；判绿只认日志里的 `SUITE_EXIT=`/`EXIT=` 行，别信通知状态。
