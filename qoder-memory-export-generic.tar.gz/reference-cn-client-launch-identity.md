---
name: reference-cn-client-launch-identity
description: 从 Agent 会话启动 Qoder CN 会因继承 QODER_* 环境变量而"身份冲突"崩溃；正确做法是用 explorer.exe 以干净用户环境拉起（或让用户点快捷方式）；含 CN 侧 agents 目录 junction 的补齐
metadata:
  type: reference
---

# 启动 CN 客户端：别继承本会话的环境变量

**现象**（2026-10-08 实测）：在 Agent 会话里用 `Start-Process "C:\ProgramData\Qoder CN\Qoder CN Launcher\Qoder CN Launcher.exe"` 启动 CN 版，弹出主进程错误并崩溃：

> A JavaScript error occurred in the main process
> Error: **产物内嵌的产品是 qoder-cn，当前运行身份是 qoder，服务端地址与安装身份不一致。**

**根因**：Agent 会话的 shell 里带着约 20 个 `QODER_*` 环境变量（含 `QODER_PRODUCT_ID`、`QODER_CONFIG_DIR` 等，都是**国际版**身份，见 `env | grep -i qoder`）。`Start-Process` 会把这些**继承**给子进程 → CN 客户端读到国际版身份 → 自身身份校验失败。**不是 CN 安装坏了**（同一台机器手动点快捷方式一直正常）。

**正确做法**：
- 要启动另一个客户端：`explorer.exe "<Launcher.exe 或 .lnk 的完整路径>"` —— 由桌面 shell 拉起，环境是用户正常环境，不含本会话的 `QODER_*`；或直接让用户点快捷方式。
（两件事互为镜像：一个剥掉环境、一个继承环境，都会造成假故障。）
- 崩溃实例要清掉：`Stop-Process -Name 'Qoder CN' -Force`，再重启。
- 判据：进程起来后 `MainWindowTitle` 是 `Qoder CN`（不是 `Error`），且子进程里出现 MCP 服务器（实测能看见 `cua-driver.exe mcp`）。

**排查口径**：任何"产物内嵌身份 + 运行期身份/地址校验"的应用（双客户端壳、多产品安装）都可能被**继承的 env** 带偏；看到错误信息里出现"身份 / 服务端地址不一致"就先查环境变量，而不是怀疑安装包。

**顺带补齐的一处结构差异**：CN 侧原本缺 `agents/`（`rules`/`skills`/`memory`/`scripts` 早已 junction 同源，`commands` 两侧各自实体但内容一致）。已建 `~/.qoder-cn/agents` → `~/.qoder/agents` 的 **junction**（`fs.symlinkSync(target, link, 'junction')`，免管理员；`cmd mklink` 经 MSYS 传参会因引号被改写而失败）。两个全局 agent（`runtime-truth-verifier` / `deploy-verifier`）现在两侧都可见。
