---
name: reference-harness-optimization-patterns
description: 主流 AI 编码 Harness（Claude Code/Cursor/DeepSeek Harness/Manus/Anthropic/SWE-agent）与各工具社区实践（Claude Code/Gemini CLI/Cline/Aider/SDD/多 Agent 编排）及 LangChain/Qoder 官方的上下文工程与优化思路调研结果
metadata:
  type: reference
---

# 主流 AI 编码 Harness 优化思路（2026-09-17 调研）

调研来源：Manus 官方博客、Anthropic 工程博客、SWE-agent ACI 文档、arXiv scaffold 分类论文、Claude Code 官方 steering 博客、Cursor 官方文档、DeepSeek Harness 开源解析文。AGENTS.md「Agent 工程借鉴」章节是这里的可执行子集。

## Claude Code：分层机制各司其职（官方指引）

按"范围与权威级别"选择机制，不混用：
- **CLAUDE.md**：全局上下文——"环境是什么、长期设定"。
- **Rules**：强制约束——必须遵守的纪律。
- **Skills**：流程步骤——某类任务怎么做（按需加载）。
- **Subagents**：隔离复杂/深搜任务，保护主上下文。
- **Hooks**：事件自动化——在特定事件触发确定性动作（不依赖模型自觉）。
- 2026 新增：Hooks 强制触发、Sub-agent 并行、非交互 CI 模式被列为实战三大重点。

## Cursor：Rules 体系与记忆管理

- **Rules 四类型**：Always（始终附加）、Auto-attached（按文件路径模式匹配）、Agent-selected（模型按描述自选）、Manual（@ 手动引用）——与本机 Qoder 的 trigger 四类（always_on / glob / model_decision / manual）一一对应。
- **写法最佳实践**：单份规则 < 500 行、具体可执行、避免冗余；`.cursor/rules`(.mdc) 与 AGENTS.md 并存互认。
- **单一事实源**：AGENTS.md 作为唯一权威，工具特定配置保持薄、引用共享规则——多份副本必然不同步。

## DeepSeek Harness（2026-08 开源）：微内核 + 一切皆插件

- **Cordis 微内核**：连 agent loop 都可替换（对比 Codex 的硬编码循环）；"一切皆插件"——工具、模型、循环全部可换。
- **事件溯源（event sourcing）**：完整记录事件流 → 支持会话重放、上下文精确恢复、策略分叉（同一会话从某点换策略重跑）——竞争对手的会话管理做不到。
- **Model-agnostic**：模型可换，不与单一厂商绑定。
- **对比**：Claude Code 是应用层 hooks 扩展；Codex 是内核级沙箱安全；DeepSeek Harness 是运行时级插件化。
- **启示**：① 过程记录完整可回溯（重放能力）；② 结构可逆优先于静态组合（保持可替换）；③ 不把工作流绑死在单一工具的私有机制上。

## Manus：Context Engineering 六条经验

1. **KV-cache 稳定性**：prompt 前缀保持稳定、只追加不修改；避免时间戳/动态内容；缓存命中与未命中成本差约 10 倍。
2. **工具用 mask 而非移除**：迭代中动态增删工具破坏 KV-cache 且模型会引用已不存在的工具。
3. **文件系统即外部记忆**：长内容写进文件，上下文只留路径引用。
4. **复述（recitation）**：反复重写 todo.md，把目标拉回最近注意力窗口，对抗目标漂移。
5. **保留错误轨迹**：失败尝试留在上下文里——是模型更新信念的证据；擦除会导致重复犯错。
6. **避免 few-shot 陷阱**：上下文过于同质会让模型盲目模仿、漂移；主动增加动作多样性。

## Anthropic：长视野任务的三大技术

- **上下文 = 提示词 + 工具 + 历史**；优化目标是"最小的高信号 token 集合"。
- **Compaction**：接近上限时总结重开；保留架构决策、未解决的 bug、实现细节；工具输出最先丢。
- **Structured note-taking**：关键状态写到上下文外持久文件（NOTES.md / todo），里程碑更新，需要时重读。
- **Sub-agent 架构**：子代理深搜，只回 1-2k token 浓缩摘要，主代理保持干净。

## SWE-agent：ACI（Agent-Computer Interface）设计

- **即时反馈**：编辑后自动跑 linter，语法错误立刻告知。
- **受控文件查看器**：100 行窗口 + 行号 + 剩余行数提示。
- **简洁搜索输出**：只返回匹配项及位置。
- **空输出显式成功**：命令无输出时明确报"执行成功"。
- **可操作错误信息**：指向具体问题与修复方式，不倾倒原始堆栈。

## 主流 Harness 差异速览

- **Claude Code**：终端工程 agent；核心循环「收集上下文 → 行动 → 验证结果」；CLAUDE.md + Hooks + Skills + MCP + Subagents。
- **Codex CLI**：本地终端 agent；沙箱安全；AGENTS.md 分层约定（本机 Qoder 规则体系借鉴此约定）。
- **Cursor**：IDE 嵌入式；Rules + Memories；强视觉交互，弱于复杂终端后台任务。
- **DeepSeek Harness**：开源微内核；可插拔 + 事件溯源 + 会话重放。
- **Scaffold 论文（arXiv 2604.03515）**：主流 agent 收敛于 ReAct 循环 + 字符串替换编辑 + 容器隔离。

## 2026-09-18 补充调研（Qoder 官方 / LangChain / StackOverflow / 阿里云）

- **LangChain Context Engineering 四操作**：Write（落盘笔记/记忆）、Select（只检索相关规则与工具）、Compress（压缩轨迹）、Isolate（子代理隔离）；四反模式：**poisoning**（错误/注入信息混入后续决策）、**distraction**（无关内容挤占窗口）、**confusion**（过时结论未清理）、**clash**（多来源冲突无裁决）。已并入 AGENTS.md「Agent 工程借鉴」。
- **Qoder 官方大库最佳实践**：提示词公式 `清晰目标 + 关键约束 + 具体文件路径 = 高效执行`；硬性限制用 Permissions/Hooks 而非文档；工作模式三分（Plan=影响面大/方向不明、Goal=目标明确、Headless=脚本流水线）；子目录启动 + 分层 AGENTS.md + Worktree 并行。已并入 AGENTS.md「任务处理/文档/规则沉淀/工作方式」。
- **StackOverflow 共享规范经验**：规则要配正误对比示例与 gold standard 文件；AI 不懂的隐性知识必须显式写出；结合 linter/formatter/静态分析兜底；错误驱动迭代。
- **阿里云 AGENTS.md 落地实践**：项目级 AGENTS.md 建议 ≤200 行（地图而非手册，细节外置 docs/ 索引化）；配套工程——自动化架构校验脚本（lint-arch 扫 import 禁止反向跨层引用）、私有组件源码以 git submodule 引入 `reference-projects/` 供 AI 读类型定义、标准化 curl 自测模板（响应落临时文件 + 独立 token 提取脚本）、统一 Makefile 质量入口。
- **Qoder 规则系统硬事实**：活跃规则总量上限 100k 字符；`.qoder/rules` 优先于 AGENTS.md；`AGENTS.local.md` 为本机不入库层；规则只支持纯文本。

## 2026-09-18 社区实践补充（Claude Code / Gemini CLI / Cline 系 / SDD / 多 Agent）

- **Claude Code 创始人 15 条技巧**：`/branch` 分叉会话并行探索、`/btw` 旁路提问不干扰主流程、`-w` Worktree 多 Agent 隔离、`/batch` 扇出大规模变更、`--bare` 跳过加载加速、`--add-dir` 跨仓库读写、`/loop` 循环 / `/schedule` 定时任务、Hooks（SessionStart 等）植入确定性逻辑、Chrome 扩展自动预览验证、`/rc`+`/teleport` 远程控制、手机 App 远程监控审批。**可迁移**：分叉探索（Qoder 对应 `fork_chat_session`）、定时循环任务（对应 `qoder_cron`）、浏览器在环验证（已在验证纪律）。
- **Gemini CLI 社区 10 技巧**：先打开项目文件夹加载正确 GEMINI.md；提示词分步骤并请求确认；先生成计划确认后再改文件；`!` 进 Shell 模式；`/memory add` 加临时上下文；`@search` 联网；自定义 slash 命令；`-p` 非交互单次执行；**Checkpoints 存档点 + `/restore` 回滚**（重大改动前后打点）。
- **Cline / Roo Code / Aider 对比**：Cline 逐动作审批（可审计性优先）；Roo Code 自定义模式 + 多 Agent 工作流；Aider **git-native——每次改动自动提交**（小步原子提交原型）。**可迁移**：小步原子提交 + 重大改动前存档点。
- **SDD 规范驱动开发（Kiro / spec-kit / Tessl，Martin Fowler 分析）**：Kiro = 需求→设计→任务三件套（每任务 3 个 md）；spec-kit = Constitution 约束 + 多文件规格；Tessl = spec-as-source（一规格对一代码文件，生成代码打 `// GENERATED FROM SPEC` 禁改标记）。**风险**：杀鸡用牛刀、评审开销高、AI 可能忽略规格或幻觉。**可迁移**：大功能三件套先行 + 规格锚定验收标准；小改动不套模板。
- **多 Agent 编排社区共识（2026 全景）**：首选 Orchestrator-Subagent 模式；**读任务并行、写任务收敛为单 Agent**；子任务领地不重叠、禁止跨文件并发编辑；审查/调研 Agent 只读；按"信息需求断层"拆上下文而非按工作类型；研究实现分离设人工闸门。**坑**：串行强依赖任务不并行；并行 token 消耗是单线 5–20 倍；警惕反应式无限循环。
- **Codex 社区 AGENTS.md 写作指南**：写边界/命令/测试/安全/审查规则；**不写**格式化 / lint（交给 CI）、密钥、冗长介绍；常见错误：空文件、目录错、超限截断、会话未重启。**可迁移**：lint/CI 能自动管的不重复写进规则。

## 给本环境的映射

AGENTS.md「Agent 工程借鉴」落地的可执行子集：分层机制各司其职、单一事实源 + 薄配置、长任务三件套、复述防漂移、保留失败轨迹、过程可回溯 + 工具可插拔、前缀稳定、工具输出为 AI 设计、短反馈闭环、上下文操作四框架与四反模式。另有：需求公式 + 大功能规格三件套（任务处理）、地图而非手册 + 分层说明（文档）、机制化约束 + 正误示例 + lint 管的不重复写（规则沉淀）、模式选择 + 并行读写纪律 + 分叉探索（工作方式）、小步原子提交 + 存档点（交付）、内置会话/定时能力（工具与能力）。

相关：[[reference-codex-agent-design-lessons]]、[[feedback-use-existing-tools-first]]、[[reference-qoder-global-setup]]
