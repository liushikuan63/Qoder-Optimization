---
name: reference-skills-rules-scaling-evidence
description: 技能/规则/MCP 规模与触发准确率的业界依据（Anthropic Skills 规范、Cursor 规则长度、MCP 工具描述缺陷研究），含出处链接与本机采纳结论
metadata:
  type: reference
---

# 技能 / 规则 / MCP 的规模与触发准确率：可引用的业界依据

2026-09-29 做技能降量与规则复核时联网核到的原始出处（用于回答"为什么不是越多越好"，别再凭印象讲）：

## 一、Anthropic Agent Skills（技能的组织方式）

出处：[Equipping agents for the real world with Agent Skills](https://www.anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills)（Anthropic 工程博客，2025-10-16）：
- **启动时预载每个已装技能的 name + description**（"At startup, the agent pre-loads the name and description of every installed skill into its system prompt"），这叫**第一层渐进式披露**；正文（SKILL.md）只有在技能被选中时才读，附带文件再按需读。
- **描述就是选择依据**："Pay special attention to the name and description of your skill"，因为"Claude will use these when deciding whether to trigger the skill in response to its current task."（→ 描述写不准 = 触发不准，跟技能多寡无关。）
- **拆目录**：SKILL.md 变臃肿就拆成多个文件并引用；**互斥 / 很少一起用的流程分开放**能省 token（"keeping the paths separate will reduce the token usage"）。

配套规范（官方页在本区域被 307 重定向到 `app-unavailable-in-region`，下列要点取自其镜像 [anthropic-agent-skills-best-practices.md](https://raw.githubusercontent.com/ismailkhan313/tech-llm-wiki/main/references/anthropic-agent-skills-best-practices.md)）：
- **SKILL.md 正文 < 500 行**（"Keep SKILL.md body under 500 lines for optimal performance"）。
- 描述要"从可能上百个技能里被挑出来"（"Claude uses it to choose the right Skill from potentially 100+ available Skills"）——**规模上到 100+ 时描述质量就是瓶颈**。

## 二、Cursor Rules（规则的规模与拆分）

出处：[Cursor Docs · Rules](https://cursor.com/docs/rules)：
- **单份规则 < 500 行**（"Keep rules under 500 lines"）。
- **大规则要拆成可组合的多个小规则**（"Split large rules into multiple, composable rules"），而不是并入一份；**引用文件而不是抄内容**（"Reference files instead of copying their contents"）——抄内容会随源文件变化而过期。
- 加载机制：`alwaysApply` 才进每轮上下文，其余按 description（模型判断）/ globs（文件匹配）触发 → **不该每轮都用的东西别设 always**。

## 三、MCP 工具描述（"工具越多越差"的量化证据）

出处：[Model Context Protocol (MCP) Tool Descriptions Are …](https://arxiv.org/html/2602.14878v1)（arXiv，2026-02）：抽样 103 个 MCP server 的 856 个工具：
- **97.1% 的工具描述至少有一种"坏味"**，56% 说不清自己的用途；
- 修好描述能让任务成功率中位数 **+5.85 个百分点**、部分目标完成 **+15.12%**；
- 但描述变丰富也有代价：**16.67% 的用例出现回退**，执行步数 **+67.46%**（→ 描述要"准确"而不是"越长越好"）。

## 四、本机采纳了什么 / 没采纳什么（2026-09-29）

**采纳**：
1. 技能"**同域不装第二个**"——依据一（描述常驻 + 描述决定触发）与依据三（工具/能力面越宽，选择越容易出错）。
2. `rules/*.md` **不合并**、按触发器按需加载——依据二（规则按 description/glob 触发、拆小可组合、别设 always）。
3. **降量前后都要能"可失败地"验证**：停用完跑 `rules-weekly-audit.js --no-fix`（适用性）+ `verify-global-setup.js`（链接/计数），而不是凭感觉。
4. 规则**触发词去重**：同一批关键词只留给更具体的那条规则（本机把"任务拆分 / 批次 / VibeCoding"从 `long-task.md` 摘给 `vibe-coding.md`）——依据一"描述是选择依据"。

**没采纳（附理由）**：
- **不设"技能总数上限"**（比如硬性 N ≤ 30）：三份材料都没给普适阈值（Anthropic 明确只讲"元数据预载 + 描述质量"，不给数量上限），按项目栈选装更合理。
- **不把 SKILL.md 一刀切拆到 500 行以下**：本机多数技能远短于 500 行，只有 `office-docs` 这类"多子命令 + 附属文档"的才需要拆（已拆成 SKILL.md + STYLES.md + CAPABILITIES.md）。
- **不因为"工具描述有坏味"就删 MCP**：三份材料的结论都是"描述要准确"，不是"删工具"；本机三个 MCP 都是按用途逐一核过才留的。

**怎么用**：再有人（或自己）主张"多装点技能/规则更保险"时，先看第一节那句"name + description 会全部预载"与第三节的 97.1% —— 然后按"同域只留一个、描述写准、触发词不重叠"三条动作。
