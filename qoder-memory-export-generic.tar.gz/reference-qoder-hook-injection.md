---
name: reference-qoder-hook-injection
description: Qoder UserPromptSubmit hook 的注入契约（stdin JSON → stdout hookSpecificOutput.additionalContext）、命令串引号陷阱、心跳日志与验证方法
metadata:
  type: reference
---

# Qoder hook 注入契约与踩坑

2026-09-19 为「让规则每轮真正生效」而建（AGENTS.md 太长会被稀释，改为 hook 每轮注入 7 行提醒——6 行纪律 + 1 行 rules 索引；2026-09-19 新增第 6 行「回复必须携带主张词」）。

## 契约（官方 + 实测）

- hook 脚本从 **stdin** 收事件 JSON，把结果写到 **stdout**；退出码语义：`0` 放行、`2` 阻断、其他非零报错但继续。
- 要注入上下文，stdout 必须是这**一个 JSON 对象**（没有别的输出）：

  ```json
  {"hookSpecificOutput":{"hookEventName":"UserPromptSubmit","additionalContext":"<文本>"}}
  ```

- 依据两条：Qoder 安装包自带 `better-harness/references/agent-customize/platforms/qoder.md`（描述 exit code 与"output JSON to stdout"），以及 polarmem0 的 Qoder 集成 `dist/hooks/user-prompt-submit.js` 用的正是这个形状（`emitAdditionalContext`）。
- 配置位置：`settings.json` 顶层 `hooks.UserPromptSubmit` 是**数组**，每个元素形如 `{"hooks":[{"type":"command","command":"...","timeout":10}]}`；额外键（如 `_rulesReminder`）会被容忍。

## 坑 1：命令串里的引号会被 cmd 吃掉（实测踩到）

`"C:/path/node.exe" "C:/path/script.js"` 这种**带引号**写法，在宿主若以朴素 `cmd /c <command>` 执行时，cmd 会剥掉首尾引号 → 报"文件名、目录名或卷标语法不正确"（实测复现）。
**做法**：路径无空格时**不要加引号**，直接 `D:/Java/nodejs/node20.13.0/node.exe ~/.qoder/scripts/rules-reminder.js` —— 实测在 `node exec` / `cmd /c` 原生 / `bash -c` 三种模式下都能跑（带引号版本有三种里的两种会挂）。注意 polarmem0 写的是带引号形式，只是碰巧宿主用的是 Node 的 `/d /s /c` 语义。

## 坑 2：不读 stdin 可能把宿主卡住

宿主往 stdin 写事件 JSON 后，若脚本完全不读且载荷超过管道缓冲区，宿主会阻塞到超时。**做法**：先 `process.stdin.on('data', ()=>{})` 排空，再在 `end`（或 1.5s 兜底定时器）时输出；输出用 `process.stdout.write(payload, cb)` 回调里再收尾，避免 `process.exit()` 截断异步写。

## 观测手段

`scripts/rules-reminder.js` 每次触发追加一行 `ISO 时间戳 ok` 到 `scripts/rules-reminder.log`（超过 64KB 自动裁剪到最近 200 行）。**要确认 hook 真的在跑，看这个日志的 mtime/行数，不要靠"应该生效了"**。

**已观测 / 未观测（2026-09-19 诚实记录）**：截至注册当天，日志里**只有我自己的测试进程**留下的时间戳（三批各 5 条，UTC 06:50 / 06:54 / 06:58），**没有任何一条来自应用会话**——说明配置虽已验证正确，但**注册后旧会话没有重新加载 hooks**。结论只能到这里：契约与执行都没问题，**"应用真的每轮调用它"尚未验证**。判定方法：重启 / 新开一个会话后随便发一句话，再看日志有没有出现新的时间戳（不是测试批次的那三组）。

## 验证方法（都实跑过）

- 解析两侧 `settings.json` → 取出 `UserPromptSubmit` 命令 → `spawnSync(node, [script], {input: 事件JSON})` → 断言退出码 0、stdout 能被 `JSON.parse`、`additionalContext` 含标记文本。
- 三种 shell 模式各跑一遍（见坑 1）。
- 空 stdin 也要能出结果（141–206ms 实测）。
- **注意**：静态配置 + 载荷正确 ≠ 模型真收到了注入。真正"看到"要等下一轮对话，或看心跳日志。

## 原生验收已达成（2026-11-05 实测）

上面那条"静态配置 + 载荷正确 ≠ 模型真收到注入"的缺口已补上。做法与判据：

- **必须新开会话**：已存在的会话不会重新加载 hooks；新建一个只读验收会话，其首轮由 hook 真实注入。
- 判据是**模型能原样报出只在本轮注入里出现的值**：例如 `WORKFLOW_CONTEXT` 的 `decisionId/sessionId/requestDigest` 与 64 位 `WORKFLOW_BINDING`，再用该 binding 调下游校验器；错绑应被拒（`WORKFLOW_SCOPE_MISMATCH`、退出码 2）。
- 取证看子会话 transcript（`read_chat_session`）里的工具调用与结论，不靠"应该生效了"；子会话写验收报告到临时目录，主会话读回。
- 注意：验收 prompt 里"只读/不建 Goal/不派发"会被 hook 解析成 restrictions，模型据此得到 `SEQUENTIAL`/`TASK_LIST`/`NONE`，属预期而非异常。

相关：[[reference-qoder-global-setup]]（规则体系与同步脚本）、[[reference-windows-mcp-stdio-spawn]]（Windows 上 spawn 的同类坑）、[[tooling-node-e-patch-script-quoting]]（heredoc/stdin 传 JSON 的反斜杠折叠）。

## model 模式的显式询问（2026-11-09 恢复）

- 2026-11-05 `f4aa78f` 引入 `--workflow-mode model` 时短路了 `verificationNote`/`goalNoteFor`，并把能力候选降为“仅召回”；用户侧因此长时间看不到验证选档弹窗。route 模式一直有，但现役接线用的是 model。
- 2026-11-09 恢复：`rules-reminder.js` 移除三处 model 短路；model 模式同时运行 `verification-trigger-core.js` 关键词兜底，命中可执行任务仍注入 B05；能力候选恢复 AskUserQuestion；`capability-advisor.cjs` 的 workflow 契约要求业务写入/执行且未 veto 时，开工前用 AskUserQuestion 展示推荐档与四个选项。
- 2026-11-09 追加：并行先生成计划再问 opt-in（未确认按串行）；中大型/跨会话/交接/审查+成文时 Vibecoding 四层/批次文档问一次，小任务不问。模型负责判断相关性，hook 只保证该问时不漏问。
- 排查：提示消失时先看 `rules-reminder.js` 是否又对 `WORKFLOW_MODE` 短路了 `verificationNote`/`goalNoteFor`/`capabilityNote`，再看 settings 的 `--workflow-mode`；model 模式现在也会写 `~/.qoder/tmp/verification-trigger/decisions.log`（关键词兜底），route 模式看同一日志与心跳。
