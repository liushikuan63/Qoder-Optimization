#!/bin/bash
# ============================================================
# Qoder 全局记忆导出脚本
# 用法: bash export-memory.sh [输出目录]
# 功能: 打包可移植的记忆文件，排除含凭据的文件
# ============================================================

set -euo pipefail

MEMORY_DIR="$HOME/.qoder/memory"
OUTPUT_DIR="${1:-.}"
# 规范化路径：去除尾部斜杠，转为绝对路径
OUTPUT_DIR="${OUTPUT_DIR%/}"
case "$OUTPUT_DIR" in
  /*) ;; # 已是绝对路径
  *)  OUTPUT_DIR="$(cd "$OUTPUT_DIR" 2>/dev/null && pwd)" || { echo "错误: 输出目录不存在: $1"; exit 1; } ;;
esac
TIMESTAMP=$(date +%Y%m%d%H%M%S)
ARCHIVE_NAME="qoder-memory-export-${TIMESTAMP}"
STAGING_DIR=$(mktemp -d)

# 含凭据的文件，导出时跳过（示例占位——按你的实际文件名增删）
CREDENTIAL_FILES=(
  "reference-gitlab-credentials.md"
  "reference-server-credentials.md"
  "reference-database-credentials.md"
)

if [ ! -d "$MEMORY_DIR" ]; then
  echo "错误: 记忆目录不存在: $MEMORY_DIR"
  exit 1
fi

echo "=== Qoder 全局记忆导出 ==="
echo "源目录: $MEMORY_DIR"
echo ""

# 创建临时导出目录
EXPORT_DIR="$STAGING_DIR/$ARCHIVE_NAME"
mkdir -p "$EXPORT_DIR"

# 复制可移植文件
COPIED=0
SKIPPED=0
for f in "$MEMORY_DIR"/*.md; do
  filename=$(basename "$f")

  # 跳过凭据文件
  is_credential=false
  for cred in "${CREDENTIAL_FILES[@]}"; do
    if [ "$filename" = "$cred" ]; then
      is_credential=true
      break
    fi
  done

  if $is_credential; then
    echo "  跳过(含凭据): $filename"
    SKIPPED=$((SKIPPED + 1))
    continue
  fi

  cp "$f" "$EXPORT_DIR/"
  COPIED=$((COPIED + 1))
done

# 生成凭据文件模板提示
cat > "$EXPORT_DIR/CREDENTIALS-TEMPLATE.md" << 'TMPL'
# 凭据文件模板

以下文件含敏感信息，需在新机器上手动创建：

- `reference-gitlab-credentials.md` — 平台认证信息（示例）
- `reference-server-credentials.md` — 服务器 SSH 凭据（示例）
- `reference-database-credentials.md` — 数据库连接与账号（示例）

格式参考:
```yaml
---
name: reference-xxx
description: 简短描述
metadata:
  type: reference
---

具体内容...
```
TMPL

# 复制导出/导入脚本（如果存在）
SCRIPTS_DIR="$HOME/.qoder/scripts"
if [ -d "$SCRIPTS_DIR" ]; then
  mkdir -p "$EXPORT_DIR/scripts"
  for s in "$SCRIPTS_DIR"/*.sh "$SCRIPTS_DIR"/*.js; do
    [ -f "$s" ] && cp "$s" "$EXPORT_DIR/scripts/"
  done
fi

# scan_gate：导出物里不得出现凭据形态的内容——"凭据不入分享包"这条纪律的机制兜底。
# 判据 = 逐文件正则扫描，命中即中止导出（exit 1），不给"先导出再手工删"的机会。
# 模式设计成**高精度**：要求"键 + 真值"（值 ≥4 字符且不以引号/斜杠起始）、URL 里 user≥2 且 pass≥3，
# 这样"讲怎么扫凭据"的文档行、以及扫描器自身的模式串都不会误命中（误报会让门禁被无视）。
# 判据的**正负对照**见同目录 export-memory.test.sh（正例必须全中、负例必须全不中），它直接从本文件抽取 SCAN_PATTERN，不会漂移。
# `--exclude` 排除自测文件：它们的 fixture 本来就是伪凭据样本，不排除会让门禁把自己判红（假红会让门禁被无视）。
# 说明：内网地址 / 项目名的扫描在分享包构建脚本 pack-generic-memory.js 里（本脚本导的是个人自用包，允许含内网地址）。
# 注：口令环境变量名在模式里写成 PG[P]ASSWORD（正则等价）——否则分发物里的敏感词扫描会把模式串本身误判成凭据。
SCAN_PATTERN='PG[P]ASSWORD[[:space:]]*[:=][[:space:]]*[^[:space:]"'"'"'`]{4,}|BEGIN [A-Z ]*PRIVATE KEY|(password|passwd|passphrase|pwd)[[:space:]]*[:=][[:space:]]*[^[:space:]"'"'"'`/]{4,}|(jdbc:[a-z]+|mongodb(\+srv)?|redis|postgres(ql)?|amqp|ssh|sftp)://[^[:space:]]{2,}:[^[:space:]/]{3,}@'
SCAN_HITS=$(grep -rInE --exclude='*.test.sh' --exclude='*.test.js' "$SCAN_PATTERN" "$EXPORT_DIR" 2>/dev/null | grep -v 'CREDENTIALS-TEMPLATE.md' || true)
if [ -n "$SCAN_HITS" ]; then
  echo ""
  echo "!! [scan_gate] 发现疑似凭据，导出中止（凭据不入产物）："
  echo "$SCAN_HITS" | sed 's/^/   /'
  echo "   处理：把凭据移到 ~/.qoder/memory/CREDENTIALS-*.md（本脚本已排除该文件）后重跑。"
  rm -rf "$STAGING_DIR"
  exit 1
fi
echo "[scan_gate] ok：导出物未含凭据形态内容"

# 打包
cd "$STAGING_DIR"
tar -czf "$OUTPUT_DIR/${ARCHIVE_NAME}.tar.gz" "$ARCHIVE_NAME"

# 清理临时目录
rm -rf "$STAGING_DIR"

echo ""
echo "=== 导出完成 ==="
echo "已复制: ${COPIED} 个文件"
echo "已跳过: ${SKIPPED} 个凭据文件"
echo "输出文件: $OUTPUT_DIR/${ARCHIVE_NAME}.tar.gz"
echo ""
echo "在新机器上运行:"
echo "  bash import-memory.sh ${ARCHIVE_NAME}.tar.gz"
