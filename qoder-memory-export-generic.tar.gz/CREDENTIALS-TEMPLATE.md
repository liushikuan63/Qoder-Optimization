# 凭据文件模板

以下文件含敏感信息，需在新机器上手动创建：

- `reference-gitlab-credentials.md` — 代码平台认证信息（示例）
- `reference-server-credentials.md` — 服务器 SSH 凭据（示例）
- `reference-database-credentials.md` — 数据库连接与账号（示例）

格式参考:

```yaml
---
name: reference-xxx
description: 简短描述
metadata:
  type: reference
---

具体内容...
```
