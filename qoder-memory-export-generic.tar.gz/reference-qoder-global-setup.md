---
name: reference-qoder-global-setup
description: Qoder 全局配置布局：AGENTS.md/规则/技能/记忆/MCP 的位置约定、规则触发器与 skills CLI 用法
metadata:
  type: reference
---

# Qoder 全局配置布局

**Qoder 与 Qoder CN 两套目录并存、路径不可混用**：非 CN 版 `~/.qoder/`；CN 版 `~/.qoder-cn/`。

## 全局规则（用户级，对所有项目生效）

- **主规则（always 加载）**：`~/.qoder/AGENTS.md`——语言 / 验证 / 交付 / 文档 / 任务处理 / Agent 工程借鉴 / 工具选用 / 记忆 / 规则沉淀 / 工具 / 工作方式。
- **子规则（按触发器加载）**：`~/.qoder/rules/*.md`，frontmatter 支持四种触发器：
  - `trigger: always_on`（默认）
  - `trigger: glob` + `glob: [...]`——命中文件类型时加载
  - `trigger: model_decision` + `description`——模型按描述判断
  - `trigger: manual`——仅显式要求时
- 项目级：`<project>/AGENTS.md` 或 `<project>/AGENTS.local.md`（local 版不提交 Git，仅本机生效）或 `<project>/.qoder/rules/*.md`；冲突时规则内容优先于 AGENTS.md；`@path/to/file` 可导入其他文件。
- **硬事实**（Qoder 官方文档）：活跃规则总字符上限 **100,000**，超出截断；规则只支持自然语言文本（不支持图片/链接）；硬性阻止类需求靠权限（Permissions）/钩子（Hooks），不靠文档约束。
- **CLI 命令**：`/init` 在项目根生成 AGENTS.md；`/memory` 管理记忆面板；`/clear` 切换不相关任务时清空上下文；`/compact` 长会话中途压缩历史。
- **指令（Commands）**：自定义可重复调用命令——`~/.qoder/commands/<name>.md`（用户级；项目级 `<project>/.qoder/commands/`），frontmatter `name` / `description` + 正文步骤，会话中 `/名称` 调用、增删改自动刷新；已建 `update-share-package`（分享包升版 → 同步文档 → 重建脱敏记忆包 → 重打 zip → 验证）。规则：反复用到的命令序列自动沉淀为指令（见 AGENTS.md 规则沉淀）。
- **信息分层原则**（官方记忆机制文档）：永久规则 → AGENTS.md/Rules；动态学习 → 长期记忆（auto-memory）；即时状态 → 对话上下文。会话开始时项目说明与长期记忆注入，对话上下文随会话累积。
- **大仓库实践**（官方 best-practices）：关键子目录放独立 AGENTS.md；从子目录启动会话就近加载模块上下文；Monorepo 按包组织说明；并行任务用 Git Worktree 隔离工作区。

**子规则按主题拆分（示例）**：一类按文件类型触发（如 Java/Spring、前端、React、Vue、测试、Python），一类由模型按描述判断（如数据库、中间件、交付、文档体系、长任务、开发任务拆分、Agent 工程）。**触发词纪律**：两条规则的描述若共用同一批关键词，同一句需求会同时命中、互相抢触发——把词留给更具体的那条（实证：把"任务拆分 / 批次"从长任务规则摘掉、只留给格式类规则）；改规则描述前先查有没有别的规则在抢同一批关键词。

## 全局技能

- 位置：`~/.qoder/skills/<name>/SKILL.md`（用户级；项目级 `.qoder/skills/` 同名时以实际加载为准）。
- 安装：官方市场用 MCP `extension-market.search_extensions` → `install_extension`（按 installRef）；社区源用 `npx --yes skills@1.5.22 add '<owner/repo@skill>' -g -a qoder -y`（CN 版用 `-a qoder-cn`）。
- skills CLI 语法坑：多技能用**重复 `-s`**（`-s a -s b`），逗号分隔会静默不装；CLI 需要 Node ≥ 22.2。
- **技能目录保持精简（同域不装第二个）**：同一件事只留一个入口，冗余与没有对应项目的栈移入 `skills-disabled/`（移走不删、可回退）；每个技能的 description 都常驻系统提示，装多了既吃上下文又会让同域技能互相抢触发。
  - **办公文档域现在只剩 `office-docs`**（自研、纯 Node、带样式层 `office-styles.js`、已过 32/32 自测）；官方 `Excel---XLSX` / `docx` 与市场 `excel-export` / `word-document-organizer` 均已停——后两者实测在本机跑不起来（要 `python3`/`pip3` 在 PATH，本机是指向商店的别名），前者是"同域不装第二个"的收敛（理由见盘点文档第六节）。
  - 日常走 Node 路线：`node ~/.qoder/skills/office-docs/scripts/office.js …`（顶层 `~/.qoder/scripts/office.js` 是转发壳），样式层 `office-styles.js`；装库带 npm 镜像源见 [[reference-npm-registry-mirror]]。本机 Python 3.14.6 可用但**不写进 PATH**（见 [[reference-python-real-path]]）。
  - 仍在装的能力域：Java/Spring 系列、测试质量、PostgreSQL（表设计+优化）、MySQL、Oracle（`db`）、Redis 核心与连接、nginx、RabbitMQ、Kafka、前端多框架与设计/样式（`awesome-design-md`、`tailwind-design-system`、`tailwindcss-animations`、`css-design-system`、`frontend-design-ui-ux`、`design-engineering-catalogue`）、小程序/小游戏、Python 选型与工程（`python-programmer` / `python-project-structure` / `python-testing-patterns` / `python-dataviz` / `async-python-patterns` / `fastapi-templates` / `python-backend-guidelines`）、架构/PRD/代码评审；输出风格 `i-have-adhd`、官方流程技能 `vibe-coding-workflow`，自制技能 `verify-before-claim`、`ship-clean-pr`、`verify-ui-in-browser`、`write-repowiki`、`vibecoding-doc`（把模糊需求转成 Vibecoding 文档，两种模式；格式以 `rules/vibe-coding.md` 为准）、`disk-junction-migration`、`merge-inbound-qoder-package`、`skill-trim-with-capability-transfer`（技能降量与能力迁移 playbook，带只读提及扫描脚本）、`verify-windows-cmd-tool`、`systemd-java-service-centos7`，另有一个项目专用的服务器服务清单枚举技能（含内网拓扑，**不外发、不随包**）。
- 诊断纪律：会话开头的技能列表**可能不完整**（实测只列插件技能、用户技能未显示），但实际可用——判断可用性要直接调用或植入探针验证，不要以列表未显示为据。
- **本机技能名与市场名并存，不是缺陷（2026-09-20 取证）**：本机技能目录里 `nginx-configuration` / `rabbitmq-development` / `kafka-development` / `db` 用的是早期安装名；分享文档第三节列的是**市场在售名**（`nginx-config-builder` / `rabbitmq-expert` / `kafka-best-practices` / `oracledb`，市场里的 canonicalName 还带发布者前缀，如 `majiayu000-rabbitmq-expert`）——文档面向"别人照着装"，本机沿用已装目录名，两者用途一致。**不要为对齐去重装或改名**；用 `extension-market.search_extensions` 按市场名搜到 `installed:false` 属正常（市场按 canonicalName 记录装机状态）。
- **临时产物卫生（2026-09-22 定；2026-11-09 收敛为唯一临时目录 + 收尾必问）**：唯一临时目录＝`D:/tmp`（`~/.qoder/tmp-sweeper.json` 的 `canonicalRoot`）；**不再新建 `%TEMP%/qoder-work`**；本机该目录（D:\Temp\qoder-work，550 文件/19MB，含 DbProbe、af XML、ui-serve 构建件）已于 2026-11-09 整体并入 `D:/tmp/legacy-qoder-work-20261109`（配置前缀 `legacy-qoder-work-` 排除扫描，内容保留待用户处置）。`%TEMP%/qoder-cli`（客户端自建 `.output`）、`%LOCALAPPDATA%/Temp/qoder-work`（C 盘遗留）只作排空根；`~/.qoder/tmp` 是机制台账（心跳/节流），不归清理。超期件（图片 / 文本 >3 天、脚本 >15 天）由 `~/.qoder/scripts/tmp-sweeper.js` 兜底，**删除前必须弹窗征得用户确认**（`--apply` 才真删）。**坑**：别用宽泛前缀扫 `%TEMP%`——Qoder 自身为每个会话建 `qoder-XXXX-cwd` 目录（实测数百个），宽前缀会误伤宿主；只用规范目录 + 精确白名单。**2026-11-09 修复与扩展**：① SessionStart 注入「清理提醒」（有超期且距上次 >7 天才提醒，节流状态 `tmp/tmp-sweeper/last-reminded.json`），提醒只报数不删；② 多根扫描＝`canonicalRoot` 优先 + 遗留/客户端根（`.output` 按文本类），`extraRoots` 仍可用；③ 活跃保护＝顶层条目 24h 内有改动整棵跳过（`--include-fresh` 解除），删后回收空目录；④ 证据排除＝`excludePaths`/`excludeTopPrefixes`（本机含 `D:/tmp/context-continuity-924e5d4b`、`D:/tmp/qo-deploy-20261109`、`QO-REL-*`、`evo-*`、`parallel-*`、`AV-AUDIT-*` 等被记忆/文档引用的取证目录）；⑤ 收尾门禁 `R14-temp-artifacts-unhandled`（stop-gate）：本回合在唯一临时根下新增条目而未弹窗询问/未 `--apply` 即拦停，要求给出**本任务清理范围**并推荐"全部清理本任务产物"；⑥ 命令层同步：`commands/clean-temp.md` 与 AGENTS 工程纪律同口径。⑦ 引用同步（2026-11-09 用户纠正）：临时根迁移/合并后必须同批更新记忆、技能、命令里的旧路径——能继续用的改到新根，已删产物标注「已随…删除，需要时重建」，不留死链；改完跑 `sync-memory.sh` 与 `sync-global-config.sh --check`。⑧ 超期清单只作参考（2026-11-09 用户纠正）：其他机器/包内配置生成的清单与本机不一定一致，清理范围以本机复扫与用户确认为准。**2026-11-09 实清**：24,370 个 / 295MB 超期件 + 9,918 个空目录（D:\tmp 24,278、qoder-cli 92），复扫为 0；D:\tmp 余量约 4.6GB 多为未归类的构建二进制/压缩包（不在清理判据内，需另定策略）。
- **分享包版本由 Agent 自动维护（2026-10-28 更名开源版 `Qoder-Optimization`，版本线重置为 `0.0.x`）**：每轮实质更新后**自行升版**——另建新版本目录 `Qoder-Optimization - x.y.z+1` 与同名 zip、重打 zip 使包内顶层目录名同步，目录名 / zip 名 / 包内 `VERSION` 三处一致，旧版保留为回滚点；**不再等用户手动改名**（2026-09-18 用户明确要求）。操作前先 `ls <发布目录>` 取当前实际目录名（早期版本命名不同，脚本仍兼容）。当前版本：**0.0.24**（2026-11-04；现役为三路合并部署，步骤见 [[qoder-optimization-share-package]]）。记忆包须由 `pack-generic-memory.js` 重建（自检 exit 0），再解压复验哈希与敏感词后才算数——未经复验的 tar 不得分发（2026-09-20 教训）。
- **安装状态文件**：`~/.qoder/share-package.json` 记录 catalog 路径；`~/.qoder/package-activation.json` 记录上次激活的 `catalogSha256` / `installedIds` / 恢复目录，可用 `catalogSha256` 反查上次安装提交，作为三路合并基线。

## 记忆

- 全局：`~/.qoder/memory/` + `MEMORY.md` 索引；项目级：`~/.qoder/projects/<project-slug>/memory/`。

## MCP / 插件

- MCP 配置：`~/.qoder/settings.json` 顶层 `mcpServers`（**官方用户级位置**，2026-09-18 官方文档确认；`~/.qoder/mcp.json` 实际未被使用）；改后 `/mcp reload` 或重开会话生效；已配 dbhub（多库只读）+ Context7，详见 [[reference-common-mcp-servers]]；stdio MCP 的 Windows 启动形式见 [[reference-windows-mcp-stdio-spawn]]。
- 已装插件（示例）：design-review / postman / cloud-agents / qoder-cloud-agents / open-code-review（配套 `ocr` CLI 全局安装）；gitlab 插件需 GitLab 18.3+/Duo 支持，自建实例不支持时应禁用。
- 插件与 MCP 从官方市场安装正常；技能安装如遇 EXDEV（用户目录与数据盘跨卷时的 rename 报错），修复 = 把 skills 目录迁到目标卷 + 原位 junction。
- **技能源避坑**：skills.sh 收录的 `partme-ai/full-stack-skills` 为索引型仓库、仓库内无实际 SKILL.md（实测安装报 "No skills found"），勿用；Nacos / RocketMQ / ActiveMQ 等无高质量社区技能时，由 `infra-ops.md` 规则覆盖即可。
- **技能安装网络坑（2026-09-18）**：企业网络下 github.com:443 可能间歇性阻断——skills CLI 依赖 `git clone` 会失败（实测）；备选路线：用 jsDelivr CDN（`https://cdn.jsdelivr.net/gh/<owner>/<repo>@main/<路径>`）直接下载 `SKILL.md` 到 `~/.qoder/skills/<name>/`；完整性用 GitHub 页面行数/大小核对（注意 jsDelivr 元数据可能滞后于其 CDN 内容，勿以元数据判错）。

## 双客户端共存实测（2026-09-18，一次"把 ~/.qoder 配置补齐到 ~/.qoder-cn"的落盘验证）

- **目录同构**：`~/.qoder/` 与 `~/.qoder-cn/` 用同一套子结构（`AGENTS.md` + `rules/` + `skills/` + `memory/` + `scripts/`）；一侧缺哪一份就在该侧按同结构补齐，不指望跨目录读取。
- **技能复制即时生效**：把 `skills/` 整目录复制到另一客户端后，**当前会话**的可用技能列表立即刷新（实测 76 个技能不重开会话即可被列出），不必重启。
- **MCP 生效边界**：两侧 `mcp.json` 都是空占位，真实 server 落在各自 `settings.json` 顶层 `mcpServers`；往 `settings.json` 加 server 后本会话 `mcp_list` **不会**出现（需重开会话），但可当轮用 `scripts/mcp-smoke.js <command> [args...]` 做协议级冒烟（initialize → tools/list）验证配置本身是否正确。
- **改全局文件前先重读**：本机可能有多个会话同时编辑 `~/.qoder/AGENTS.md` 与 `rules/*.md`（实测 `frontend.md`、`AGENTS.md` 在本次任务中途被另一会话改写过）。复制 / 改写前后各做一次 diff，否则会拿过期副本覆盖新结论；同步完成后用 `diff -rq` 复验两侧一致。
- **批量路径改写的坑**（2026-09-23 起 AGENTS.md 不再做分侧路径改写、两份保持一致；此坑仍适用于其他批量替换场景）：把配置里的 `~/.qoder` 全局替换成 `~/.qoder-cn` 时，会连带改掉"故意对比两个客户端"的句子（如"非 CN 版 `~/.qoder/`；CN 版 `~/.qoder-cn/`"、"`-a qoder`（CN 用 `-a qoder-cn`）"）。替换后必须 grep `非 CN|两套|-a qoder` 这类对比语境逐条复核。
- **两侧一致性复验**：`node ~/.qoder/scripts/verify-global-setup.js`——检查规则 frontmatter 触发器、技能 SKILL.md 有效性、记忆索引与文件一一对应、凭据例外清单、两侧同源状态；全绿退出码 0（2026-09-23 实测 13 项 PASS / FAIL 无）。**改完机制/全局文件后必跑**。**坑（2026-11-04）**：脚本打印 `FAIL:` 时退出码仍可能是 0（本次 AGENTS.md 漂移即如此）；不能只看 exit code，必须检查输出中的 FAIL 行。
  - 2026-09-23 修掉两处真问题：① 凭据项改为**先剥掉脱敏脚本的 `const SENSITIVE = [...]` 声明块再扫**——这些脚本必须内嵌口令样本才能做替换与比对，此前 3 个脚本及其 `_backup` 副本常年假红；豁免精确到声明块，文件其他位置命中仍判 FAIL（已用隔离用例验证两个方向）。② **第 8 项换判据（用户 2026-09-23 裁决）**：AGENTS.md 两份**保持逐字节一致**（由 `sync-global-config.sh` 同步），**不再要求"各自路径口径"**——当日曾按后者把 CN/国际版各改一轮，已废止并统一；文档里真正分侧的 `settings.json`/`commands` 改用"本侧配置目录"指代（不写死路径），rules/skills/memory/scripts 两侧本就是 junction、写哪侧都落到同一份。新断言做过**可失败性对照**：故意让两侧差一个换行 → 判红；还原 → 全绿。

## 配置目录同源化（junction，2026-09-18 起生效）

- `~/.qoder-cn/{rules,skills,memory,scripts,commands}` 已替换为指向 `~/.qoder/` 同名目录的 **NTFS Junction**（`commands` 于 2026-11-04 实测确认为 junction）（`New-Item -ItemType Junction`，无需管理员）。此后**只有一份**：任一侧客户端改规则 / 写记忆 / 装技能 / 跑脚本，另一侧同时可见，不再需要手工同步（`scripts/` 原先两侧只差 `MEMORY_DIR` 一行，合并后指向同一记忆池，差异失去意义）。
- 仍各自独立的是：`AGENTS.md`（两份实体副本，靠 `sync-global-config.sh` 保持**逐字节一致**，不做 junction）、`settings.json`（MCP 与客户端私有配置）、`mcp-router.json`、`projects/`（会话运行时状态）、`plugins/`、`extensions/`、`memories/`。
- **`projects/` 只做"项目级记忆"同源，不整目录合并**：目录按工作区路径派生 slug，内含 `<slug>/<会话uuid>.jsonl`（会话轨迹，实测单会话最大 1.4MB、国际版整目录 250MB）、`<slug>/<uuid>/state.json`、`compression-v2/`、`<slug>/memory/`（项目级记忆）。两侧 slug 近乎零重叠（会话工作区带 uuid），且两侧存在**只有大小写不同**的同名 slug（NTFS 大小写不敏感，会撞成同一个键）；整目录 junction 会把两侧会话历史混池，并在**会话正在写入一侧时**冒丢轨迹的风险。做法：按 slug 只 junction `<slug>/memory` 一层，先把该侧独有的项目记忆回流真源再断链；要整目录池化，必须在两个客户端全部退出后执行（进程守卫 + 可回滚脚本）。
- **安全删除 junction**：`cmd /c rmdir ~/.qoder-cn/<name>`（只断链）。**禁止** `rm -rf` 或资源管理器递归删除——会穿透链接删掉真源内容。恢复真实目录：先 `rmdir` 断链，再从建链前移走的备份目录里 `mv` 回来（本包 `scripts/link-cn-dirs.ps1` 即用此法，自带备份槽与 `-Revert`）。
- **凭据口径**：合并后以单一真源为准；哪些记忆正文允许保留既有凭据属于**用户裁决**，要在**校验脚本里显式登记成例外清单**，清单外出现即 FAIL。**边界不变**：不得新增明文秘密，索引与对外汇报必须脱敏（索引里出现过的"账号 / 口令"对要改为指向正文）——见 [[feedback-protect-secrets]]。
- **机器校验（同源化的必要配套）**：合并成 junction 后，"对比两侧目录"必然恒真、判据失效，断言要换成 ① 目录确为 reparse point 且 `realpath` 指向真源 ② 未合并的一侧不存在未回流文件 ③ 凭据扫描把"禁区"（规则 / AGENTS / 索引 / 脚本）与"允许保留凭据的记忆正文"分开判定。另注：`fs.lstatSync().isSymbolicLink()` 对 junction 不可靠，PowerShell `.Target` 会回显链接自身路径——用 `realpath` 比较才准。
