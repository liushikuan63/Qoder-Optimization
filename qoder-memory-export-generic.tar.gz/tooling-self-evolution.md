---
name: tooling-self-evolution
description: 自进化机制（Codex Python 移植到 Node.js）：证据门槛、checkpoint/commit/rollback、受管路径与两侧独立；现役入口在 skills-library；R19 pending 真源与 --decline；2026-11-25 验证“部分覆盖时并入最窄既有载体”
metadata:
  type: reference
---

# 自进化机制（self-evolution）

**来源**：2026-10-10 从 Codex harness 的 `self-evolution-stage`（Python 实现 `evolution.py`）移植到 Qoder 的 Node.js 环境（`evolution.js`，零外部依赖）。

**现役位置**：`~/.qoder/skills-library/self-evolution/`（SKILL.md + scripts/evolution.js + references/operations.md）。早期记忆写的 `~/.qoder/skills/self-evolution/` 已不是现役入口；两侧同步以 `sync-global-config.sh --check` 为准。

## 核心设计

- **证据门槛**（不是自动计分，是脚本记录事实 + 代理判断语义）：
  - 用户明确偏好：一次即可
  - 推断偏好：≥3 个独立真实任务、跨 ≥2 个会话
  - 已验证技术经验：按项目记录，只有对已有技能的证实错误修正可立即更新
  - 可复用流程：≥3 个独立任务或用户明确要求
  - 插件/MCP 缺口：用户当次明确需要或 ≥2 个独立任务同一缺口
- **受管路径白名单**：`~/.qoder{,-cn}/AGENTS.md`、`~/.qoder{,-cn}/settings.json`、`~/.qoder{,-cn}/skills/*`；**不碰** `.system`、插件缓存、项目文件（项目文件按项目自己的版本控制处理）。
- **数据目录**：`~/.qoder/evolution/`（`records/`、`checkpoints/`、`control.json`）；两侧独立、不共享。

## 命令与用法

```bash
node ~/.qoder/skills-library/self-evolution/scripts/evolution.js status
node ~/.qoder/skills-library/self-evolution/scripts/evolution.js record --input evidence.json
node ~/.qoder/skills-library/self-evolution/scripts/evolution.js checkpoint --input change.json
node ~/.qoder/skills-library/self-evolution/scripts/evolution.js commit --id <ID> --validation '验证结果'
node ~/.qoder/skills-library/self-evolution/scripts/evolution.js rollback --id <ID> [--apply]
```

## 关键机制

- **文件锁**（`acquireLock/releaseLock`）：防并行会话同时写 `control.json` 或 `records/`。
- **原子写入**（`atomicWrite`）：temp 文件 + rename，不产生半写状态。
- **checkpoint/commit 双快照**：checkpoint 保存修改前哈希 + 内容，commit 保存修改后哈希 + 验证结果；commit 时检测并发修改（修改后哈希与当前文件哈希不一致 ⇒ 标记冲突）。
- **rollback 哈希校验**：`--apply` 只在全部文件仍匹配记录的修改后哈希时恢复；有并发修改时按区块合并撤销，不整文件覆盖。
- **`--user-requested`**：暂停期间只有用户明确要求的维护操作才能写入，表达调用原因、不提供新授权。

## 与 AGENTS.md 的关系

AGENTS.md 已加「自进化」章节（在"记忆"与"规则沉淀"之间），写明证据门槛、不做什么、checkpoint/commit/rollback 流程、两侧独立。规则层只写策略，执行细节在技能里。

## 移植时的适配点

- Python `fcntl.flock` → Node `fs.openSync` + 排他写（`wx` 标志 + 重试）
- Python `hashlib.sha256` → Node `crypto.createHash('sha256')`
- Python `tempfile + os.rename` → Node `fs.writeFileSync(tmp) + fs.renameSync(tmp, target)`
- 路径白名单从 Codex 的 `~/.codex/` 改为 `~/.qoder{,-cn}/`
- 状态文件 `control.json` 格式保持一致（`paused` / `lastId` / `counter`）

## 收尾候选（R19）要先核实再采纳：excerpt 截断会造假缺口（2026-11-15 实测）

- **候选真源**：`~/.qoder/tmp/evolution-capture/pending-<会话ID前8位>.json`（`items[]` 含 kind/topic/carriers/excerpt/evidence.occurrences）。stop-gate R19 读的就是这份 pending，采集层只写 pending、永不拦截。
- **excerpt 是被截断的**：本轮三条候选里「capability-gap：没有-改法-命令」的 excerpt 停在 `gr...`，而现读被指控的守卫源码发现**改法命令确实存在**（整读提示给了「先 Grep 定位再 Read 带 offset/limit」，大输出提示给了「重定向落盘 + tail/head」）⇒ 纯误判。另两条「同一错误重复失败」其实是守卫**按设计生效**拦下整读大文件与无限量 grep，规则层早有对应纪律。
- **处置口径**：候选 `verified` 一律 false，只是待核对材料、不是授权。采纳前先读 pending 原文＋现读被指控载体核实；三条都已被现有机制覆盖时推荐「本轮跳过」，理由是「同域不装第二个」——再沉淀就是第三份重复纪律，稀释注意力。
- **跳过要登记**：`node ~/.qoder/scripts/evolution-capture.cjs --decline "<topic>" --decline "<topic>" …`（可一次多主题），实测输出 `declined=3 removed_from_pending=4 total=3`、exit 0；登记后同主题不再重复弹。用户选采纳才动载体（先 carrier-preflight 查重→备份→最小差异→验证→evolution.js record）。
- **真缺口可能在采集器而非守卫**：误判根因是 excerpt 长度/分类判据，改它属另一批授权（会触碰现役脚本），不要顺手在本批扩范围。

## 用户明确不再追问时（2026-11-24）

- 若用户中断/拒绝自进化 `AskUserQuestion`，并明确说“不再询问、直接收尾”，按**本轮跳过**处理：运行 `evolution-capture.cjs --decline "<topic>"` 登记，同主题不再弹；不改技能、hook 或记忆载体。
- **Why:** 用户的明确收尾指令优先于 R19 的重复弹窗；沉默或单纯取消不等于跳过。
- **How to apply:** 只在用户明确说 skip / finish / no more questions 时使用；若用户选采纳，仍走 carrier-preflight → 备份 → 最小修改 → 验证 → `evolution.js record`。

## 部分覆盖时并入最窄既有载体（2026-11-25 验证）

- 用户对“检索路径含 node_modules 触发范围守卫/超时”候选选择采纳。`carrier-preflight` 返回 REVIEW、无 similar/blockers，只提示 AGENTS 超过预警行数。
- 实际没有新建规则、技能或 hook：把一句检索范围纪律并入既有「控制上下文污染」条目，行数不变；改前备份无该句、改后存在，双端 32 个配置文件逐字节同步。
- **How to apply:** 候选已被现有载体部分覆盖时，优先合并到最窄既有条目，不另起平行文件；行数预警不等于必须新增载体。验证用“改前 false / 改后 true”的可失败对照，最后用 `evolution.js record` 留证。

## `record` 字段与类型枚举（2026-11-27 实测）

- **type 只接受 4 个值**：`observation` / `correction` / `capability-gap` / `rejection`。写成 `memory` 会直接报 `{"error":"Invalid type/explicit/verified"}`（不是字段缺失）。
- 必填：`type/topic(≤160)/scope(≤240)/summary(≤600)/evidence/explicit`；可选 `verified`。`evidence` 必填 `task_id`、`source`（user / local-validation / memory / external）、`detail(≤600)`，可选 `session_id`。**`explicit:true` 要求 `source:"user"`**（用户明确要求/选择）；仅本地验证的用 `source:"local-validation"` + `verified:true`。
- 成功返回 `{id, independent, duplicate_of}`；重复主题会给出 `duplicate_of` 而非报错。
- 内联 `node -e` 写含 "grep" 等关键词的 JSON 会被 PreToolUse 守卫误拦（见 grep-scope-guard-recovery），改用 Write 落 `.json`，命令行只留路径。

## junction 限制（2026-10-10 实测）

受管路径经 **junction** 时会被安全检查拒绝：`checkpoint` 报 `Symlink/reparse paths are forbidden: ~\.qoder\skills`（该目录是 junction→`D:\UserData\.qoder\skills`）。⇒ **非 CN 侧技能文件无法走 checkpoint**，用 cp 备份 + 两侧 md5 比对兜底；CN 侧 `~/.qoder-cn/skills` 是实体目录、可正常 checkpoint。AGENTS.md / settings.json 两侧都不经链接、正常可用。改工具本身（放开 junction）属"绕过自身验证"边界，未做。
