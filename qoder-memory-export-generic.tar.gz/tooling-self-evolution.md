---
name: tooling-self-evolution
description: 自进化机制（从 Codex Python 移植到 Node.js）：证据门槛（推断偏好需 3 个独立任务/2 个会话）、checkpoint/commit/rollback 带 SHA-256 校验、文件锁、受管路径白名单；数据目录 ~/.qoder/evolution/，两侧独立
metadata:
  type: reference
---

# 自进化机制（self-evolution）

**来源**：2026-10-10 从 Codex harness 的 `self-evolution-stage`（Python 实现 `evolution.py`）移植到 Qoder 的 Node.js 环境（`evolution.js`，554 行，零外部依赖）。

**位置**：`~/.qoder/skills/self-evolution/`（SKILL.md + scripts/evolution.js + references/operations.md），两侧各一份、已 `diff` 确认一致。

## 核心设计

- **证据门槛**（不是自动计分，是脚本记录事实 + 代理判断语义）：
  - 用户明确偏好：一次即可
  - 推断偏好：≥3 个独立真实任务、跨 ≥2 个会话
  - 已验证技术经验：按项目记录，只有对已有技能的证实错误修正可立即更新
  - 可复用流程：≥3 个独立任务或用户明确要求
  - 插件/MCP 缺口：用户当次明确需要或 ≥2 个独立任务同一缺口
- **受管路径白名单**：`~/.qoder{,-cn}/AGENTS.md`、`~/.qoder{,-cn}/settings.json`、`~/.qoder{,-cn}/skills/*`；**不碰** `.system`、插件缓存、项目文件（项目文件按项目自己的版本控制处理）。
- **数据目录**：`~/.qoder/evolution/`（`records/`、`checkpoints/`、`control.json`）；两侧独立、不共享。

## 命令与用法

```bash
node ~/.qoder/skills/self-evolution/scripts/evolution.js status
node ~/.qoder/skills/self-evolution/scripts/evolution.js record --input evidence.json
node ~/.qoder/skills/self-evolution/scripts/evolution.js checkpoint --input change.json
node ~/.qoder/skills/self-evolution/scripts/evolution.js commit --id <ID> --validation '验证结果'
node ~/.qoder/skills/self-evolution/scripts/evolution.js rollback --id <ID> [--apply]
```

## 关键机制

- **文件锁**（`acquireLock/releaseLock`）：防并行会话同时写 `control.json` 或 `records/`。
- **原子写入**（`atomicWrite`）：temp 文件 + rename，不产生半写状态。
- **checkpoint/commit 双快照**：checkpoint 保存修改前哈希 + 内容，commit 保存修改后哈希 + 验证结果；commit 时检测并发修改（修改后哈希与当前文件哈希不一致 ⇒ 标记冲突）。
- **rollback 哈希校验**：`--apply` 只在全部文件仍匹配记录的修改后哈希时恢复；有并发修改时按区块合并撤销，不整文件覆盖。
- **`--user-requested`**：暂停期间只有用户明确要求的维护操作才能写入，表达调用原因、不提供新授权。

## 与 AGENTS.md 的关系

AGENTS.md 已加「自进化」章节（在"记忆"与"规则沉淀"之间），写明证据门槛、不做什么、checkpoint/commit/rollback 流程、两侧独立。规则层只写策略，执行细节在技能里。

## 移植时的适配点

- Python `fcntl.flock` → Node `fs.openSync` + 排他写（`wx` 标志 + 重试）
- Python `hashlib.sha256` → Node `crypto.createHash('sha256')`
- Python `tempfile + os.rename` → Node `fs.writeFileSync(tmp) + fs.renameSync(tmp, target)`
- 路径白名单从 Codex 的 `~/.codex/` 改为 `~/.qoder{,-cn}/`
- 状态文件 `control.json` 格式保持一致（`paused` / `lastId` / `counter`）

## junction 限制（2026-10-10 实测）

受管路径经 **junction** 时会被安全检查拒绝：`checkpoint` 报 `Symlink/reparse paths are forbidden: ~\.qoder\skills`（该目录是 junction→`D:\UserData\.qoder\skills`）。⇒ **非 CN 侧技能文件无法走 checkpoint**，用 cp 备份 + 两侧 md5 比对兜底；CN 侧 `~/.qoder-cn/skills` 是实体目录、可正常 checkpoint。AGENTS.md / settings.json 两侧都不经链接、正常可用。改工具本身（放开 junction）属"绕过自身验证"边界，未做。
