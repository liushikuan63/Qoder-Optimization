---
name: feedback-organize-reusable-scripts
description: 通用或高复用率的脚本应单独放到专用文件夹统一管理，不散落在项目各处
metadata:
  type: feedback
---

通用或复用率较高的脚本应单开一个专用文件夹进行统一管理，不要散落在项目目录中。

**Why:** 脚本复用率高时散落管理会导致重复、难找、版本混乱。

**How to apply:** 编写脚本时判断其是否通用或可复用；如果是，将其放入独立的脚本管理文件夹（如 scripts/ 或 shared-scripts/），而非留在当前工作目录。
