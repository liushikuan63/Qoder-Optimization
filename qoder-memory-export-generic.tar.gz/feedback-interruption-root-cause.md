---
name: interruption-root-cause
description: 「任务老中断」的根因是单请求 payload 过大触发传输层 60s 掐断；三层机制已在 2026-09-19 接管（大输出守卫 / 会话体积哨兵 / 规则），含验证方式与调松入口
metadata:
  type: feedback
---

**规则**：往上下文里灌大块内容 = 让回合活不下来。单条工具返回 >20KB 就要当成炸弹处理。
（用户 2026-09-19 点名要求"修复任务老中断的问题"，这是排查后的结论，不是风格偏好。）

**Why（取证，遍历本项目九个会话的 transcript）**：
- 119MB / 65.8MB 两个会话里出现 **9 次传输层掐断**：`Model stream timed out before response headers after 60s` ×3、
  `The model service rejected this request` ×4、`The request could not be completed` ×2。
  这些回合**没有收尾文本**（不是我在停手），用户看到的就是"任务又断了、要再敲一次继续"。
- 因果链：单条工具返回越大 → 单请求 payload 越大 → 第三方 provider（本项目走 `api.commandcode.ai`，200k 窗口）60s 内发不出响应头 → harness 中止本回合。
- 炸点分布（>20KB 共 81 条 / 3MB）：**Read 整读大文件 921KB**（`收口清单.md` 一次 913KB、项目记忆文件被整读五六遍 38~54KB/次）、
  Edit 回显 849KB、Bash 无上限输出 454KB、**子代理报告 382KB**（每条 40KB 量级，尽管提示词里写了"600 字以内"）。

**How to apply**：
- 大文件：先 `grep -n` 定位再 `Read` 带 `offset/limit`；要通读就 `sed -n '1,200p'` 分段。
- 命令：一律 `> /tmp/x.log 2>&1; tail -30 /tmp/x.log`（或 `| head`、`-l`、`-c`、`--oneline`）。
- 子代理：提示词里写"只回结论、点到路径与行号为止"，别让它贴代码（机制已自动追加这段约束）。
- 会话到档位就**先落盘、再继续推进任务**（别等被掐断）；本项目不稳（压缩 ≥2 次 / 逼近红线）时才把任务**搬到新会话接着跑**——接续点写进项目根 `.qoder-work-queue.md`，新会话开局会自动读到并**直接接着做**。**换会话是手段不是收工**（见 feedback-persist-until-exhausted）。

**机制（不要靠记性，2026-09-19 已上线并现场验证）**：三层，**防线必须前移到"回合开始之前"**——
**关键结构认识：被掐断的回合根本到不了 Stop**，所以只在 Stop 判体积的门禁兜不住这件事（R7 只能救"侥幸活下来"的回合）。
① **降速** `~/.qoder/scripts/huge-output-guard.js`（PreToolUse，两侧已挂）：整读大文件 deny / 无上限命令 deny / 子代理提示词追加 ≤300 字约束；
② **前移预警** `~/.qoder/scripts/session-budget.js`（UserPromptSubmit，两侧已挂）：**三个独立信号** ——
**体积分档**（≥8MB 节约 / ≥15MB 先落盘再继续 / ≥25MB 立即落盘）、**压缩次数**（`isCompactSummary` ≥1 提醒落盘 / ≥2 落盘并继续）、
**上一回合上下文增量**（≥2MB 报警，即"返回侧入账"：读取侧只拦"明显超标的单条"，拦不住多条中等返回累积；只有回合粒度，看不出是哪个工具贡献的——要单工具粒度得接 PostToolUse）；
③ **最后兜底** `stop-gate.js` **R7**（会话 ≥25MB 拦停，要求先交接）。
体积取值三来源（都实测通过）：`transcript_path` → `session_id` 精确定位 → `cwd` 推导项目目录；**不做全库扫描**（会拿别的会话的体积判档）。
自测：`huge-output-guard.test.js` 23 条、`session-budget.test.js` 31 条（三档必触发 + 压缩信号/返回侧增量各自独立触发 + 看门狗四态 + 不该触发必静默 + disabled/非法输入 fail-open）、`stop-gate.test.js` 27/27；
台账 `tmp/huge-output-guard/decisions.log`、`tmp/session-budget/checks.log`（每回合体积 / 档位 / comp=N / Δ=增量 / 取值来源，可核对可看趋势）。
**关掉/调松**：`~/.qoder/huge-output-guard.json` / `~/.qoder/session-budget.json` 写 `{"disabled":true}`；阈值 `HOG_READ_BYTES`/`HOG_READ_LINES`/`SB_YELLOW_MB`/`SB_ORANGE_MB`/`SB_RED_MB`/`SB_TURN_GROWTH_MB`/`SB_AUDIT_STALE_DAYS`/`STOP_GATE_SESSION_MB`。

**中断的代价要靠"接续"压下去（2026-09-19 定型的第二半）**：光防掐断不够，还要让"被中断"这件事变便宜。
约定 **项目根 `.qoder-work-queue.md`** 作标准交接产物（交接四件事：做到哪 / 下一步第一件事 / 阻塞点 / 关键入口；未完成项写 `- [ ]`）。
`session-budget.js` 在 **SessionStart** 把未完成项自动注入新会话开局上下文 ⇒ 用户不必重新交代一遍。
规则侧已写进 AGENTS.md「任务处理」：**落盘是持续动作，到档位先落盘再继续推进**；换会话只是把任务搬个地方接着跑，**不是收工信号**。

**连带发现三（本次）**：
- **R7 的结构性缺陷**（上面那条）：阈值再准也白搭，因为它晚于事故发生。凡是"防某事故"的检查，先问"事故发生时这个检查跑得到吗"。
- **体检脚本抓到的耗时不匹配已被修**：`sync-memory.sh` 原逐文件 `cmp`（84 文件 × 两侧 ≈200 次 spawn，实测 29–34s）超过 `global-config-guard.js` 的 8s 超时 ⇒ 那项检查永远超时、等于没做。现改为**每侧只跑一次 `md5sum`**（0.7s，总耗时降到 2.3s），并保留"取不到内容宁可报红"的兜底。**修完再跑体检，告警正常消失**——这正是"判据能失败"的价值：它先红过，才证明绿是真的。
- **又一次踩到反斜杠**：往 `node -e` / heredoc 里内联 Windows 路径时 `<用户目录>\...` 的 `\U`/`\a`/`\2` 会被当转义吃掉，得到 `C-Users<user>DocumentsQoder6-09-12...`，于是"测试失败"其实是测试夹具错了。**Windows 路径一律用正斜杠或 `String.raw`**，别内联裸反斜杠。

**连带发现（同一次排查里的第二条）**：`stop-gate.test.js` 早已红了三条而没人看 —— R1b 上线时没同步期望值
（夹具写的「我接着开下一格」正是 R1b 该拦的形状、规则号正则 `R\d-` 匹配不到 `R1b-…`、`--report` 期望的规则名过期）。
**门禁自己的自测红着，等于"守卫生效"的信心建立在错的证据上**；已修并写明原因。
同族的检查纪律：改了门禁规则就要跑它自己的自测，别只看它拦没拦住那一句。
