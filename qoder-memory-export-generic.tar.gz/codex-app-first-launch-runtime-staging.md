---
name: codex-app-first-launch-runtime-staging
description: Codex 桌面版大更新后"一直无界面"的根因与修复：首启动要复制 cua_node 运行时到本地（staging→16hex 目录），复制慢且被打断会死循环，等一次跑完即恢复
metadata:
  type: reference
---

**现象**：Codex 桌面版大版本更新后（2026-09-18 实例：26.908 → 26.911），启动后**一直不出界面**：进程在跑（5 个、无 renderer）、窗口对象存在但 Visible=False、日志停在 `Launching app` 一行、CPU 空闲。

**根因**：新版首次启动必须把包内运行时 `app\resources\cua_node`（4123 文件、约 261MB，含 node/npm）复制到 `%LOCALAPPDATA%\OpenAI\Codex\runtimes\cua_node\<16位hash>`（临时目录 `.staging-<hash>-<rand>`，完成后 rename）。复制慢（实测约 16 文件/秒）且**全程无 UI 反馈**；用户以为卡死而关闭/重开 → 从头再来。本次连续 4 轮（00:42/00:46/00:49×2）均半途而废；**第 5 次不被打断，约 4.5 分钟自动完成** → 窗口出现。完成后自动：staging→rename、清理旧 `.staging-*` 与旧 hash 副本、更新 config.toml 中 notify/node_repl 的路径（**但不会更新用户自加 MCP server 里手写的旧路径**）。

**判据**：`...\runtimes\cua_node\` 下出现 `.staging-<hash>-*` 残留且文件数停滞；app 日志（`...\LocalCache\Local\Codex\Logs\<UTC日期>\codex-desktop-*-t0-*.log`）只有 `[sparkle] in_app_updates_policy_wait_started` + `Launching app` 两行；当前目标 hash 可从 staging 目录名提取。

**正确做法**：
- 大更新后首启动**给足 5-10 分钟、不要关它**（别反复点图标/杀进程）。
- 备用：无 Codex 进程时手动 `robocopy` 包内 `resources\cua_node` → `runtimes\cua_node\<hash>`（在 PowerShell 里跑，Git Bash 会把 /E 等参数当路径转换掉）。
- 更新后扫一遍 `~/.codex/config.toml` 里指向旧 hash 的路径（用户自加条目不会被 app 自动更新）。本次修复后已手工把 context7 mcp 的 node.exe 路径改为 `fcf5d08964516500`。

相关：[[codex-app-update-staged-pending]]
