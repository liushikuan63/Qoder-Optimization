---
name: feedback-parallel-sessions
description: 同仓库多会话并行：提交/还原前 git status 分辨归属且每轮重判，非本会话改动不碰；推送用已验证的 SHA 而非 HEAD，带对方提交需另批授权；探针回滚先备份再还原
metadata:
  type: feedback
---

同一仓库可能有多个会话 / AI 工具并行改动。提交、还原、清理前先 `git status --short`，逐项区分「我这轮改的」与「工作区里本就有的」。

**Why:** 用户会开多会话并行改同一仓库。实测：提交自己的批次后工作区冒出别的会话的未完成改动（前端组件、探针文件）；冒然提交会把别人未完成的工作混进 commit，冒然 `git checkout` / `git restore` 会直接毁掉他人工作或自己的未提交编辑（两次实测：自己刚写的功能代码被一次 checkout 抹掉，只能凭上下文重放）。

**How to apply:**
- 提交前回顾本轮自己改过哪些文件（对照工具调用记录），只 `git add` 明确路径；**不用 `git add -A` / `git add .`**。
- 看到陌生改动（`zz-*.test.ts`、`*.probe.*`、临时脚本）先读内容判断来源，再给用户处置选项（留给原会话 / 我来验证后提交 / 部分提交），不替用户拍板。
- 共享文档里躺着别人未提交的相邻行时：**本轮不提交该文件**，把要写的行留到对方落地后补记，不动别人的行、不改他们的编号。
- 探针回滚固定动作：植入前先 `cp <file> <bak>` **留可还原的拷贝**（只存 md5 没用——只能证明丢了，不能还原）；还原用 `cp` 覆盖 + `md5sum -c` 或精确反向编辑；敲 `git checkout` / `git restore` 前先 `git diff --stat` 看会一起丢多少行，不是 0 行就换手段。

相关：[[feedback-delivery-hygiene]]、[[feedback-fix-and-sweep]]。


## 同一工作副本里有并行会话时的三条硬规矩（2026-10-08 实测补充）

1. **写任务必须收敛为单会话顺序执行**：本轮开工前 `svn status` 只有 5 个前端 `M`，一小时内变 8 个
   （`layouts/index.tsx`、`utils/request.ts` 等新出现）→ 说明另一会话**正在改**。
   判据：动手前后各跑一次状态命令比对**清单差异**，不要只比"有没有 M"。
2. **并发构建会污染证据**：前端改动的验收依赖 `npm run build` 产物与 dev server，
   两个会话在同一目录并发构建，产物哈希与 DOM 断言都无法归因 → 本会话直接**让出 `fronted/` 领地**，
   只替对方跑构建门槛（退出码 0）并写明"组件级行为未验 + 原因"。
3. **共享台账文件要"点名提交"**：`验收矩阵.md` 两个会话都在写。提交时**只列自己那几条路径**，
   并在提交说明里点名"连带入了对方写的 XX 措辞"（本轮 r41245/r41246 都这么写了），
   否则对方会以为自己的改动已入库，或误以为内容是你写的。
4. 追加文本进共享文件前先 `Read` 取**当前**内容再改：本轮按记忆里的旧措辞做精确替换连续失配 3 次
   （对方已把标题改掉），最后改成"落成文件 + `cat >>`/按行号 splice"的写法。

## 必须改"带别人未提交改动的文件"时（2026-10-12 实测）

删除/重构一个**正被别的会话改的文件**时（本轮：删本地用户栈必须改 `BuildProjectController`，而它带着他会话未提交的 `syncWorkflowStatus` 端点）：

1. **先查两件事再动**：`svn status <file>`（是否仍被改）+ `svn cat -r HEAD <file> | grep <符号>`（目标引用是**本就存在**还是对方新加）。本轮先误判过一次——以为 `sysUserService` 是对方新加的，实为已提交代码。
2. 只有"必须动它才能达成目标"时，**弹窗**给三选一：① 我改并**连同他的未提交改动一起提交**（提交说明里点名"连带入了对方 XX"）② 等他先提交 ③ 换不动该文件的替代方案。
3. 本轮用户选 ①：改动照做、提交说明显式点名对方改动，HEAD 保持可编译、进度不停。**默认不替用户拍板**（同 [[feedback-delivery-hygiene]]）。

## 共享端口与"服务还开着给你复核"这类断言每轮重判（2026-11-23 实测）

上一轮汇报里写的"dev server 保留中（PID X/Y）"到下一轮就可能是假的：本机 8082 被并行会话用 `npm start`（→ `cross-env` → `max.js dev` → `forkedDev.js dev`）在 12:15:25 抢下，本会话起的实例旧 PID 全部 `GONE`，自己的重启任务以 `Error: listen EADDRINUSE: address already in use :::8082` 结束（外层包装仍打 `DEV_TASK_EXIT=0`，见 [[tooling-background-task-exit-code]]）。

**Why:** 端口是跨会话共享资源，"保留中"是**运行时状态**而不是已入库事实；沿用上一轮 PID 会让用户按失效地址去复核，等于给了个打不开的证据入口。同理，工作副本里他人把 `.umirc.ts` 的 proxy `target` 从现网网关改成本机端口联调，会让人把自己已提交的修复误判成"被回退"。

**How to apply:**
- 声明"服务还开着 / 端口保留 / 用这地址复核"之前，本轮重跑 `netstat -ano` 取当前监听 PID，再按 PID 读 `Win32_Process` 的 `CommandLine` + `CreationDate` + 父链判归属；旧 PID 查不到就是归属真空，如实更正上一轮的说法。
- 不杀他人实例（技能纪律）；要自己的实例就换端口起，并在汇报里点名当前实例的后端指向与数据口径差异。
- 核对"入库字节 == 验证字节"前先 `svn diff` / `git status` 分辨他人未提交的配置改动（本例＝proxy target 全改本地），不要替对方还原，也不要据此判自己的提交失效。
- 跨轮引用上一轮的验收读数时标注出处与时间；别人起的实例上没复跑的浏览器级门禁要写"未在新实例复跑 + 原因"，不能拿旧实例的绿代替。

相关：[[feedback-delivery-hygiene]]、[[feedback-fix-and-sweep]]、[[feedback-backup-before-modify]]。

## 只提交对方 feature 的"一个文件"会把 HEAD 弄挂（2026-10-12 实测）

对方会话的未提交改动常是**一个 feature 的多文件集**（本轮：`syncWorkflowStatus` = controller + service 接口 + impl + dao + mapper）。我为自己的改动（删本地用户栈）必须改其中的 controller → 只提交了 controller、**没提对方其余文件** ⇒ **HEAD 编译不过**（controller 调用的接口方法还在未提交的接口文件里；我本地能过是因为工作区带着对方的文件）。

**规矩**：一旦决定"连带提交对方文件"，就**把该 feature 的整个文件集一起提交**；或在提交前先 `svn cat -r HEAD <file> | grep <被调用符号>` 确认这些符号**已在 HEAD**。发现已造成 HEAD 断链，**立即补提整个 feature 集**并在说明里点名（本轮 r41295 补提，修复 r41293 引入的断链）。

**Why:** 共享工作副本里"我提交 A、对方留 B"看起来干净，但 A 依赖 B 的符号时，HEAD 就停在编译不过的状态，坑到下一个拉取的人。
**How to apply:** 提交前对"我改的每个文件"扫一眼它新调用/引用的符号是否都在 HEAD；不确定就整组提交并点名。

## 发布分支与标签的并行冲突（2026-11-04 实测）

发布过程中另一会话可能推送 main 和新 tag：0.0.23 发布时远端 main 先后被 0.0.24 提交推进两次，`git push origin main` 连续被拒。

**Why:** force-push main 会丢掉另一会话已发布的提交；发布后再移动 tag 会让已下载/已引用的资产与标签不一致。

**How to apply:** 推送前先 `git fetch origin`；main 落后就 `git merge origin/main` 解决冲突后再推，绝不 force；tag 只在**还没有任何 Release/资产**时允许重建，已有 Release 后不得移动；并行会话的正式发布标签（如 v0.0.24）不要覆盖。

## 推送前 HEAD 多了并行提交（2026-11-09 实测）

推送前复核 `git log origin/main..HEAD`，发现任务期间另一会话已在本地提交（auto-clean 改动），且工作区还留着它未提交的测试修复；用户最初授权的"推送本地提交"只指当时那批。

**Why:** 新提交属于另一会话，默认带走等于替对方发布；未提交的修复也不能由我提交或改动。

**How to apply:**
- 出现新提交就**重新弹窗确认推送范围**；只推原批次可用 `git push origin <目标sha>:main`（快进，不带后续提交）。
- 若对方正在修与本批门槛相关的测试（本次为 `codex-feedback` 失败用例），优先等它提交后一起推，并在推送前重跑全量。
- 2026-11-09 用户选择：**等并行会话提交修复后一起推**（不单独推原批次、不带走未提交改动）。

## 临时目录清理门禁会误把并行会话探针算成本轮产物（2026-11-09 实测）

自动清理（stop-gate R14 / `tmp-round-scan --since`）只按时间窗扫描，会把并行会话的探针目录算进"本轮产物"。实测：`D:\tmp\某系统_probe_20261109` 属于 `<项目目录>\某系统` 的会话 `dccd08dd-...`（task `某系统-preset-500-fix`），其 transcript 时 mtime 与当前时间只差 1 秒、目录仍在新增文件，而门禁连续两次要求 `--apply`。

**Why:** 时间窗只回答"何时出现"，不回答"谁创建、是否仍在用"；按窗删除会直接破坏另一会话正在进行的验证，且违反"并行会话共用临时根禁止按时间窗整根清理"。

**How to apply:** 先 dry-run 看清单；逐项查归属——临时目录里的 `verification_request.json` / 配置中的 `taskId`/`sessionId`/`workspaceKey`，或到 `~/.qoder/projects/**/<sessionId>.jsonl` 看 mtime；归属他人或所属会话仍活跃 → **保留**，在最终回复里写明"保留 + 原因 + 证据"，不执行 `--apply`；确认是本任务产物才用 `--only <精确路径>` 或 `--since` 清理。复扫后必须反馈删除/保留结果。

## 本地 main 夹带并行发布提交时（2026-11-09 实测）

推送前 `git log origin/main..HEAD` 发现本地 main 比远端多 3 个提交：并行发布会话的 `8ebb493`（0.1.1 发布准备）和 `11da2d5`，以及本会话的 `a63de92`；远端 main 只到 `2025191`。直接 `git push` 会把发布会话尚未完成全量验证的提交一起推上去。

**Why:** 用户只授权推本会话的 hook 提交；发布会话的 0.1.1 批次正在等全量套件，替它推送会干扰其发布节奏。

**How to apply:**
- 先 `git fetch origin` 并复核 `git log origin/main..HEAD`，按提交归属拆分。
- 只推自己的提交：`git worktree add <临时目录> origin/main --detach`，在隔离 worktree 里 `git cherry-pick <自己的提交>`，再 `git push origin HEAD:refs/heads/<独立分支>`；不动本地 main、不 force。
- cherry-pick 到旧基线可能出现冲突：本次 `CHANGELOG.md` 冲突块夹带了发布会话的中文条目；解决时**只保留本批新增条目**，把发布会话的 0.1.1 文案留在其分支，不要顺手带进独立分支。
- 推送前在隔离 worktree 跑全量；完成后 `git worktree remove` 并清理临时目录。

## 同一文件里分离两批 hunk：按内容标记，不按行号（2026-11-13 实测）

必须改一个**正带着另一会话未提交改动**的文件（本轮 `CHANGELOG.md`：对方在 Unreleased 加了 14 行，我要在 0.1.6 节补条目）时，可以只提交自己的 hunk，不必整文件让路：

1. `git diff -- <file>` 取全部 hunk，**按内容标记分类**（我的标记 vs 对方标记），**不要按行号/位置**——两边都会编辑，行号必漂移。
2. 判据要能失败：**任一 hunk 同时含两批标记 ⇒ 纠缠，拒绝执行**；**无法归类的 hunk 一律判红**，不静默丢弃；两批都必须被识别出来（否则分离可能在空转）。
3. 拼出只含我方 hunk 的补丁（保留原 diff 头），**双向负对照**：我的补丁不含对方任何标记、对方补丁不含我的任何标记；再加**增删行守恒**（两份补丁合计 == 原差异），防切 hunk 时丢内容。
4. 默认 dry-run，`--apply` 才 `git apply --cached <mine.patch>`；入索引后复核三件事：暂存差异不含对方标记、确含我的标记、**工作区仍保留对方那些行**（行数与对方补丁一致）。
5. 提交后再跑一次 `git status`，确认对方那批件数原样在工作区。本轮 15/15 PASS，两次提交都只加明确路径。

**Why:** 比「本轮不提交该文件、等对方落地」更推进得动，又不碰对方一个字节；比 `git add -p` 交互更可控且判据可复核。
**How to apply:** 共享文档/CHANGELOG/台账被两批同时改时优先用这套；纠缠或无法归类就停手回报，别硬切。

## `git fetch --tags` 的 exit 1 可能只是 tag 冲突，main 已经取到了（2026-11-15 实测）

远端 main 被另一作者推进 2 笔时，`git fetch origin --tags` 返回 **exit 1**，但日志里 `6cfdd7b..df058b4 main -> origin/main` **已成功**，失败只来自 `! [rejected] v0.1.5 -> v0.1.5 (would clobber existing tag)`——远端某个旧 tag 与本地同名 tag 指向不同对象。

**Why:** 把这种 exit 1 当「fetch 全失败」会误判为网络阻塞而反复重试或去开代理；反过来，用 `--force` 取 tag 会改写本地已有标签，违反「已发布 tag 不动」。

**How to apply:** fetch 后**分别核** `git rev-parse origin/main` 与 `rev-list --left-right --count origin/main...HEAD` 判断 main 是否真取到；tag 冲突单独留档点名、**不动任何已有 tag**，作为发现项交用户决定。分叉后做真合并（`git merge --no-ff origin/main`）而非 force；先用 `gh api .../compare/<mine>...<remote> --jq '.files'` 只读比对**文件重叠面**，零重叠即内容无冲突，但合并后仍要重建元数据（对方改了 SKILL.md 却没重建 manifest 是常见漂移）并在**合并后的最终 HEAD** 重跑放行门。

## 发版准备提交之后的 CHANGELOG 缺口（2026-11-13 实测）

`chore(release): prepare X` 那一刻写好的 CHANGELOG，**不会覆盖其后落地的提交**。本轮 0.1.6 节自 `0fc939e` 后再没更新，漏记了其后 **9 个**提交（守卫/备份/文档）。

**How to apply:** 出包前跑 `git log --oneline -- CHANGELOG.md` 取最后一次改动，再比对该提交之后的 `git log`，逐条补写；别假设「发版准备已写好 changelog」。补写时同样按上面的 hunk 分离法，只入自己的条目。

## 验证期间本地 main 被并行会话推进：推「已验证的 SHA」，不是 HEAD（2026-11-16 实测）

事实链：套件/门禁绑定 `6393b84` 跑了约 35 分钟，期间另一会话先提交 `20c6307`（比我的 merge 早 58 秒）⇒ 我的 `git merge --no-ff origin/main` 把**对方提交变成了 parent**，随后对方又提交 `f0829d5`。全绿后推送预检判红：`origin/main..6393b84` 会发布 **3 个提交（我的＋对方的＋合并）/ 15 个文件**，超出「只回流一个文件」的授权。

**Why:** 合并提交会把对方批次一起公开；"绿"绑定的是那个 SHA 的树而不是当前 HEAD；替对方发布中间态（其后续提交还没推）等于替它拍板。

**How to apply:**
- 推送目标写**已验证的那个 SHA**：`git push origin <gated-sha>:main`（快进、不 force），不写 `HEAD:main`。
- 预检断言要能失败：授权**提交集**与**文件集**逐字比对（多一件/少一件都红）、被推 SHA 是本地 HEAD 祖先、`origin/main` 是被推 SHA 祖先、`rev-list --count <sha>..HEAD` 的未发布余量点名、远端 main == origin/main（无新上游）、tag 的 **ref 对象 SHA** 推送前后逐字不变、远端文件字节 == `git show <sha>:<path>`。
- 发布对方提交属**新的对外批次**，必须弹窗。本轮用户选「授权连 20c6307 一起推」；随后又说「并行会话已停止，现在由你全权负责」⇒ 可修对方**已发布**代码，但工作树里第三条工作流（新技能目录＋catalog/manifest/docs 登记）的未提交改动仍不碰。
- **归属每轮重判**：上一轮的脏文件清单可能已被对方提交掉、又冒出另一批（本轮从 `catalog.json`+`package-dependencies.cjs` 变成 8 改＋2 个未跟踪技能目录）；不沿用上一轮结论。
- 套件与门禁都绿之后**仍要再核一次 HEAD 与 worktree 绑定**（head-before/after、status 行数）：绿 ≠ HEAD 没动。
