---
name: feedback-parallel-sessions
description: 同仓库多会话并行：提交/还原前先 git status 分辨改动归属，非本会话改动不碰；探针回滚先备份再还原
metadata:
  type: feedback
---

同一仓库可能有多个会话 / AI 工具并行改动。提交、还原、清理前先 `git status --short`，逐项区分「我这轮改的」与「工作区里本就有的」。

**Why:** 用户会开多会话并行改同一仓库。实测：提交自己的批次后工作区冒出别的会话的未完成改动（前端组件、探针文件）；冒然提交会把别人未完成的工作混进 commit，冒然 `git checkout` / `git restore` 会直接毁掉他人工作或自己的未提交编辑（两次实测：自己刚写的功能代码被一次 checkout 抹掉，只能凭上下文重放）。

**How to apply:**
- 提交前回顾本轮自己改过哪些文件（对照工具调用记录），只 `git add` 明确路径；**不用 `git add -A` / `git add .`**。
- 看到陌生改动（`zz-*.test.ts`、`*.probe.*`、临时脚本）先读内容判断来源，再给用户处置选项（留给原会话 / 我来验证后提交 / 部分提交），不替用户拍板。
- 共享文档里躺着别人未提交的相邻行时：**本轮不提交该文件**，把要写的行留到对方落地后补记，不动别人的行、不改他们的编号。
- 探针回滚固定动作：植入前先 `cp <file> <bak>` **留可还原的拷贝**（只存 md5 没用——只能证明丢了，不能还原）；还原用 `cp` 覆盖 + `md5sum -c` 或精确反向编辑；敲 `git checkout` / `git restore` 前先 `git diff --stat` 看会一起丢多少行，不是 0 行就换手段。

相关：[[feedback-delivery-hygiene]]、[[feedback-fix-and-sweep]]。


## 同一工作副本里有并行会话时的三条硬规矩（2026-10-08 实测补充）

1. **写任务必须收敛为单会话顺序执行**：本轮开工前 `svn status` 只有 5 个前端 `M`，一小时内变 8 个
   （`layouts/index.tsx`、`utils/request.ts` 等新出现）→ 说明另一会话**正在改**。
   判据：动手前后各跑一次状态命令比对**清单差异**，不要只比"有没有 M"。
2. **并发构建会污染证据**：前端改动的验收依赖 `npm run build` 产物与 dev server，
   两个会话在同一目录并发构建，产物哈希与 DOM 断言都无法归因 → 本会话直接**让出 `fronted/` 领地**，
   只替对方跑构建门槛（退出码 0）并写明"组件级行为未验 + 原因"。
3. **共享台账文件要"点名提交"**：`验收矩阵.md` 两个会话都在写。提交时**只列自己那几条路径**，
   并在提交说明里点名"连带入了对方写的 XX 措辞"（本轮 r41245/r41246 都这么写了），
   否则对方会以为自己的改动已入库，或误以为内容是你写的。
4. 追加文本进共享文件前先 `Read` 取**当前**内容再改：本轮按记忆里的旧措辞做精确替换连续失配 3 次
   （对方已把标题改掉），最后改成"落成文件 + `cat >>`/按行号 splice"的写法。

## 必须改"带别人未提交改动的文件"时（2026-10-12 实测）

删除/重构一个**正被别的会话改的文件**时（本轮：删本地用户栈必须改 `BuildProjectController`，而它带着他会话未提交的 `syncWorkflowStatus` 端点）：

1. **先查两件事再动**：`svn status <file>`（是否仍被改）+ `svn cat -r HEAD <file> | grep <符号>`（目标引用是**本就存在**还是对方新加）。本轮先误判过一次——以为 `sysUserService` 是对方新加的，实为已提交代码。
2. 只有"必须动它才能达成目标"时，**弹窗**给三选一：① 我改并**连同他的未提交改动一起提交**（提交说明里点名"连带入了对方 XX"）② 等他先提交 ③ 换不动该文件的替代方案。
3. 本轮用户选 ①：改动照做、提交说明显式点名对方改动，HEAD 保持可编译、进度不停。**默认不替用户拍板**（同 [[feedback-delivery-hygiene]]）。

相关：[[feedback-delivery-hygiene]]、[[feedback-fix-and-sweep]]、[[feedback-backup-before-modify]]。

## 只提交对方 feature 的"一个文件"会把 HEAD 弄挂（2026-10-12 实测）

对方会话的未提交改动常是**一个 feature 的多文件集**（本轮：`syncWorkflowStatus` = controller + service 接口 + impl + dao + mapper）。我为自己的改动（删本地用户栈）必须改其中的 controller → 只提交了 controller、**没提对方其余文件** ⇒ **HEAD 编译不过**（controller 调用的接口方法还在未提交的接口文件里；我本地能过是因为工作区带着对方的文件）。

**规矩**：一旦决定"连带提交对方文件"，就**把该 feature 的整个文件集一起提交**；或在提交前先 `svn cat -r HEAD <file> | grep <被调用符号>` 确认这些符号**已在 HEAD**。发现已造成 HEAD 断链，**立即补提整个 feature 集**并在说明里点名（本轮 r41295 补提，修复 r41293 引入的断链）。

**Why:** 共享工作副本里"我提交 A、对方留 B"看起来干净，但 A 依赖 B 的符号时，HEAD 就停在编译不过的状态，坑到下一个拉取的人。
**How to apply:** 提交前对"我改的每个文件"扫一眼它新调用/引用的符号是否都在 HEAD；不确定就整组提交并点名。

## 发布分支与标签的并行冲突（2026-11-04 实测）

发布过程中另一会话可能推送 main 和新 tag：0.0.23 发布时远端 main 先后被 0.0.24 提交推进两次，`git push origin main` 连续被拒。

**Why:** force-push main 会丢掉另一会话已发布的提交；发布后再移动 tag 会让已下载/已引用的资产与标签不一致。

**How to apply:** 推送前先 `git fetch origin`；main 落后就 `git merge origin/main` 解决冲突后再推，绝不 force；tag 只在**还没有任何 Release/资产**时允许重建，已有 Release 后不得移动；并行会话的正式发布标签（如 v0.0.24）不要覆盖。

## 推送前 HEAD 多了并行提交（2026-11-09 实测）

推送前复核 `git log origin/main..HEAD`，发现任务期间另一会话已在本地提交（auto-clean 改动），且工作区还留着它未提交的测试修复；用户最初授权的"推送本地提交"只指当时那批。

**Why:** 新提交属于另一会话，默认带走等于替对方发布；未提交的修复也不能由我提交或改动。

**How to apply:**
- 出现新提交就**重新弹窗确认推送范围**；只推原批次可用 `git push origin <目标sha>:main`（快进，不带后续提交）。
- 若对方正在修与本批门槛相关的测试（本次为 `codex-feedback` 失败用例），优先等它提交后一起推，并在推送前重跑全量。
- 2026-11-09 用户选择：**等并行会话提交修复后一起推**（不单独推原批次、不带走未提交改动）。

## 临时目录清理门禁会误把并行会话探针算成本轮产物（2026-11-09 实测）

自动清理（stop-gate R14 / `tmp-round-scan --since`）只按时间窗扫描，会把并行会话的探针目录算进"本轮产物"。实测：`D:\tmp\某系统_probe_20261109` 属于 `<项目目录>\某系统` 的会话 `dccd08dd-...`（task `某系统-preset-500-fix`），其 transcript 时 mtime 与当前时间只差 1 秒、目录仍在新增文件，而门禁连续两次要求 `--apply`。

**Why:** 时间窗只回答"何时出现"，不回答"谁创建、是否仍在用"；按窗删除会直接破坏另一会话正在进行的验证，且违反"并行会话共用临时根禁止按时间窗整根清理"。

**How to apply:** 先 dry-run 看清单；逐项查归属——临时目录里的 `verification_request.json` / 配置中的 `taskId`/`sessionId`/`workspaceKey`，或到 `~/.qoder/projects/**/<sessionId>.jsonl` 看 mtime；归属他人或所属会话仍活跃 → **保留**，在最终回复里写明"保留 + 原因 + 证据"，不执行 `--apply`；确认是本任务产物才用 `--only <精确路径>` 或 `--since` 清理。复扫后必须反馈删除/保留结果。

## 本地 main 夹带并行发布提交时（2026-11-09 实测）

推送前 `git log origin/main..HEAD` 发现本地 main 比远端多 3 个提交：并行发布会话的 `8ebb493`（0.1.1 发布准备）和 `11da2d5`，以及本会话的 `a63de92`；远端 main 只到 `2025191`。直接 `git push` 会把发布会话尚未完成全量验证的提交一起推上去。

**Why:** 用户只授权推本会话的 hook 提交；发布会话的 0.1.1 批次正在等全量套件，替它推送会干扰其发布节奏。

**How to apply:**
- 先 `git fetch origin` 并复核 `git log origin/main..HEAD`，按提交归属拆分。
- 只推自己的提交：`git worktree add <临时目录> origin/main --detach`，在隔离 worktree 里 `git cherry-pick <自己的提交>`，再 `git push origin HEAD:refs/heads/<独立分支>`；不动本地 main、不 force。
- cherry-pick 到旧基线可能出现冲突：本次 `CHANGELOG.md` 冲突块夹带了发布会话的中文条目；解决时**只保留本批新增条目**，把发布会话的 0.1.1 文案留在其分支，不要顺手带进独立分支。
- 推送前在隔离 worktree 跑全量；完成后 `git worktree remove` 并清理临时目录。
