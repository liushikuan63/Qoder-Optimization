---
name: tooling-playwright-probe-patterns
description: 用 playwright 写"能失败"的浏览器探针的六个实测要点：evaluate 只带函数源码（助手要挂 window）、Windows 下 ESM 导绝对路径要 file:///、canvas 应用输入走引擎自己的 EditBox、读数走场景图、截图必须肉眼过一遍、累积状态的探针第一次绿不算数
metadata:
  type: reference
---

用 playwright 写浏览器验收探针时（仓库里 `tools/verify-*.mjs` 那一族）实测出来的六个要点：

1. **`page.evaluate(fn)` 只序列化函数源码**：fn 里调用的其它模块级函数不会跟着过去，
   报错是页面上下文里的 `ReferenceError: findNode is not defined`，堆栈看着像页面自己坏了。
   写法：先 `await page.evaluate(installHelpers)` 把助手挂到 `window.__xxx`，之后
   `page.evaluate(() => window.__xxx.tap('Tab_chat'))` 按名字调 —— 顺带让每条判据都能单独重跑。
2. **Windows 下 ESM 里 import 绝对路径必须写 `file:///D:/...`**，写 `D:/...` 会直接
   `ERR_UNSUPPORTED_ESM_URL_SCHEME`（Received protocol 'd:'，堆栈说的是模块加载器，不是路径写错）。
3. **canvas 应用（Cocos/小游戏）的输入不要"往组件里塞字符串"**：先让输入框拿到焦点
   （`node.getComponent('cc.EditBox').setFocus()`），再用 `page.keyboard.type()` 真的敲，
   最后从组件读回字符串断言"吃到了" —— 这样才覆盖"输入框接线断了"这类缺陷。
   引擎自己建的隐藏 DOM 输入元素不适合直接 fill（它在编辑态才显示）。
4. **读数走场景图，不读 DOM**：`window.cc.director.getScene()` 递归 `node.children`，
   只统计父链激活（`activeInHierarchy`）的 `cc.Label.string` —— 池化归还的行仍留在场景里但
   `active=false`，不排除就会读到"上一页"的文字。读之前先 `waitForFunction(场景非空)`。
5. **截图必须肉眼过一遍**：本轮全部文本断言都是绿的，靠截图才发现新加的输入行压在底部导航条
   与页签行上 —— "文本读数全绿"证明不了排版，把截图路径写进汇报供人复核。
6. **会用累积状态的探针，第一次绿不算数**：聊天窗口"取最早 5 条而不是最新 5 条"的缺陷，
   在频道里还没有别人历史时是绿的，第二遍（同一个世界频道已有 7 条）才露头。
   要么每条判据自己造干净状态，要么至少复跑一次再下结论。

7. **复用同一个浏览器标签页时，控制台/异常事件会跨页面累积**：CDP `Runtime.exceptionThrown`
   收的是"连接期间该 target 发生过的所有异常"——上一页（甚至上一轮 dev server 页面）留下的
   XHR 失败会算进当前页的 errors 列表。2026-09-20 一次冒烟里就混进了 `127.0.0.1:43227`（已停的
   SVN dev server）的旧错误，差点误判新部署有问题。
   写法：**每进入一个页面先记 `errors.length` 基线，只取增量**判"本页零错误"；
   汇报里贴错误要用错误文本里的 URL/host 前缀确认归属，别直接引用累积列表首项。

8. **React 组件内部值用 fiber 取证（2026-11-20 实测）**：不落 DOM 的组件 props（如 antd 弹窗的隐藏 `type`/`proccessType`），从任一 DOM 节点的 `__reactFiber$` 键沿 `.return` 上溯读 `memoizedProps` 即得——弹窗 prop 从 `.ant-modal-content` 上溯 120 层内命中。注意**局部常量不在任何 memoizedProps 上**：页面组件里 `const options = {...}` 再塞进 `columns[i].valueEnum` 时，要上溯找 `memoizedProps.columns` 数组再取列的 `valueEnum`（直接找 `options` 这个 prop 名会返回 null）；fiber 行走必须设层数上限。配套：无头浏览器首次冷加载可 >45s（readyState 卡 loading→interactive），探针轮询要打印 url/readyState 诊断，别静默吞错直到超时；多语言页面的按钮文案以 locale 文件为准，别按中文语义猜英文标签。

9. **无头 CDP 实测四条（2026-11-23 流程图提速验收）**：
   - Fetch 拦截的 `urlPattern` 是通配匹配**真实请求 URL**：AlphaFlow 登录页是 `/static-page/login-sso/`（连字符），换票接口是 `/api/login/sso/app-user`（斜杠）——`*login-sso*` 只拦到前者，换票 XHR 被直接放行，表现为"慢载模拟没生效"的假绿。先打印 `Fetch.requestPaused` 的实际 URL 再定 pattern。
   - 测 `window.open`（如「在新窗口打开」）必须用 `Input.dispatchMouseEvent` 真实鼠标事件：`element.click()` 没有用户激活，弹窗被拦截，会误判"按钮无效"；真实点击后新 target 约 1s 落到目标路由。
   - antd Modal 一检测到内容就截图会拍到入场动画的 `opacity=0`（截图是底页）：拿到可见弹框后等 ~900ms，并断言 `.ant-modal-content` 的 `closest('.ant-modal')` computed opacity ≥0.99；`.ant-modal` 是父元素，别用 `querySelector('.ant-modal')`。
   - 证据文件名必须带环境（dev/prod）或把 `base` 写进 evidence JSON：同名 `native-zh-CN.png` 在 dev 与生产两轮互相覆盖，事后无法区分出处；dev HMR 期间 `.anticon-*` 会瞬时空缺，点击动作要包重试循环，不要一次 `.closest()` 就断言。

相关：[[reference-browser-use-viewport]]（用 browser-use MCP 而不是 playwright 时的同类经验）、
[[feedback-verify-fix-in-ui]]（前台改动必须真跑 + 截图）。
