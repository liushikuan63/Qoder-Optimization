---
name: feedback-dependency-verification
description: 优先复用现有依赖，新增包与扩展前核验来源、版本、接口及权限，不凭 AI 记忆安装
metadata:
  type: feedback
---

优先复用项目已有库和工具；新增依赖、Skill、插件或 MCP 前核验真实性、兼容性与权限，不能把 AI 推荐的名称或示例当作已验证事实。

**Why:** 用户于 2026-09-16 要求补充 AI 编码优化规则。GitHub 官方代理风险说明包含新增依赖安全检查；结合用户的稳定性优先和扩展全局复用偏好，采用来源核验与最小变更原则。该要求不代表当前工具具备 GitHub 产品的自动扫描能力。

**How to apply:**
- 先读取项目依赖声明、锁文件和现有用法；能用已有能力解决的问题不为方便引入新包。
- 对新增依赖查询官方文档、包注册表或可信市场，确认名称、维护来源、所选版本的 API、运行时兼容性和许可证适用性；未核验前不安装猜测包名。
- 核对可获得的漏洞与恶意包告警；无法扫描时说明验证缺口，不将“没查到”表述为绝对安全。
- 遵循项目既有包管理器与锁文件机制；只更改必要的依赖，不顺手升级全量依赖、不删锁文件解决安装失败、不绕过完整性校验。
- 安装或调用扩展前确认权限、联网目的地、数据范围和执行脚本；仅在已授权范围内操作，涉及额外权限、收费、敏感数据外发或工具要求确认时先确认。
- 常用扩展的全局复用遵循 [[feedback-auto-add-global-extensions]]；不因“全局化”而扩大权限、关闭安全检查或重复安装。

**参考来源（2026-09-16 查阅）：**
- [GitHub 代理风险与缓解措施](https://docs.github.com/enterprise-cloud@latest/copilot/concepts/agents/cloud-agent/risks-and-mitigations)
- [GitHub Copilot 代理责任使用说明](https://docs.github.com/en/copilot/responsible-use/agents)
