---
name: feedback-always-reply-in-chinese
description: 所有回复必须使用中文；commit/PR 说明语言跟随目标仓库惯例（上游英文、内网团队惯例）
metadata:
  type: feedback
---

每次回复必须使用中文。

**Why:** 基本沟通偏好；需要把"中文回复 + 提交说明语言分工"固化下来，避免每次重复交代。

**How to apply:**
- 所有回复、解释、总结、提问、报错说明均用简体中文。
- 代码、命令、文件路径、API/类/方法名、配置键、错误原文保持原文（英文），只在周围用中文解释。
- `git commit` message 与 PR 标题/描述的语言**跟随目标仓库惯例**：上游 / 开源仓库用英文（便于维护者评审）；内网仓库沿用团队既有语言。详见 [[feedback-delivery-hygiene]]。
