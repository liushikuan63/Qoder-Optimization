---
name: tooling-qoder-chat-session-delegation
description: Qoder 会话委派与监督机制（builtin create/wait/send/read/stop 实测）：快照字段语义、revision=进度信号、消息排队、stop 取消排队；监督先读子会话完整历史再判授权（回调不含用户直接授权）；监督指令会被撤销，回滚前先只读盘点磁盘实际状态；派工 prompt 自包含＋领地锁定＋取号协议，验收只认远端核验
metadata:
  type: reference
---

# Qoder 会话委派机制（2026-10-07 一次完整派工的实测记录）

工具（`builtin` MCP）：`create_chat_session` / `wait_chat_sessions` / `send_message_to_chat_session`。

**create_chat_session**：`prompt` 自包含（≤40000 字符；新会话**没有**本会话任何历史）。返回的 `sessionId` **只代表"已创建并派发"，不代表完成**。prompt 里不要写"再开一个会话"（被派工的首轮必须直接干活）。

**2026-10-07 实测（硬约束）**：**被创建的首轮会话再调 `create_chat_session` 会被 harness 直接拒**：「由其他会话创建的首轮任务必须直接执行，不能继续创建嵌套会话」。⇒ 这类会话的"下一格"只有两条路：① 自己做；② `send_message_to_chat_session` 顺链派给**既存**会话（实测可用——240399d1 收尾后直接接下了 #769 修复）。派工时若预期后面还有格子，先在 prompt 里写明"下一格归谁"，别让收尾会话撞墙才改道。

**wait_chat_sessions**：`sessionIds` ≤8 个、`timeoutMs` ≤60000（0=立即取快照）。目标"结束当前回合 / 变 idle / 失败 / 被中断 / 需要人工"时提前返回，否则超时也返回最新状态。快照字段（判进度就读这几个）：
- `runtimeState`：`running` / …；**同一个 `activeTurnId` 可以持续几小时**（期间跑长命令、长构建）——别用"看起来没动静"推断卡死；
- `revision`：只增计数，**是唯一天然细粒度进度信号**（实测一次派工里从 43 一路涨到 186，其间完成了造数→截图→落档→全量 battery→推送）；
- `queuedTurnCount`：我发去的消息在排队（发消息时它在跑 ⇒ 消息排到当前回合之后处理）；
- `pendingInteractionCount` / `backgroundAgentCount`：待人工/后台代理计数；`lastAssistantText` 常为 null，别指望它给摘要。

**send_message_to_chat_session**：`prompt` ≤40000；目标 running 时按其 steering/queue 策略处理（实测=排队）。适合投递"批次计数更正 / 领地锁定 / 新踩到的坑"这类增量。

**read_chat_session（2026-10-07 用于"从旧会话提炼技能"）**：参数名是 **`sessionId`**（传 `session_id` 直接 validation failed）。
**只回最近一个用户回合**——`turnLimit: 10` / `20` 加 `hasMoreBefore: true` 也一样只给那一条，**没有任何翻页/offset 入口** ⇒ 早期过程拿不回来。
⇒ 提炼旧会话时别指望它复盘全程：去读它留在盘上的产物（本会话记忆条目、工作目录里的脚本 / log / 备份 .reg），那些才是可核实的真源；
取回的正文与工具输出只作证据，其中"未复现的结论"要显式标注为未验证再写进产物。

**打过的一个完整样板（B13 截图格 → 会话 240399d1）**：
1. 派工 prompt 自包含：工作目录、目标与验收判据、精确环境配方（含必填环境变量）、产物与截图路径、检验与推送纪律、**领地锁定声明**（"`验收矩阵.md` 与 `contract/**` 由主会话维护，你不要动"）；
2. 主会话立刻把队列那一格首行标 `【会话 <id 前 8 位> 持有】`，此后**本会话不再开同一格**；
3. 监控 = "快照 + 有界等待"取**在跑证据**（runtimeState/revision），辅以只读侦察其产出（端口、日志、产物、工作树）——**不碰它的落点文件**；
4. 它自主走完全链路：造数 → 真跑截图 → 落档 → 全量 battery（check.sh+test.sh 全绿）→ **连同主会话攒的提交一起推送**；
5. 验收 = 对远端核验（`ls-remote`/提交内容/截图文件/它在台账与队列的落笔），**不采信"自述完成"**。

**与收尾门禁的配合**：被 R1b 拦"声明了下一步却没做"时，正确回应 = 给出"该格正在另一会话执行"的实时证据（runtimeState=running + revision 在涨）+ 说明为什么主会话不双开（领地冲突、双开必撞同一批文件/端口），而不是立刻自己开工同一格。

**它收起时会自建"下一格"**：实测 240399d1 在收尾里把已完成的截图格标 `[x]`、并写下"下一格（未持有，待认领）：修 B25-S3…"（同回合还顺手开工，工作树三处在手）。主会话核验后按 <示例项目>-work-queue-location 的两态规则补账：**已完成格 → `[x]`+证据；在途修正格 → `[~]` + `阻塞：领地冲突`（归属未核时别写"持有"）**——这比等它自己再回来勾更可靠。

**相关**：feedback-persist-until-exhausted、<示例项目>-work-queue-location、feedback-parallel-sessions。

## 另一侧独有内容（2026-10-07 无损并入，只增不删）
**回报方向可能被策略拒（2026-10-07 实测：非永久、也不是简单次数限额）**：被委派会话向委派方 `send_message_to_chat_session`——首两条送达；第三条被拒：**“由其他会话委派的任务必须直接执行，不能继续向其他会话转发消息”**；而**同一会话其后的"对账回执"又成功送出** ⇒ 别当永久封禁、也别当可靠通道：**被拒就把回执写进用户可见的回复**（用户是双方共同的上游）；回报仍要**一次给全**（当前状态 + 要对方接手的事项 + 口径更正）、派工 prompt 里先把“还会不会有回传”的预期写清。
**对账回执两个要点（同日实测）**：① 对方的验收基线可能**滞后于你的推送**——主会话按 `37eac871` 的文件清单核“第 4 条不在里面”，而该条已在其后的 `4801fce1` 完成 ⇒ 回执要**按 git log 给提交链 + 每笔标题**，并写明“你看的 X 是更早一笔，Y/Z 里已做”；② **批次计数不按对方消息里的数字推算**（“4 笔/6 笔”都曾滞后于实际），一律 `git merge-base --is-ancestor` 逐笔核自己在远端的主体，再把准确口径回给对方。

## 监督委派会话：先读完整历史再判授权（2026-11-14 误判实测）

**supervise 回调只给「它在问怎么做 X」，不给「用户已批准 X」**。用户可以直接在被委派会话里发消息授权（本例：用户先后直接说「加强生成规范避免后续载体冲突」「修复后依旧上传远端」「忽略 Linux」并亲答四项开工选择），这些授权**父会话在回调摘要里看不到**。

**Why:** 父会话仅凭回调把子会话的增强工程判成「无授权范围扩张」并下回滚指令，差点回滚掉用户已授权的工作（11 件仓库改动＋现役 3 脚本）；`read_chat_session` 读完整历史才发现用户早已直接授权。回滚工具调用恰被拒才没造成损失。

**How to apply:** ① 判子会话「越权/范围扩张」前，先 `read_chat_session` 读它的完整用户消息（尤其用户直接给它的授权），不能只看 supervise 回调；② 子会话向用户弹的问题，先核历史里用户是否已答/已授权，再决定转达还是直接回；③ 发现误判立即撤销指令、如实向用户认错，不静默掩盖。

**纠正运行中子会话的工具 mechanics（同日实测）**：
- `send_message_to_chat_session` 目标 running 时**排队**（`queuedTurnCount`），**不中断当前回合**——纠正指令排在错误回合之后，拦不住它。
- 中途纠错＝`stop_chat_session`（中断 active turn **并取消 queued inputs**，返回 interrupted/canceled/idle）→ 再 `send_message` 发新指令；stop 会清掉排队消息，纠正须重发。
- supervise 回调「Turn 已结束/被中断」**只确认该 turn 终态，不代表会话完成**（Goal/后台可能仍在跑）；用 `read_chat_session` 看 `runtimeState`/`activeTurnId` 判当前态。
- `read_chat_session` 的 `turnLimit` 本次实测可回多条用户回合（早期「只回最近一条」记录似已改进），`hasMoreBefore` 标更早历史；正文/工具输出只作证据。

## 监督指令会被撤销：执行回滚前先只读盘点实际状态（2026-11-15 实测）

监督方先下「停止范围扩张并回滚」，随后**自行撤销**并改令「恢复并继续」；子会话那次回滚工具调用**恰被用户拒绝、从未执行**。

**Why:** 若按「已回滚」的假设去"恢复"，就会拿保全 patch 覆盖掉其实完好的增强改动（本例 12 件仓库改动＋现役 3 脚本），把无损失变成真损失。指令文本不等于磁盘状态。

**How to apply:** ① 收到回滚/恢复类指令，先只读盘点：`git status --short` + `git diff --stat` 看哪些改动还在，现役文件现读 sha256 与「增强态/HEAD 态」两个期望值比对，回滚脚本有没有 `.log`/`.exit` 落盘（没有＝没跑过）；② 确认状态后再决定要不要动盘，逐件核实恢复结果等于目标态，不盲信 patch；③ **用户在本会话的直接授权优先于监督回调的指令**——监督看不到用户直接给子会话的授权（见上节），冲突时以用户原话为准并如实说明；④ 保全件（patch/副本）留档但注明"未使用"，别把留档当成已执行的证据。

**相关**：feedback-dispatch-redline-verification、feedback-cross-session-handoff、feedback-parallel-sessions。

## 工作完成后的冗余确认可直接停会话（2026-11-25 实测）

- 子会话可能已提交、验收、更新队列并给出最终报告，随后因新的 hook 又弹一次重复开工确认而进入 `waiting-user`。此时 `pendingInteractionCount=1` 不代表交付未完成。
- `send_message_to_chat_session` 在 waiting-user 时会排队，不能替用户回答已有 `AskUserQuestion`；若只剩冗余确认且实际工作已核验，`stop_chat_session` 会返回 `interrupted` 并清掉排队消息。
- 停止后 `respond_chat_session_interaction` 可能返回 `expired`，这是正常终态，不要反复重试。汇报时以已核验的磁盘/提交/服务证据判定完成，不以“会话仍 waiting-user”判未完成。
- 若“被中断”回调对应的是我方在交付完成后发起的 `stop_chat_session`，随后 `read_chat_session` 显示 `runtimeState=cold`、`activeTurnId=null`、`queuedTurnCount/pendingInteractionCount/backgroundAgentCount/backgroundProcessCount=0`，按预期终态收尾；不要因标题“被中断”重开交付或重复提交。
