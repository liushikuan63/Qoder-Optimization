---
name: codex-local-skills-migration
description: 2026-10-10 用户授权将 codex 本地缺失能力补充到 qoder：7 个 local-* 技能已迁移并验证
metadata:
  type: reference
---

**事实**：2026-10-10 用户更新 codex 规则/技能后要求"参考并加到 qoder"。codex evolution record `59ecd7c0` 记录用户原话："重叠较多的情况，将本地缺失的进行补充，依旧以本地为主。" 据此把 7 个 `local-*` 技能从 `~/.codex/skills/` 迁移到 qoder 真源 `D:\UserData\.qoder\skills\`（保留 MIT 许可与 SOURCE.json）。

**迁移的技能清单**
- `local-api-contracts` —— REST API 兼容、分页、错误与幂等设计
- `local-browser-e2e` —— 网页关键路径的 Playwright/浏览器验收
- `local-db-migrations` —— schema/数据迁移的兼容、锁、回填与恢复
- `local-frontend-a11y` —— 表单/弹窗/菜单的键盘、焦点与语义检查
- `local-performance-evidence` —— 性能/成本优化的基线、瓶颈与对照实验
- `local-rust-engineering` —— Rust 所有权、错误、异步并发与测试边界
- `local-spring-mybatis` —— Spring + MyBatis 事务、参数绑定、映射与查询

**验证**：迁移后 qoder 技能数从 109 增至 116；`skills-doctor.cjs` 未因新增技能产生新的 RED 项（既有 RED = CN 侧 description 过长 / YAML hazard / skill-trim 悬空引用，与本次无关）。

**来源与许可**：7 个技能来自 ECC/Compound Engineering 专项能力，按 MIT 许可适配为本地按需技能；LICENSE-ECC.txt / LICENSE-CE.txt 随目录一并保留。

**How to apply**：qoder 侧遇到对应主题任务时会从技能目录加载；这些技能的 description 已足够触发。注意它们是**按需**技能，不用于普通内部函数/纯文案/纯前端等无关任务。
