---
name: tooling-powershell-native-arg-splat
description: PowerShell 函数形参命名成 $args 会让 native 命令静默收到空参数、只打 usage 帮助且退出码 0（假绿）；判据是"看到帮助文本＝参数没传"
metadata:
  type: feedback
---

给 PowerShell 函数传"命令参数数组"时，**形参绝不能叫 `$args`**（`$args` 是 PS 自动变量，未声明的余下参数都装在这里）。实测：

```powershell
function RUN($label, $exe, $args) { $o = & $exe @args 2>&1 | Out-String }   # 错
RUN 'dism-scanhealth' 'dism.exe' @('/Online','/Cleanup-Image','/ScanHealth')
```

- **现象**：日志里 `EXITCODE| dism-scanhealth = 0`，看着是绿的；但紧跟的输出是 DISM 的**用法帮助**（`/Cleanup-Wim - 删除与损坏的已安装映像` 那类行），根本没做健康检查。整轮"扫描已完成"是假的。
- **根因**：`$args` 作为命名形参会被自动变量语义顶掉，`@args` 展开成空 ⇒ dism.exe 无参 ⇒ 打帮助 ⇒ 退 0。
- **正确做法**：形参改名（`$argList`），native 命令直接 `& $exe $argList`（数组会自动按元素展开成多个参数，不需要 splatting）。
- **判据要两件事**：外部命令的退出码 **＋** "本轮确实打出了该命令特有的结论行"（如 DISM 的"没有发现损坏的存储组件"/百分比进度行、SFC 的 `[SR]` 批次行、chkdsk 的"已扫描文件系统并且没有发现问题"）。**出现 usage/帮助文本＝参数没传到，必须判红**，不看退出码。
- **适用边界**：任何用封装函数批量跑原生 CLI（dism/sfc/sc/chkdsk/winmgmt/bcdedit/reg）的探针脚本；`Start-Process -ArgumentList` 与 `Invoke-Expression` 拼串同理。
- 关联：tooling-background-task-exit-code（判绿只认日志里显式记录的退出码）、feedback-checker-crash-vs-red（门自己的写法造成假绿）、reference-powershell-script-encoding。
