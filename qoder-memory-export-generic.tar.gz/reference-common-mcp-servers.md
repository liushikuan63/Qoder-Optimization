---
name: reference-common-mcp-servers
description: 常用 MCP 速查与已配示例：多库只读（dbhub）+ Context7；Windows 启动形式（node 直调优先）、配置位置与协议级验证流程
metadata:
  type: reference
---

# 常用 MCP 速查

配置位置：`~/.qoder/settings.json` 的 `mcpServers`（**官方用户级位置**，2026-09-18 官方文档确认；`~/.qoder/mcp.json` 实际未被使用）。改后 `/mcp reload` 或重开会话生效。

## 配置模板（Windows stdio——两种形式）

**优先：全局安装 + node 直调**（启动 1s 级，无 npx 冷启动不确定性）：

```json
{
  "mcpServers": {
    "<名称>": {
      "type": "stdio",
      "command": "<Node 安装目录>\\node.exe",
      "args": ["<Node 安装目录>\\node_modules\\<包路径>\\dist\\index.js", "<参数...>"]
    }
  }
}
```

**备选：`cmd /c` + 绝对路径 `npx.cmd`**（见 [[reference-windows-mcp-stdio-spawn]]）：

```json
{
  "mcpServers": {
    "<名称>": {
      "command": "cmd",
      "args": ["/c", "<Node 安装目录>\\npx.cmd", "-y", "<npm 包名>", "<连接参数...>"]
    }
  }
}
```

要点：npx 在企业网络下冷启动可能做 registry 校验、可超 90s（导致 MCP initialize 超时）——常用 MCP 一律全局安装后 node 直调；写完先做**协议级冒烟**（initialize → tools/list → 实测一次查询）再落盘。

## 数据库 MCP 速查（按技术选包）

| 技术 | 包名（来源） | 备注 |
|------|------------|------|
| PostgreSQL / 瀚高 | `@bytebase/dbhub`（npm，多库通用）或 `postgres-mcp`（PyPI） | 瀚高走 PG 协议，dbhub 通用性最好（已实测） |
| MySQL / MariaDB | `@benborla29/mcp-server-mysql`（npm）或 `@bytebase/dbhub` | dbhub 支持该引擎 |
| Oracle | 社区较少——用 `@bytebase/dbhub` 或先在市场搜索 | — |
| MongoDB | `mongodb-mcp-server`（官方 npm） | 配 `--connectionString` 或环境变量 |
| Redis | `redis-mcp-server`（官方 PyPI） | Python 系需 uvx 可用 |
| 通用/多库 | `@bytebase/dbhub`（PG/MySQL/SQL Server/SQLite）、Google `mcp-toolbox`（Docker，40+ 源） | dbhub 优先级最高（npm + 多引擎 + TOML 只读） |
| 分析型 | ClickHouse `mcp-clickhouse`、DuckDB `mcp-server-motherduck`（均 PyPI） | 按需 |

**选包纪律**：优先官方 → npm/npx 系（Node 可靠）→ 社区高采用。包名可能变动，配置前先在 npm/PyPI 或官方市场核实最新版本。

## 已配 MCP（2026-09-18）

### 1) dbhub —— 多库只读查询（PG 兼容库），已端到端实测

- **数据源**：（按你的环境填写；示例为 3 个 PG 兼容库）
- **工具名**：`execute_sql_<source_id>`（按 source 自动命名，`-` 归一为 `_`）；一个进程挂多源
- **只读**：TOML `[[tools]] readonly = true`（SELECT/SHOW/DESCRIBE/EXPLAIN/PRAGMA 之外全拒）+ `max_rows = 500`
- **写操作回退**（实测）：dbhub 只读不够时，用 Node.js pg 驱动从本机直连数据库（按你的连接参数）；无需 SSH 中转或 psql
- **DSN 明细**：`~/.qoder/dbhub.toml`（含密码，勿外传；`lazy = true` 首次查询才连接）
- **启动命令**（settings.json mcpServers.dbhub）：`<Node 安装目录>\node.exe` + `<全局 node_modules>\@bytebase\dbhub\dist\index.js --transport stdio --config=<用户目录>\.qoder\dbhub.toml`（dbhub@1.2.5 全局安装）
- **查询注意**：表在自定义 schema 下时需 schema 限定名

### 2) Context7 —— 文档检索（官方市场安装，http 型）

`settings.json` 的 `mcpServers.Context7`（市场自动写入 url）。

## dbhub 部署踩坑记录（2026-09-18 实测，避免重犯）

1. **`--config` 必须等号形式**：`--config=<路径>`；空格分隔不识别，会报 "Database connection configuration is required" 并退出。
2. **npx 冷启动慢**：本网络下 npx 可能每次做 registry 校验、超 90s——改用 `npm i -g @bytebase/dbhub` + node 直调后 initialize 仅 1.3s。
3. **半装状态假故障**：全局安装未完成时启动会报 `Cannot find module '...zod/v4/index.js'`——等 `npm ls -g <包>` 树健康后即恢复，别误判为包缺陷。
4. **协议级验证方法**（三步全绿才算配好）：spawn 后按行分隔 JSON-RPC 发 initialize → tools/list → tools/call 实测 `SELECT 1`；输出需脱敏后打印。

## 配置与验证流程（通用）

1. **读已有连接信息**：查记忆中的连接参考或问用户（一次问全：主机 / 端口 / 库 / 账号 / 密码）
2. **安装与冒烟**：优先全局安装；spawn 后协议级冒烟（initialize → tools/list → 实测查询）
3. **写配置**：写入 `~/.qoder/settings.json` 的 `mcpServers`；凭据只落 MCP 配置文件与既有凭据文件（如 dbhub 的独立 TOML），不扩散进规则 / 记忆正文 / 汇报
4. **生效**：`/mcp reload` 或重开会话；`mcp_list` 能看到该 server 的工具
5. **记录**：已配清单更新到本记忆（上节），供后续会话复用

相关：[[reference-windows-mcp-stdio-spawn]]、[[feedback-auto-install-domain-tooling]]、[[reference-qoder-global-setup]]
