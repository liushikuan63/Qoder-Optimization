---
name: reference-browser-use-viewport
description: browser-use 两条通道实测：① 内嵌浏览器——视口 hidden 首要根因=Qoder 侧边栏未开/会话不在主窗口（2026-10-16 口径），修法=调前台+开侧边栏，另有 navigate→screenshot、headless Edge/playwright 缓存 Chromium + Node CDP 无头出图（2026-11-19，零依赖）、动画时钟冻结；② 外部 Chrome（Browser Connector SDK，2026-11-26）——截图挂起首因=窗口最小化（restore 后 124ms 出图）、`evaluate` 恒 null、`reload()` 打死命令队列（SPA 用 hash goto）、窗口级兜底 WGC 非前台可截
metadata:
  type: reference
---

本机（Windows）用 browser-use MCP 做前端验收时的实测事实汇总（ + 2026-10-16 补）：

- **【2026-10-16 用户口径 · 首要排查项】视口 0×0/visible=false 的根因大多不是环境玄学，而是：① Qoder 侧边栏（内置浏览器所在面板）没打开；② 当前会话不在主窗口。** 修法：**操作电脑**（computer-use/cua）把任务窗口调到主窗口并**打开侧边栏**，再截图即恢复；不要再先重试 N 次截图浪费时间。以后遇到 `NATIVE_BROWSER_VIEWPORT_UNAVAILABLE` 一律先查这两点。


- **视口问题是间歇性的，不是永久的**：某轮 `take_screenshot` 报 `NATIVE_BROWSER_VIEWPORT_UNAVAILABLE`（viewport=0x0、visibilityState=hidden），**后续会话重试即恢复**（实测截图成功，视口 ~832×849；另一会话为 724×729，尺寸随会话变化勿硬编码）。截图失败先重试导航+截图，不要直接放弃视觉验证退回 DOM 断言。
- **同会话内视口 hidden 的修复手段（2026-09-18 实测）**：重试 navigate/reload/select_page 无效时，用 computer-use 插件 `list_windows` 找到 Qoder 主窗口 → `activate_window`（window 传完整对象 `{app, id, title}`，id 必须字符串）把宿主窗口调到前台，之后 `take_screenshot` 立即恢复，无需重开会话。（同日另一场景：尚未试到这招，computer-use 就整体被 browser_url_policy 停用，见下。）
- **失败态特征串**：报错文案为 `NATIVE_BROWSER_VIEWPORT_UNAVAILABLE ... (viewport=531x617, visible=false, attached=false, cdpAttached=true, visibilityState=hidden)`；本轮连续重试 3 次均失败，**再 navigate 一次同一 URL 后立即恢复**——"navigate → screenshot" 组合比单纯重试截图有效。
- **take_screenshot 参数白名单**：仅接受 format/quality/uid/fullPage/filePath，传 name 等额外键直接报 `params must NOT have additional properties`；要存档用 filePath。
- **局部放大看细节**：内嵌浏览器视口只有 ~531×617，全场景截图看不清细节。注入式改布局即可放大：`document.body.style.display='block'` + 给容器设内联宽度（如 `.stage{width:900px}`），再 `window.scrollTo(x,y)` 平移截取局部；注意 scrollTo 会被 `document.body.scrollWidth` 截断，别按想象的坐标算，需用页面里可辨识的固定元素（如太阳圆心+半径）反推当前缩放与可视区域。
- **SMIL 动画存活的可失败判据**：不用截图也能证明真在跑——隔 0.6s 读两次动画元素父级的 `getCTM()` 求 `Math.atan2(m.b,m.a)`（旋转角）与 `getComputedStyle(line).strokeDashoffset`（虚线偏移），两者都变化即证动画运行；比值单张静态截图更硬。
- **Element Plus 弹窗超高时的滚动**：对话框高于视口时，滚动容器是包装层 `.el-overlay-dialog`（`dialog.closest('.el-overlay-dialog')` 直接设 scrollTop），**不是** `.el-dialog__body`（overflow: visible）、不是 window（scrollY 恒 0）；且 `.el-overlay` 的 scrollHeight 可能虚报等于 clientHeight，别用它判断可滚。
- **弹窗消歧**：多弹窗并存（如"新增检测规则"+"浏览模板"）时，用 `d.querySelector('.el-dialog__title')?.textContent` 匹配目标弹窗；用 `textContent.includes(...)` 匹配会命中错误弹窗（表单弹窗文本里含"浏览模板"按钮文案）。
- **el-select 下拉**：所有 popper 的 options 都在 DOM 里（含隐藏的），先按 `offsetParent !== null && computed display !== 'none'` 过滤出可见 popper 再点选。
- **交互会改变弹窗状态**：点卡片"应用"后模板弹窗自动关闭——跨多次 evaluate_script 调用时每次重新查弹窗存在性，别缓存元素引用。
- **evaluate_script 用法**：参数名是 `function`（传 JS 函数声明字符串），支持 async；单次 MCP 调用 ~15s 超时，长流程拆成多次调用。textarea 与 input 的原生 setter 不同；`Illegal invocation` 多为 prototype setter 用错或对 NodeList 直接调方法。
- **本地静态 HTML 可直接预览验收（2026-09-18 实测）**：`navigate_page` 传 `file:///C:/...` URL 即可打开本地 HTML，无需 dev server；改文件后用 `{"type":"reload","ignoreCache":true}` 刷新生效。
- **CSS 动画的截图验收技巧**：单张静态截图验证不了动画是否在跑；间隔截两张图对比相位差异（如云朵位移、车轮辐条角度、烟团出现/消失）即可作为"动画真实运行"的可失败判据。SVG 内嵌动画元素（transform-box: fill-box + CSS keyframes）在此浏览器下工作正常。
- **视口 hidden ≠ 动画代码坏了（2026-09-18）**：内嵌浏览器面板未打开时页面隐藏，`document.timeline.currentTime` 恒为 0 不推进，所有 animation `playState` 仍 'running'，但 computed transform/dashoffset 两次采样不变——这是时钟冻结的环境态，不是动画没写对。判据：采样 `document.timeline.currentTime` 是否推进 + `visibilityState`，先判环境再怀疑代码。
- **computer-use 截浏览器窗口会被 URL 政策拦停（2026-09-18）**：对 msedge 窗口 `get_window_state` 报 `browser_url_policy / url_verification_required / insufficient_url_confidence`，消息明说 "Computer Use has been stopped for this turn" 并要求收尾时说明原因——Windows 下它无法高置信度确认浏览器 URL；此路不通别重试，整个 computer-use 本回合已停。
- **headless Edge 双帧截图验动画（2026-09-18 实测有效）**：拿不到内嵌视口时的视觉验收替代：`msedge.exe --headless=new --disable-gpu --no-first-run --no-default-browser-check --hide-scrollbars --user-data-dir=<临时目录> --screenshot=<绝对路径.png> --window-size=960,640 --virtual-time-budget=<ms> "file:///..."`，跑两个 budget（如 1200/1450ms）后 Read 两图对比相位（轮辐角、虚线相位、烟团位置）即证动画推进；**必须带独立 --user-data-dir**，否则并入已开的 Edge 会话（传 file URL + `--new-window` 也只提示"已在打开的会话中打开"）；验证完删除临时目录。
- **诚实降级**：实在拿不到视口时用 evaluate_script 程序化驱动页面并读 DOM 完成验收，并明确说"以 DOM 断言代替视觉检查"，不要谎报看到了界面。
- **SPA fallback 干扰**：`curl` 判断本地服务存活时，SPA 会把任意路径答成 `200 text/html`，必须用"不存在路径"对照组 + content-type / 特征串区分。
- **headless Edge 也能截 dev server（2026-09-30 实测）**：不必局限 `file:///`——`--screenshot` 直接打 `http://localhost:8081/...` 同样出真图（`--virtual-time-budget=6000~9000` 给 SPA 足够渲染时间）。内嵌视口彻底拿不到时这是可行的视觉验收路径。**局限**：无法预置 `sessionStorage`/`localStorage`（sessionStorage 不跨进程、cookie 无法从外部注入），所以**只能截"未登录"分支**；"已登录"分支仍需内嵌浏览器 + `evaluate_script` 断言。
- **用"两张 PNG 逐字节相同"做归因对照（2026-09-30 实测有效）**：页面上出现红/崩时，把改动文件临时换回备份版、重截同一 URL，`cmp` 两张图——**相同即证明该红与本次改动无关**。比读代码推理硬。注意：① 换回后要 `sleep` 等 dev server 热编译再截；② 用**独立的 `--user-data-dir`**（如 `edgeprof2`）避免缓存串扰；③ 验完立刻还原并 `cmp` 确认还原成功 + 关键改动标记仍在。
- **内嵌浏览器 sessionStorage 疑似跨 localhost 端口共享（2026-09-30）**：在 `:8081` 里 `sessionStorage.setItem('token', X)` 后，导航到 `:8082` 竟读到同一个 `X`。→ 多应用同机验收时**每次都要 `sessionStorage.clear()` 并回显确认**，且种子值用唯一串，否则判据被污染（实测踩到：一次"负向"结果里 token 仍在，但页面又被弹走，两个事实互相矛盾即为此因）。
- **pointer 动作（click）在无捕获面时也会被拦 → 改 evaluate_script 驱动（2026-10-12 实测）**：`NATIVE_BROWSER_VIEWPORT_UNAVAILABLE` 不只拦 `take_screenshot`，`click` 同样报错；此时用脚本选：antd `<Select>` 先对 `document.querySelector('.ant-select-selector')` 派发 `mousedown/mouseup/click` 打开下拉，再 `[...document.querySelectorAll('.ant-select-item-option')].find(o=>o.getAttribute('title')==='目标')` 派发点击。另：该回合 `mcp__browser-use__*` 曾短暂报 "Tool not found"，`mcp_list({keyword})` 后又可用——重试即恢复。
- **playwright-core + msedge 探针可预置 storage 并出真图（2026-10-12 实测）**：项目 `acceptance/` 自带 `playwright-core`；`chromium.launch({channel:'msedge',headless:true})` + `ctx.addInitScript(()=>sessionStorage.setItem('token',...))` 能截"已登录/需 token"分支（补 headless `--screenshot` 无法预置 storage 的短板），还可用 `page.on('request')` 数请求、`page.click('.ant-select-selector')` 真点。判断"是否真的整页刷新"用 `page.evaluate(()=>performance.getEntriesByType('navigation')[0].type)`。
- **`performance.getEntriesByType('resource')` 是"点击到底有没有发出请求"的干净判据**：比 `list_network_requests` 轻（可数差值、可按 URL 过滤），适合验证"菜单项点了有没有触发 effect"。配合 `it.offsetParent !== null` 过滤可见节点——反复 hover 后 DOM 里会残留**隐藏的旧弹层**，`querySelectorAll` 取到失效节点会导致"点了没反应"的假故障。

- **activate_window 前台≠面板展开（2026-11-20 实测）**：computer-use 把 Qoder 主窗口调前台成功（`foregroundStatus=matched`）后，browser-use `click` 仍报 `NATIVE_BROWSER_VIEWPORT_UNAVAILABLE (viewport=0x0, visible=false)`——内嵌浏览器**面板**未展开时窗口前台无济于事，别重复 activate 浪费轮次；直接走上一条 playwright Chromium + CDP 无头通道（workzone 项目实证：token 经镜像 `setup.html?to=<路由>` 注入，截图＋fiber 断言一次跑通）。
- **2026-11-05 生产验收恢复序列（实测）**：报 `NATIVE_BROWSER_VIEWPORT_UNAVAILABLE (viewport=825x785, visible=false, attached=true, cdpAttached=true, visibilityState=hidden)` 时，先用 computer-use `get_window_state` 对 Qoder 主窗口截一张窗口图（同时确认内置浏览器面板是否真的可见），随后 `take_screenshot` 立即恢复；再用 `filePath` 把页面截图落盘（如 `D:/tmp/<名称>.png`）留证。注意：窗口截图里能看到页面 ≠ browser-use 已恢复，必须另截页面图存档。

- **完全绕开内嵌面板的出图通道（2026-11-19 实测，第四次才走通）**：`NATIVE_BROWSER_VIEWPORT_UNAVAILABLE` 反复拿不到视口时，别再重试内嵌浏览器——用**本机 playwright 缓存里的 Chromium**（`AppData/Local/ms-playwright/chromium-1246`，或 `PLAYWRIGHT_BROWSERS_PATH` 指向的 `D:\dev-cache\ms-playwright`）以 `--headless=new --remote-debugging-port=94xx --user-data-dir=<独立临时目录>` 启动，**Node 24 原生 `fetch`＋`WebSocket` 直连 CDP，零新增依赖**。可用的关键调用：`Page.addScriptToEvaluateOnNewDocument` 注入 `sessionStorage`/`localStorage`（解决 headless `--screenshot` 无法预置票据与语言的短板）、`Emulation.setDeviceMetricsOverride`（`deviceScaleFactor:2` 出 2× 放大图）、`Page.captureScreenshot` 的 `clip` **必须带 `scale`**（漏了直接报错）、`Input.dispatchMouseEvent` 发真实指针。三条实测边界：① 等页面就绪要**轮询特征**（如表格行数），固定 7s sleep 会截到骨架；② 导航期 `Runtime.evaluate` 会抛执行上下文错误，要按 label 容错重试；③ **无头态 antd `<Select>` 发了真实三件套点击后仍判 `{"open":false}`**，下拉展开面板截不到——展开列表的正确性改用接口层读数覆盖，整页表单图（含选中值）作像素证据。收尾：profile 目录含注入票据要**永久删除**（不进 `.trash`），业务截图 PNG 含真实数据故不入版本库、移入带 `.evidence.json` 登记的证据目录。

相关：[[feedback-verify-fix-in-ui]]。

## 2026-11-24：Qoder 主窗口截图可作内嵌浏览器视觉证据
- 即使 computer-use 已把 Qoder 主窗口调前台，browser-use 的 `click`/`take_screenshot` 仍可能报 `NATIVE_BROWSER_VIEWPORT_UNAVAILABLE`；此时不要反复重试页面截图。
- 用 computer-use `get_window_state({include_screenshot:true})` 截 Qoder 主窗口，能看到实际内嵌浏览器页面时，可作为视觉证据；交互继续用 evaluate_script 驱动 DOM，行为用 network/接口结果交叉验证。
- 汇报时注明证据来源是“Qoder 窗口截图”，不要冒充 browser-use 页面截图；窗口截图能看到页面也不代表 browser-use 视口已恢复。
- 需要留档时用 cua-driver `get_window_state` 的 `screenshot_out_file` 直接写 PNG，并配 `.evidence.json` 登记 SHA256 与 expected/observed 比对结论；完整配方见 [[tooling-windows-window-capture]]。

## 2026-11-26：外部 Chrome（Qoder Browser Connector + browser-use SDK）通道实测

与上文"Qoder 内嵌浏览器"是**两条独立通道**：外部 Chrome 走 `node_repl` 里的 `createBrowserAgent()`，`take_screenshot` 那套 MCP 工具连的是内嵌浏览器。本轮 某编号 线上三张真实截图由外部 Chrome 通道取得。

- **`tab.screenshot()` 长时间挂住（>60s 不返回）的首要根因＝目标 Chrome 窗口被最小化**，没有可绘制表面。实测：窗口最小化时截图 77s 无返回；用 computer-use `activate_window`（`restore:true`）把窗口恢复后，**同一调用 124ms 返回 67KB PNG**。所以截图挂起先 `list_windows` 看 `isMinimized`，别怀疑页面或网络。
- **扩展 1.7.7 不支持 `tab.activate()`**：报 `Unsupported Browser Agent command: activate_tab`。截图不需要标签激活（SDK 截图按标签取图，能截到非最前标签），**不要为了截图去抢用户前台**。
- **`tab.evaluate()` 在该扩展恒返回 `null`**（能力未开放，`apiSupportOverrides` 里只有 `Tabs.content` / `Tab.ax` / `Tab.requestManualHandoff`）。读页面文本改用 `tab.innerText('body')`、`tab.locator(sel).allInnerTexts()`、`tab.locator(sel).inputValue()`。
- **串行命令队列会被一条不返回的命令占死**：对重页面（撤销审核页内嵌工作流 iframe）执行 `reload()` 后，后续所有命令——包括最轻的 `tab.url()`——全部超时；`createBrowserAgent()` 重建 agent 与 `browsers.list()` 仍通，但标签级命令持续 TO，最终报 **`Tool command queue quota is full for this relay`**。可失败判据：队列恢复后 `tab.url()` 在 200ms 内返回。
  - 规避：**SPA 验收不要用 `reload()`**，改 hash 路由 `goto()` 即可让前端响应；`innerText` 一类要跑页面主线程的命令，在重页面上用 `Promise.race` 加超时包住，避免把通道打死。
- **`NATIVE_BROWSER_VIEWPORT_UNAVAILABLE (viewport=0x0, visible=false, cdpAttached=true)` 是内嵌浏览器侧的报错**，与外部 Chrome 无关；那条路要用户打开 Qoder 侧边栏（见上文 2026-10-16 口径），外部通道可用时直接切外部，不要在两条通道间反复试。
- **窗口级兜底**：computer-use `get_window_state({include_screenshot:true})` 用 Windows 图形捕获，`occlusionSafe:true`，**窗口不在前台也能拿到像素图**（`activate_window` 可能被宿主前台锁拒：`foregroundStatus:"blocked_after_restore"`，此时截图仍成功）。代价＝只能截**最前标签页**，且带浏览器 chrome。配方细节见 [[tooling-windows-window-capture]]。
- **语言 URL 口径只在一侧成立（2026-11-26 修正）**：`index.html#/route?language=am-ET` 在**整页加载**时生效并**同标签内跨路由保持**（切路由仍是阿姆哈拉语，按钮变 `ምርምር`/`ወደ ውጪ ላክ`/`ዳግም አስጀምር`）；但**同标签内 hash 导航切不回来**——`fronted/某系统-TLE/src/index.ejs:13-19` 只在 document 解析时读一次 hash query 写 `sessionStorage.lang`，Playwright `goto()` 换 hash 属同文档导航不重跑该脚本，所以 `?language=zh-CN` 追加在后面**无效**。要中文态就得**新开标签整页加载**（sessionStorage 是标签级）。副作用：按中文按钮名 `getByRole('button',{name:'查 询'})` 会 0 命中——**先 `allInnerTexts()`/`innerText('body')` 读实际文案再定位**。
- **antd 3 DatePicker 单元格 `title` 是中文格式（2026-11-26 实测，解掉上一轮 0 命中悬案）**：`td.ant-calendar-cell[title]` 取值为 `2026年11月1日` 而非 `2026-11-01`，按 ISO 串选日期必然 0 命中；且 `locator.fill('2026-11-01')` + `Enter` **不提交**（受控值回滚成原值），唯一可行＝点开面板后**点真实单元格**（选择器里用 `\u5e74/\u6708/\u65e5` 转义避免中文进 JSON）。可失败判据＝点完回读 `inputValue()` 已变成目标日期。
- **agent 建的标签在 Turn 结束自动关闭**：`tabs.list()` 下一轮返回 `[]`，`tabs.close()` 并不是函数（报 `is not a function`）——别为"清理垃圾标签"找 API，也不要把"留个标签给用户看"当成会生效的交付；要留档就**落盘截图 + `.evidence.json`**（内联 `emitImage` 会随会话压缩丢失）。
- **`node_repl` 有界执行**：单元格默认 10s 让出为 `status:"running"`+`cell_id`，须调 `node_repl_wait`（参数只有 `cell_id` 与 `yield_time_ms`，**传 `timeout_ms` 直接校验失败**）。重页面一次 `screenshot`+`innerText` 组合常在 15–50s 才回，出现一次 TO 即停手，别连压三四条（第 58 行的队列打死就是这么来的）。
