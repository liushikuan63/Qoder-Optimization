---
name: edge-browser-cannot-load-pages
description: 本机 Edge「动不动打不开网页」的实测根因＝Watt Toolkit hosts 劫持一批域名 + 其回源抖动；量具 /edge-net-check；手改 hosts 会被 Watt 自愈
metadata:
  type: reference
---

# Edge 动不动无法访问网页 —— 根因与量具（2026-09-24 实测）

**结论**：不是 Edge 的缺陷。是 **Watt Toolkit（Steam++）3.1.0** 的 hosts 加速模式把 **一百多个域名**
指向 `127.0.0.1` 由本地 80/443 MITM 回源，而该回源线路**抖动极大**，页面资源域被拖到 7–29 秒。

## 决定性证据（可失败，同刻对照）

| 观测 | 数值 |
| --- | --- |
| `github.githubassets.com` 同一域名重复实测 | 138ms / 774ms / 2028ms / 7035ms / **9018ms 超时** |
| GitHub 首页 114 个资源（走劫持） | 每个 **28858ms**；同页主文档 TTFB 仅 1140ms |
| 直连真实 IP（绕过 hosts） | `github.com` 305ms、`githubassets` 823ms、`avatars` 2084ms |
| 直连确实不通（真需要加速器） | `raw.githubusercontent` 3376ms、`objects.githubusercontent` 7594ms |
| 非劫持对照 | `www.baidu.com` 73–336ms、`www.qq.com` 72ms |
| 同被劫持但不慢的族 | imgur 系 1.1–1.7s ⇒ 抖动是 **GitHub 资源域专属**，不是 hosts 通用开销 |

## 已排除（各自有证据，别再查）

- **DNS**：路由器 `<内网IP>` 解析 18–696ms，`223.5.5.5` 19ms；无 DNS-Client 错误事件。
- **DoH**：Edge `Local State` 里 `dns_over_https.mode = off`，无 Edge 策略键。
- **证书链**：MITM 叶子证书 AKI `9C:01:79:3F…45:2D` == 有效根 `7C296976`（notAfter 2026-12-14）。
  库里另有一张**过期**根 `56077FBD`（2026-02-17）但**不是当前签发者**，属残留、非故障源。
- **路由**：唯一默认路由 `<内网IP>`；`vgate0`(<内网IP>/32) 未抢路。
- **崩溃**：`%LOCALAPPDATA%\CrashDumps` 无 Steam++/msedge 转储，近 14 天无相关错误事件。
- **升级**：GitHub `releases/latest` = **3.1.0（2026-03-11）**，本机正是 3.1.0 ⇒ 无稳定版可升。

## 两个引信

1. **仍在（拆除无效）**：注册表残留 `ProxyServer=127.0.0.1:10809`（端口无监听）。本轮删掉它之后
   **Watt 又把这个值写了回来**（22:20 复测 `ProxyServer=127.0.0.1:10809` 存在）⇒ 手工清值不是持久手段，
   只有让 Watt 自己退出才会消失。危险形状与浏览器级 A/B 证据（仍然有效，只是"已修"不成立）：
   - `ProxyEnable=1` + `ProxyServer=127.0.0.1:10809`（端口死）⇒ Edge `fetch` 百度 **`ERR:TypeError`（必炸）**
   - `ProxyEnable=1` + `ProxyServer` **缺失** ⇒ Edge 走直连 **78–95ms 正常**（⇒ 删值才是起作用的动作）
   - 回滚点：旧临时根中的 `wininet-reg.bak-20260924-210122`（已随 2026-11-09 临时根清理删除，需要时用 `reg export <键> D:/tmp/wininet-reg.bak-<时间戳>` 重新导出），可用 `reg load HKU\_rbprobe <文件>` 反读校验
     （PowerShell 里挂在 **`HKU:\`** 下，不是 `HKCU:\`；用完必须 `reg unload`）。
   - 量具的该分支做过植入必红/还原必绿双向自测，不是空跑。
2. Watt `AutoRunOnStartup=true`：开机即恢复该批域名劫持。**手改 hosts 无效**——实测把 70 条
   注释掉后数秒内被 Watt 自愈重写回生效项（文件从 218 行涨到 288 行、出现重复条目）。
   ⇒ 收敛劫持面只能在 **Watt 界面关掉对应服务的加速**，不能改文件。**此项仍未执行**（见文末）。

## 量具与回滚

- 一键定性：`/edge-net-check` → `node ~/.qoder/scripts/edge-net-check.cjs`（只读，含代理/hosts/
  加速器存活/完整 HTTPS 请求耗时四段与判红行；对照组按证书 issuer 区分 MITM 与真实站点）。
- hosts 改前必须 `Copy-Item` 整份备份 + `cmp` 逐字节校验，还原同法 + `Clear-DnsClientCache`。
- 写 hosts 用 latin1 读**且写**可保字节不变；插入的标记串**必须纯 ASCII**（中文标记会被 latin1
  截成 `?`）；改行时**不要 trim()**（会吃掉 CRLF 的 `\r`），只在整行前加前缀。
- 探针教训：只量 TLS 握手会**假绿**（握手 9–292ms 全绿，而完整 HTTPS 请求 9s 超时）——
  浏览器卡顿类判据必须量到"拿到响应"，不能停在握手。

## 待你拍板的修法（弹窗两次未选，安装/退出应用属难回退动作故未擅自动手）

- **收敛劫持面**：在 Watt 界面只保留真用的服务（`googleapis / gstatic / bootstrapcdn` 不再被劫持，
  普通网站即与加速器存活解耦）；GitHub 资源域抖动仍在。
- **绕过 Watt**：退出 Watt 后实测 `github.com` 305ms、`githubassets` 823ms（比走 Watt 更快更稳），
  代价是 `raw / objects.githubusercontent` 需改由真实 IP 块接管，且 Steam/Roblox/Docker 加速停。

## 22:20 二次复现与结论更正（重要，覆盖上文两处说法）

- **满档复现**：劫持三域同时 `9437 / 9406 / 9342ms 超时`，对照直连 123/326ms。
- **"摘掉 Watt 就快" 是错的**：杀掉 Watt 并删掉 `# Steam++` 块后（三条断言 PASS、只剩 Docker 自有一条），
  GitHub 首页 133 个资源**直连中位 14553ms、页面 23395ms**——比走 Watt 只好一点，且丢了 raw/objects 的可用性
  ⇒ **已按哈希回滚**（`hosts.bak2-222029`，线上文件与备份哈希一致；Watt 已重启、443 恢复监听）。
- **"重启 Watt 即修复" 也是错的**：随后测得 `load_ms=2330`、138 个资源中位 **0ms** ⇒ 那是 **HTTP 缓存命中**，
  不是网络恢复。冷域名探针（每次新建 TLS + 无 HTTP 缓存）同域一分钟内 `3753/5023ms` 与 `2323/1531ms`
  ⇒ 结论只能是：**该路径在 0.1–9.4 秒间剧烈抖动**，与是否重启无稳定因果。
  教训：**页面加载耗时要先排除缓存**（资源中位数 0ms = 命中缓存，该读数不能用于证明网络改善）。
- **仍成立的主因**：Watt 把该批域名（含 `googleapis.com / gstatic.com / bootstrapcdn.com`）劫持到本地 MITM，
  该路径抖动 + Watt 未运行时全部直接连不上 ⇒ 这就是"动不动"。
- **唯一能真正缩小受害面的动作**（需 Watt 界面，本会话 computer-use 插件不可用，无法代点）：
  实测可安全交还直连的有 **72 条 / 19 个主域**，其中 `googleapis.com` 188ms、`gstatic.com` 304ms、
  `bootstrapcdn.com` 752ms、`hcaptcha.com` 784ms、`roblox.com` 25 条 1118ms ⇒ **优先关掉 Google 组加速**
  （普通网站大量引用它，关掉即与 Watt 存活解耦）；**GitHub 服务要留着**（并发下走 Watt 优于直连）。
- 工具已加 `--fix`（判红时重启 Watt 并复测），**负向对照已验证**：无判红项时明确"不动任何进程"；
  `--fix` 的重启分支本身未在真实判红状态下端到端跑过 ⇒ **该分支未验证**。

## 交付物（双击即可，2026-09-24 收尾）

- **桌面脚本 `<用户目录>\<user>\Desktop\浏览器打不开-双击修复.bat`**（2.3KB，CRLF + `chcp 65001`，正文纯 ASCII）：
  `[1] 只体检` / `[2] 体检+试重启 Watt`（回车默认）/ `[3] 双路对比出清单`。日志写 `D:\tmp\edge-doctor-*.log`，
  可用环境变量 `DOCTOR_LOG` 指定路径。三条路径都已真实执行验证（退出码 0、日志 UTF-8 可 grep）。
  **未做视觉验证**：本会话 computer-use 插件被移除，PowerShell 抓控制台窗口三次失败（脚本块转委托 + 中文路径），
  只能以真实 cmd 进程的标准输出与 UTF-8 日志代替。
- 后端脚本：`~/.qoder/scripts/edge-net-check.cjs`（含 `--fix`）、`~/.qoder/scripts/gh-accel-plan.cjs`（六桶对比，自带
  `合计全部用例 PASS` 覆盖校验）。
- **22:50 六桶实测**（同刻双路，一百多个劫持域）：立刻交还直连 **11** 个（roblox×7、githubusercontent×2、steamstatic、github，
  全是 `Watt ETIMEOUT` 而直连可用）；值得交还 **29** 个（roblox×19 5716→1214ms、arkoselabs×3、github.com×2、
  **gstatic 1853→167ms / googleapis 1586→612ms / google.cn 2116→168ms**）；保留加速 **88** 个（artstation/imgur/dropbox
  直连根本不通）；两条都不通 **15**；两条接近 **26**。
  ⇒ 最划算的两下：**关掉 Roblox 与 Google 组加速**（合计 40 条），普通网站立刻与 Watt 解耦；**GitHub 加速留着**。
- **重启 Watt 不治病（已实测）**：`--fix` 在真实判红态端到端跑过两次，`9197ms -> 9367ms`、`7203ms -> 9437ms`，
  都是"仍未恢复" ⇒ 脚本选项文案已改成"仅当转发进程卡死时有用"，不再宣称自动修复。

## 两条工具编写教训（本轮踩到）

- `Tee-Object` 在 PS 5.1 默认写 **UTF-16**，日志中文 grep 不到 ⇒ 批处理里改成 `node ... > "%LOG%" 2>&1` + `type "%LOG%"`，
  日志就是 UTF-8 且控制台照常回显。
- 用正则给批处理打补丁把 `%S%\edge-net-check.cjs` 写成了 `%S%\%S%\...` 且漏改一行 ⇒ **整份重写**，别打行级补丁。

相关：`github-access-setup`、feedback-pseudo-verification-shapes、feedback-checker-crash-vs-red
