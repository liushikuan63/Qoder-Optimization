---
name: reference-windows-mcp-stdio-spawn
description: Windows 上配 stdio MCP 的唯一可靠形式：cmd /c + 绝对路径 npx.cmd；直接 spawn npx=ENOENT、.cmd 直连=EINVAL
metadata:
  type: reference
---

Windows 上配 stdio MCP，三种启动形式实测（`child_process.spawn` 参数数组语义，与 MCP 启动器一致）：

| 形式 | 结果 |
| --- | --- |
| `{"command":"npx","args":[...]}` | **ENOENT**——npx 是 .cmd 垫片，不能直接 spawn |
| `{"command":"D:\\...\\npx.cmd","args":[...]}` | **EINVAL**——Node 20+ 安全策略禁止无 shell spawn .cmd/.bat |
| `{"command":"cmd","args":["/c","D:\\...\\npx.cmd",...]}` | **STARTED OK** ✓ |

**结论**：Qoder 里配 stdio MCP（`~/.qoder/settings.json` 的 `mcpServers`，或 `~/.qoder-cn/settings.json`），用 `cmd /c` 包一层 + **绝对路径**的 npx.cmd——既不依赖 PATH 顺序，也绕开 Node 的 .cmd spawn 限制。

**How to apply**：写入配置前先用 node 脚本以参数数组形式 spawn 目标形式做冒烟测试（期望看到 server banner 且进程存活）；内联 `node -e` 会被 shell 吃反斜杠，落成 .js 文件跑。

**补充（2026-09-18 实测）**：npx 在企业网络下冷启动可能做 registry 校验、可超 90s（导致 MCP initialize 超时）——**常用 MCP 优先"`npm i -g` 全局安装 + `node.exe` 直接运行 dist 入口"**（启动 1s 级；dbhub 全链路实测通过，见 [[reference-common-mcp-servers]]）；`cmd /c` + npx.cmd 形式保留为一次性/冷门包的备选。冒烟测试升级为**协议级**：initialize → tools/list → 实测一次查询，三步全绿才算通。

相关：[[reference-qoder-global-setup]]、[[reference-common-mcp-servers]]。

**接线生效时机（2026-10-14 实测）**：settings.json 加/改 `mcpServers` 后**运行中的客户端不热加载**——会话里 `mcp_list` 查不到新 server、但两侧接线逐字节一致时，这是"未重载"的已知状态、不是故障（workflow-ops 实例：接线完好、会话查不到）。自证服务端可用：`node src/index.js` 手动跑 initialize → tools/list JSON-RPC 三步；发现性验证留到客户端重启之后。另：`node -e` 写 settings.json 会被 shell 吃反斜杠，路径一律用正斜杠（`D:/software/node24/node.exe`）。
