---
name: qoder-optimization-share-package
description: 分享包的组成与维护：开源版 Qoder-Optimization 0.0.x→0.1.0（最新 0.1.0，2026-11-09 完成审阅流程修复的三路合并部署；含 pack-share-docs 会重写 curated 第二节的坑、pkg-diff skills→skills-library 映射、drift 分组呈报与更新实录）；可分享版规则文档 + 个人规则提示词 + 记忆导出包；真源在 ~/.qoder{,-cn}，文档需跟随真源同步
metadata:
  type: reference
---

**开源版 0.0.1（2026-10-28，更名 + 开源首发）**：
- 更名：分享包由《Qoder 优化》改为 **`Qoder-Optimization`**，版本线由 5.x 重置为 `0.0.x`，首版 `0.0.1`（2026-10-27 构建，包内 `VERSION=v0.0.1`）。发布目录由用户指定；历史版仍在桌面，目录名带版本号，打包脚本对新旧命名双兼容。
- 实测构成：zip 37.8 MB / 499 条目 / 顶层目录 `Qoder-Optimization - 0.0.1/`；`catalog.json` 222 条 = skill 123 / script 87 / command 10 / agent 2；同目录另发 3 份配套文档（作品说明 / 使用说明与目录结构 / 技能与命令清单）。包内是白名单子集，不等于本机全量（本机 135 技能 / 89 脚本 / 10 命令 / 2 agents）。
- 链路同批改：`check-share-docs.js` 的默认发现与 `prune-share-packages.cjs` 的默认前缀都改成双名兼容（新名 `Qoder-Optimization - x.y.z` + 旧名）；`/update-share-package` 与分诊技能口径改为 `0.0.x` 线递增。
- 出包底线不变：目录名 / zip 名 / 包内 `VERSION` 三处同版本；四道验证 exit=0。

**开源版发布流水线（2026-10-28/29，0.0.2–0.0.3 实践）**：
- 构建入口 `node .github/build-release.js <tag> <外部目录> <ref>`：**ref 只接受 `HEAD` / tag / 完整 40 位 SHA，传短 SHA 或分支名直接 `BUILD_FAILED`**；产物 `build.json` 含 commit/tag/package/sha256/files，`sha256` 可与 GitHub Release 资产的 digest 直接比对（同 commit 本地构建 = 远端资产是强证据，但仍不等于"下载件复验"）。
- `check-release.js` 的 `checkRelease(dir, tag)` **只能对构建/解包后的包目录跑**；对工作区跑会把 `.bak`、队列文件、node_modules 全算成 `unexpected release file`（实测数千条），不要据此判红或判绿。
- tag push 触发的发布曾在 gate（README 计数未同步）和 publish（`invalid remote release metadata`，draft 可见性问题，见 reference-github-access-and-repo）两处失败，最终由 **workflow_dispatch 在同一 draft 上补发成功**；下次发版前先在 dispatch 路径演练一次，别默认 tag push 一定绿。
- 发布后仍要做"真下载 → 全包复验"（包名/文件集/逐文件哈希/checkRelease/README 双链接计数/消费者注册/技能脚本安装/loader 正负路由），脚本模板见 `D:/tmp/QO-REL-*` 现场。

**0.0.4 发布实录（2026-10-29）**：核心包与 `mcp/offline/` 拆成两个 ZIP（核心 ~1.6MB、离线 ~36MB），各带 `.sha256`，同一提交各自校验、并集合计覆盖全部 343 文件。两个只在发布期才暴露的坑：① **gzip 头第 9 字节是平台标识**（Windows 10 / Unix 3），记忆归档的"按字节一致性"检查因此在 Linux CI 上必红——生成与校验都归一化为 255 再比，内容仍逐成员校验；② draft 无法按 tag 查回（`/releases/tags/` 对 draft 404，且列表可见性受 token 影响），`gh release create` 又不返回 id，**改为 `gh api -X POST /releases` 取返回 id、后续上传/发布/确认全部按 id 复查**；`gh release edit --draft=false` 同样换成 `PATCH /releases/<id>`。两者都有正反例测试（`release.test.js`）。

分享包目录（新名 `Qoder-Optimization - x.y.z`，每轮实质更新自动递增；2026-10-28 起为开源版 `0.0.x` 线）→ 5.0 / 5.1 → **5.3.1（对方演进版，回发）→ 5.4（2026-10-12，以 5.3.1 为基线并入本机后重打）→ 5.4.1（2026-10-13，office-docs 技能 bug 修复）→ 5.4.2（2026-10-13，office-docs 补「插入表格」链路）→ **5.4.3（2026-10-14，cua 升级 + 备份保留策略 + 规则审阅落实）→ 5.4.4（2026-10-14，磁盘「清理+迁移」触发面补齐 + 五处漂移修复）**——`Qoder-AI编码通用规则.md`（可分享版，脱敏改写）+ `Qoder-个人规则生成提示词.md` + `qoder-memory-export-*.tar.gz`（通用记忆示例包）+ `skills/`（自建技能，`pack-share-extras.js` 打入）+ `mcp/`（MCP 配置模板：占位符版、无凭据）+ `scripts/`（机制脚本白名单）+ `commands/`；改版前在同级留 `_backup-<日期>-*/`。

**5.6.1 打包实录（2026-10-27，任务检查强化 + 守卫误拦修复）**：
- 基线 `Qoder 优化 5.6.0` 复制为 5.6.1；5.6.0 目录与 zip 留回滚点。变更：R9 主张-证据核对 / R3 改动面驱动 / R2 真实备选口径（与六项例外对齐）/ 同类连败计数（attempt-lock 三件套）/ 返回侧体积（tool-payload）/ 大输出自动限流 / 图片体积；memory-first 只认可执行位（heredoc 与引号内引用不算动手）、win-path 不再把 `description:\s` 当盘符、备份口径收窄为"无版本控制兜底的覆盖式改动"、CUA 路由把 computer-use 标为备用面。
- 打包侧：`pack-share-extras.js` 的 `SCRIPT_FILES` 补 5 个新脚本 + `win-path-guard.js`/test（之前从未随包，本地接线却在用）；`SCRIPT_SANITIZE` 给 win-path 加两条宽替换（把说明文字里的用户目录样例统一换成 proj 形态，判据语义不变）；包内 `hooks.example.json` 与 `README-hooks.md` 原计划补 attempt-lock / tool-payload / win-path 三处接线，**实际当时没落进模板**（2026-10-27 内容优化时才补齐，见下节）；两份 md 版本改 5.6.1、技能计数 124→128（**基线包 check-share-docs 因该计数过期本就判红——"家用机实际装 N 个"是活体数字，技能库增减必须同批改文档**）。
- 四道验证全 exit=0；包内 40 技能 / 79 脚本 / 2 子智能体 / 2 个 hooks 模板 / 218 文档 / 记忆 100 条（104 文件哈希一致）；`Qoder 优化 5.6.1.zip.sha256` 已生成（`hash  文件名` 两空格格式）。

**5.6.1 内容优化实录（2026-10-27，版本不变）**：
- 清单生成两处缺陷：`pack-share-extras.js` 的 frontmatter 正则只认 `\n`，随包的 local-adaptation 系列是 CRLF → 7 条技能描述解析成空；"非随包且无 `_meta.json`"会落进 `npx skills add '<owner/repo>@…'` 分支，给自建技能编出不存在的社区安装命令（脚本注释早写了"不能编"，代码分支没对齐）。判据：清单零空条目 + 本机专用段不再出现技能名。
- 根目录 `记忆筛选菜单.md` 是 2026-10-11 手工快照：101 条里 30 条文件名已不存在，且与 tar 内 `rules-summary.md`（由 GROUPS 生成、全部命中）重复 → 删除根文件，以 tar 内那份为唯一筛选菜单。
- 包内自相矛盾四处：规则文档同时写 124/26/98 与 128/27/101；hooks 模板缺 `win-path` / `attempt-lock` / `tool-payload` 三处接线却自称"与本机现役接线一致"；安装落点写 `skills/` 与"默认入按需库"冲突；`rules/doc-system.md`、`rules/rule-enforcement.md` 两个文件名已改（`doc-authoring.md`、`agent-engineering.md`）；文末两条重复的「目标与任务归属」合并进「工作方式」。
- 验收：`pack-extras`（自检）+ `check-share-docs` + `pack-folder` + `verify-share-package` 四道 exit=0，另跑 `pack-extras --check` 无漂移；版本仍 5.6.1，sha256 同步更新。

**5.6.1 单端装配修复（2026-10-27，只装一个客户端时不再造另一个目录）**：
- 事实：随包机制几乎全部把状态 / 台账 / 索引用例硬编码到 `~/.qoder`（9 个守卫 + stop-gate/session-budget/rules-reminder + fact-ledger/tmp-sweeper + tier-skills/build-skills-index + pkg-catalog + 两个 shell 同步脚本 + install-mcp），CN-only 机器第一次跑 hook 就会凭空造出 `~/.qoder`。
- 修法：新增 `scripts/client-root.js`，按 HOME 下**实际存在**的一侧解析（`QODER_HOME` 可覆盖；两侧都在时沿用 `.qoder`），`counterpart()` 给比对类脚本返回"另一侧或 null"；20 个脚本 + `fail-streak-core.js` / `mark-suggestions-evolved.cjs` + `install-mcp.cjs` 全部改用它；`sync-global-config.sh` / `sync-memory.sh` 任一方向单端都只报一句并退 0；hooks 模板占位符换成 `<客户端目录>`，README 增「只装了一个客户端（单端装配）」节。
- **判侧不能用 `__dirname`**：本机 `~/.qoder-cn/scripts` 是指向 `~/.qoder/scripts` 的 junction，被 require 的模块 `__dirname` 会被 Node realpath 成实体侧（实测）；`process.argv[1]` 才保留调用侧。但测试靠 HOME 沙箱隔离，所以解析必须以 HOME 为准。
- 判据（能失败）：沙箱 HOME 只放 `.qoder-cn`，跑 pkg-catalog register / tier-skills / rules-reminder / disk-sweeper / 两个同步脚本后 `.qoder` 必须不存在；单点变异把 `QODER = CLIENT_ROOT` 改回硬编码 `.qoder` 后必须造出 `.qoder`（实测通过，20/20 + 变异对照）。本机两侧都在，路径口径不变（周检 / config-doctor / skills-doctor 仍 CLEAN）。


**5.6.2（2026-10-27，并行会话产出 + AGENTS 新条款同步）**：
- 并行会话把 5.6.1 复制为 5.6.2（含单端装配改造；技能库新增 7 个、计数改 135），但**包内 `VERSION` 与两份文档仍写 5.6.1** —— 已改正为 5.6.2（目录名/zip 名/包内版本三者不一致是会随包发出去的缺陷，升版后必须三处同批改）。
- 同步 AGENTS 新增条款：历史结果标出处 / 冲突以现场为准、用户可见变化含服务端与配置改动、连败两次先升级怀疑层级、大输出先落盘、开工与收尾三问；四道验证 exit=0，sha256 已生成。
- 已知瑕疵（未修，待定）：`attempt-lock-guard.test.js` 的 ⑩ 断言"真机状态目录不得被写"用的是快照相等，**hook 活跃时会被真实台账写入撞成假红**（本轮实测一次：测试窗口内真实 `decisions.log` 被写入；单跑与全量复跑均绿）。修法方向：改成"真机台账不含沙箱专属键"这类内容判据，而不是整目录快照相等。


**5.3.1 回流并入 + 5.4 重打实录（2026-10-12）**：
- 入站 5.3.1 包（对方演进版）→ 按技能 `merge-inbound-qoder-package` 六阶段并入本机 → 按 `update-share-package` **以入站 5.3.1 为基线**（不是桌面 5.1）复制为 5.4 版；5.1 与其 zip 留回滚点。
- **入站包的"自检全绿"必须亲手复跑**：5.3.1 的 README 与 `rules-weekly-audit.test.js` 都宣称有"hook 指向不存在脚本"（V18）与"两侧 `scripts/`+`skills/` 目录不对等"（2g/V20）两项判据，**随包 `rules-weekly-audit.js` 并未实现** → 其自带测试实测 2 条红。处置＝在本机 `rules-weekly-audit.js` 补实现：V18 的路径正则**必须含扩展名**（否则 `fs.existsSync` 查的是无扩展名路径、基线误红）；2h 两侧同缺要静默（单端/单能力合法）；同时把测试基线里那条 hook 改成指向**真实存在的桩**。
- **记忆包"已脱敏"自称要实测复验**：5.3.1 记忆包残留个人账号、内网 schema 名、内网服务器路径与代理环境 → 并入本机的条目就地擦除；重建包时补脱敏表。
- **记忆包与本机是"同批主题的另一代导出"**（51 条同名且多分叉 + 约 25 条同主题改了前缀）→ 全量并入既造重复又撞 `MEMORY.md` 25000 字节上限；按用户裁决**只并方法论/工具类 18 条**（硬件/环境类与重命名重复跳过），再压索引回限内。
- **`pack-generic-memory.js` 要一起动的表**：KEEP / GROUPS（索引与摘要由它生成，缺一断言失败）/ SANITIZE，加**新增的 `LINK_UNWRAP_FILES`**（把新条目里指向包外的 `[[链接]]` 降为纯文字，并清家目录字面量）。本轮还修掉 3 处**旧记忆漂移出 SANITIZE 表**（`feedback-clarify-before-acting` 整行失配、`reference-common-mcp-servers` 新增带内网库地址的行、`reference-continuation-hardening` 带项目名）。**教训：新写的记忆正文别带真实标识——脱敏表只覆盖老行，新行会直接把内网信息带进包。**
- **`pack-share-extras.js` 本轮三处扩展**：① `resolveSkillDir` 支持从 `skills-disabled/` 回退（本机停用 5 个重叠技能后仍要随包发源码）；② 新增 `COMMAND_FILES` 白名单（此前不打包 `commands/`，新指令 `/edge-net-check` 会漏）；③ `SKILLS` 扩到 22 并加 `OVERLAP_NOTE`——清单里注明哪 5 个与随包 rules 重叠、收件人可自行去重。
- **`check-share-docs.js` 两条计数硬判据**：文档「N 条领域 / 流程规则」== `~/.qoder/rules/*.md` 实测、yaml 块数相等，且须含"**家用机实际装 N 个**"（正则写死这个短语）；本轮 rules 18 / skills 69，补了 3 个此前未成节的规则块（文档运行时复核 / 外部 jar 实体扩展 / 多 schema 权威源）。
- 四道验证全 exit=0；包内 22 技能 / 2 agents / 3 指令 / 52 脚本 / 128 文档 / 记忆 100 条。本机侧：两侧 `IN-SYNC`、记忆索引自洽、真机周检 0 告警、18 个自测全绿、stop-gate 活体判据真拦。

**5.4.1 打包实录（2026-10-13，office-docs 技能 bug 修复）**：
- 基线 `Qoder 优化 5.4` 复制为 `Qoder 优化 5.4.1`；5.4 留回滚点。变更：`skills/office-docs/scripts/office.js` 的 `arr()` 函数修复裸空元素（如 `<w:p/>`）解析为空字符串时触发 runText 递归栈溢出的 bug（`arr('')` 从 `['']` 改为 `[]`）。
- **`.bak` 备份文件不进包**：`pack-share-extras.js` 复制技能目录时会把 `.bak_*` 一起带入 → 打包后手动删除并重跑 `pack-folder`；下一版应在 `pack-share-extras.js` 的 `copyDir` 里加过滤（本轮未做，临时处置）。
- 四道验证全 exit=0；包内 22 技能 / 130 文档 / 记忆 100 条（104 文件哈希比对一致）。

**5.4.2 打包实录（2026-10-13，office-docs 补「插入表格」链路）**：
- 基线 `Qoder 优化 5.4.1` 复制为 `Qoder 优化 5.4.2`；5.4.1 留回滚点。变更：`office-docs` 的 SKILL.md 新增「往既有 docx 模板插入新表格（保模板样式）」专节 + description 补触发词 + 「已知边界」加裸空标签条目（`office.js` 的 `arr()` 修复随 5.4.1 已入包）；两份文档同步（通用规则 md 加本版条目与办公文档 capsule 描述）。
- **被导出记忆的新行要过敏感词形态**：5.4.1 实录段里的无空格包名形态不在 SANITIZE 覆盖内 → 记忆包自检判红（敏感词），本轮改写为带空格形态「Qoder 优化」后通过——新写正文先自查，别等打包才踩。
- **5.4.1 留的「copyDir 加过滤」本轮已做，但要覆盖下划线命名**：`pack-share-extras.js` `copyDir`、`check-share-docs.js` ⑦、`pack-folder.js` 三处的 `SKIP_PAT` 原为 `([-.][^/]*)?`，只认 `-` / `.` 分隔——`.bak_20261013` 这类下划线备份照样漏进包（实测先在包内发现才定位到）；三处字符类都补成 `[-._]`。过滤生效的判据：删掉包内遗留 `.bak_` 后重跑 extras，文件**不再重现**（实测通过）。
- 四道验证全 exit=0；包内 22 技能（62 文件）/ 52 脚本 / 2 子智能体 / 记忆 100 条（哈希比对一致）。
- **旧版不一定留在桌面**：本轮打包期间（16:35），上一版 `Qoder 优化 5.4` / `5.4.1` 目录与两个旧 zip 被清入回收站（非打包链路所为——链路脚本无回收 / 删除兄弟目录逻辑，且普通 rm 进不了回收站）；查历史，各轮旧版最终都进了回收站。**回滚点实际在回收站**：要旧版时先从回收站还原，别以为桌面目录还在。

**5.4.3 打包实录（2026-10-14，cua 升级 + 备份保留策略 + 规则审阅落实）**：
- 基线 `Qoder 优化 5.4.2` 复制为 `Qoder 优化 5.4.3`。变更批次：① cua 守卫扩到 0.35.2 新工具（`run_steps`/`run_script` 的 7 种形态，自测 35→50）+ 还原两跳兜底（沉降复读 + user32）；② 新机制脚本 `backup-file.js`（备份保留策略：≤3 份 / 删 7 天前 / 至少 1 份、删除进回收站；`edit-guard` 文案改指它）；③ 规则"裁决弹窗口径"实测化（**删掉 120 秒承诺**，改"未答复：常规按推荐继续 / gated 未授权"——同步 5 处载体：AGENTS / reminder hook / stop-gate 文案 / clean-disk / clean-temp）+ 工具条目去重 + 自动更新纪律 + 停手例外收窄；④ 周检新增 2i"有新版未升"（V21/V21b 自测）；⑤ 合并技能加「合并后审阅」阶段。通用规则 md 同步 8 处（含 changelog 5.4.3 条目）。
- **记忆瘦身批次必须与包脚本同批改**：5 条记忆瘦成"指针 + Why/案例"后立刻踩两个坑——`SANITIZE` 的旧行失配（pop-decision 3 条替换规则整块删除 + commit 注释）、瘦身后 `[[链接]]` 指向包外（该文件加进 `LINK_UNWRAP_FILES`）；先把 `pack-generic-memory.js` 跑到新暂存目录自检全绿，再 tar、再验。
- 四道验证全 exit=0；包内 22 技能 / 54 脚本 / 132 文档 / 记忆 100 条（哈希比对一致）。

**5.4.4 打包实录（2026-10-14，磁盘「清理+迁移」触发面补齐 + 五处漂移修复）**：
- 起因：用户复核"涉及 C 盘的迁移询问"规则——真源在（`AGENTS.md` 两条：清理与迁移一起问 / 首次分享包必问迁移），但**三个消费面只留"清理两问"**：`/clean-disk` 步骤、SessionStart 磁盘哨兵注入、分享文档；触发面也缺"任何要向 C 盘写大体积数据的操作"。
- 修复：① 三消费面并入"迁移一问"（clean-disk 第三问 / disk-sweeper 输出脚注 / session-budget 哨兵文案 / 文档同节）；② AGENTS 触发面补"向 C 盘写大数据操作（低于 10GB 并入弹窗）+ 分享包首次部署不看水位也问迁移"。
- **顺带全库漂移扫描又抓到 5 处**（用户点名"顺便检查"）：rules-reminder 六项例外旧措辞、disk-sweeper "两问"残留、周检磁盘建议文案、迁移技能"一次问两问"、个人规则提示词旧工具条目——全部修正。命中 `file-history/` 的旧文属历史快照，不算漂移。
- **教训**：同一句规则被多个消费面复述时，改一处必须全仓复查；"两问"这类编号词各载体含义不同（sweeper＝一档+三档；迁移技能＝清理组+迁移组），统一成"**一次问全（清理两问 + 迁移一问）**"后歧义消除。可复用命令：`grep -rln "<旧短语>" ~/.qoder | grep -v "file-history\|\.bak"`。
- 四道验证全 exit=0；包内 22 技能 / 54 脚本 / 132 文档 / 记忆 100 条。

**升版是「复制旧目录」，白名单缩了 / 脚本改名后旧文件会留在包里继续教人做错事**（2026-09-30 实测：4.10 基线里还带着已被判为有害的 `sync-byok-modelconfigs.js`）。修法在 `pack-share-extras.js`：拷完白名单后按 `SCRIPT_FILES` / `SKILLS` 剪掉输出目录里不在名单的文件并打印 `[剪除] …`，别靠手工删——下一版还会漏。

**5.0 打包实录（2026-10-08）**：
- 基线取自上一版包目录（先例：由并行会话产出的 4.10 线）→ 复制为新版目录（用户指定版本号）；旧目录与 zip 留作回滚点。
- `pack-share-extras.js` 本轮新增两样产出：`agents/`（用户级子智能体，白名单 `runtime-truth-verifier` / `deploy-verifier`）与 `plugins/README-plugins.md`（**插件不转发源码**，只给"装哪些 / 为什么 / settings.json 怎么写"，含"本机禁用"项与理由）。两者都进了产物敏感词扫描范围与包根 README 表。
- 文档同步仍用"节尾追加"法，但**必须加后置断言**：本轮因 `String.replace` 的 `$` 模式（替换文本里出现 `` $` ``）把 47k 字符的文档一次放大到 128k（同一节出现 3 次）——**修法是函数式替换 `replace(锚点, () => 文本)`**，并断言"目标节只出现 1 次 + 体积增幅有界 + yaml 块数 = 规则数"。教训已进 `rules/text-edit-safety.md` 与技能 `safe-text-editing`。
- 四道验证全 exit=0；包内 14 个自制技能 / 2 agents / 1 插件清单 / 45 脚本 / 88 文档 / 记忆 78 条。

**5.1 打包实录（2026-10-08，AGENTS.md 新增加「问题回写既有内容」规则同批）**：
- 基线 `Qoder 优化 5.0` 复制为 `Qoder 优化 5.1`；5.0 与 4.10 留回滚点。变更：AGENTS.md 新增回写纪律 + 记忆 `feedback-auto-supplement-rules.md` 增「回写既有内容」小节 + 两份文档同步该条。
- **坑 1（改 KEEP 内记忆必读）**：记忆正文里引用**真实项目名**会让 `pack-generic-memory.js` 敏感词自检 exit 1（本轮直接卡包）——记忆写 Why 时用"某遗留系统"这类通用表述，别带项目名/内网词；**新写的行不在脱敏表覆盖内**，要么写成"Qoder 优化"（带空格）这类不过敏的形态，要么同步补进脚本的 SANITIZE 表。
- **坑 2**：`verify-share-package.js` 第二参数要传「**只含一个顶层导出目录的父目录**」（脚本内部 `readdirSync(STAGE)[0]` 拼路径）——直接传导出目录本身会 ENOTDIR 崩溃；父目录里混了别的文件会取错条目。稳妥做法：临时建 `pack-parent/` 只放导出目录。
- **坑 3**：`pack-share-extras.js` **不重打 zip**——正确顺序是 `pack-folder（首次可省）→ pack-extras → **重跑 pack-folder** → check-share-docs → verify-share-package`；否则 zip 落后于目录一步（本轮在 extras 后补跑 pack-folder 才一致）。技能 `update-share-package` 步骤说明已同步此注。
- 四道验证全 exit=0；包内 14 技能 / 88 文档 / 记忆 81 条（85 文件哈希比对一致）。

**⚠️ 4.3 起新增的一条硬教训（改记忆的人必读）**：`pack-generic-memory.js` 的 `SANITIZE` 表按**整行字面量**匹配记忆正文，**记忆正文一改，对应条目立刻失配** → 自检报 `[未命中]`、exit 1、包打不出来（本轮降量改了 `reference-qoder-global-setup.md` 的三行，三条 SANITIZE 全断，连带该行里的包名/内部项目名裸奔到敏感词自检）。规矩：**改被脱敏改写的记忆后，同批更新 SANITIZE 表，且源串要从记忆文件里程序化提取（别手抄）**；新增记忆进 `KEEP` 时要同时补 `GROUPS`（索引由 GROUPS 生成，缺一即断言失败），并在 SANITIZE 里把它指向包外的 `[[链接]]` 收成纯文字。

**4.3 打包链路实录（2026-09-29）**：
- 旧版本可能只剩 zip、源目录已不在：以 `unzip` 解旧 zip 为新版目录（旧 zip 保留作回滚点）；**解包后内层顶层目录要改名**，`pack-folder.js` 才会打出与新版本号一致的顶层名。
- 文档同步点（`check-share-docs.js` 会逐条判）：① `yaml 块数 == rules/*.md 数`（本轮 12→13，新增 Python 规则块）；② 文档里的「N 条领域 / 流程规则」与「家用机实际装 N 个」必须等于磁盘实测（13 / 55）。
- `pack-share-extras.js` 本轮三处改动：`SKILLS` 白名单新增 3 个自制技能；新增 `NO_SHIP_SELF_BUILT`——**自制但源码里有意保留内网形态样例**的技能（其 selftest 夹具要证明内网 IP 会被门禁抓到，抽掉样例等于削弱自测），清单里如实标「本机专用」、不编社区安装命令；**本机专用技能的 description 不进清单**（描述天然带环境信息，否则会让「清单敏感词」自检失败）。
- 四道验证全 exit=0：`pack-share-extras`（自检：技能齐全 + 产物零敏感词）、`pack-folder`、`check-share-docs`、`verify-share-package`（结构 / 敏感词 / 链接 / 与暂存逐文件哈希）。

**4.1 打包链路实录（2026-09-23；含链路 8 处修复，务必沿用）**：
- 组装：解包 4.0 为新版目录 → 删基线里不该带的（`export-memory.sh` / `import-memory.sh`：含本机凭据清单）→ `pack-share-extras.js` 重建 skills//scripts//mcp//README → 重建记忆包 → tar → zip → 双校验。
- `pack-share-extras.js` 六处修复：① `copyDir` 排除 `node_modules`（此前把整棵依赖树打进包）；② `SCRIPT_FILES` 补 4.0 新脚本（commit-scope-guard / disk-sweeper / global-config-guard.test / **stop-gate.test**——漏它会让未净化文件混入）；③④ `SCRIPT_SANITIZE` 增 rules-weekly-audit.test / stop-gate.test 的用户目录绝对路径示例；⑤ 删 validate-repowiki 的过时替换（4.0 文件已自带脱敏，"未命中即报错"是设计，别留过时条目）；⑥ 扫描豁免 `package-lock.json`（npm registry 哈希的随机 base64 串会撞敏感词清单里的短代号，实测撞过）。
- `verify-share-package.js`：**两处**扫描循环都要同一豁免（包目录扫描 + tar 内记忆包扫描）。
- `pack-generic-memory.js` **不自动建暂存目录**（直接 ENOENT）——先 `mkdir -p` 再跑。
- verify 的"暂存目录"参数要传**含顶层子目录**的路径（tar 阶段目录），不是记忆包平铺目录。
- 文档计数（"家用机实际装 N 个技能"）随磁盘实测更新，否则 `check-share-docs.js` 判红。

**关系**：文档是"分享版改写"，**真源是 `~/.qoder{,-cn}/AGENTS.md` + `rules/*.md`（12 个）**——真源更新后要对照检查文档。2026-09-19 一次合并（18 处）：vibe-coding 整节、三层 hook 机制现状、长任务/frontend/testing/databases/infra-ops/delivery-pr 的条目与 glob、description 关键词、技能名与计数口径（11 条规则 / 80 候选）、rules·memory 不可建链的新事实。

**维护检查清单**（改完必跑，已脚本化为 `~/.qoder/scripts/check-share-docs.js`）：① 所有 ` ```yaml ` 块解析合法且含 trigger（应 12 个）；② 计数口径 = 磁盘实测（12 条领域规则 / 80 候选技能名 / 已装技能数）；③ 旧技能名无残留（nginx-configuration→nginx-config-builder、rabbitmq-development→rabbitmq-expert、kafka-development→kafka-best-practices、db→oracledb 等）；④ 三反引号行数为偶数；⑤ 记忆包由 `pack-generic-memory.js` 重建（自检 exit 0）并解压复验（哈希一致 + 敏感词零命中）才算数——未经复验的 tar 不得随包分发。

**0.0.16 与交付闭环（2026-11-03）**：
- 现役已按「三路合并部署」合并 0.0.16（现役 live / 旧包 / 新包，保留现役较新内容）；部署后索引 154（12 常驻 + 142 按需）。包内仍有约 70 个技能、3 个脚本未安装，46 个已安装条目与包内内容不同（含本地较新内容），按需询问后再处理，不整目录覆盖。
- 发布 / 下载复验通过后必须用 `AskUserQuestion` 询问是否部署；检索到可安装 / 可更新条目必须询问安装 / 更新。机制：`pkg-catalog.cjs` 的 `search/list/drift` 输出 `NEXT_ACTION`，`skill-load` 本地命中也会比对包内内容；`update-share-package` 与 `share-package-release` 已写入强制询问步骤。
- 口径详见 feedback-share-package-ask-install-update；不要把「发布成功」当成「交付完成」。

**0.0.21 部署实录（2026-11-04）**：
- 拉取 0.0.20→0.0.21（660b4fe）后按标准部署：更新 19 条本地未改的安全条目（7 条基础路由 + 12 条脚本/技能/命令）；`self-evolution` 只替换 `references/operations.md`，保留本地 `SKILL.md`；安装新技能 `counterexample-driven-plan-review`。
- `install-package.cjs --yes` 接线基础路由并安装 `capability-advisor.cjs`；索引 156（12 常驻 + 144 按需），skills-doctor CLEAN。
- 剩余 44 条差异保留未覆盖：17 条双方都改、26 条仅本地改动、1 条 `self-evolution` 混合；需要时按逐项 diff 合并。
- 已知：`share-package.json` 的 catalog 指向仓库 `catalog.json`，旧基线随版本移动会把基础路由误判为 REVIEW_UPDATE；先三路比对确认本地=旧版后再 `--force` 更新。
- 已知：CN 侧 hook 命令串未加 `--client-root`，周检报两侧不一致；本次 CN 设置写入被平台分类器拦截，留待人工处理（两侧脚本均已接线，功能等价）。

**0.0.22 发布实录（2026-11-04）**：
- 版本 `0.0.22`，提交 `8a809f3`（16 文件，+82/−20），附注标签 `v0.0.22`；构建 522 文件，核心 zip 2.34MB / offline 36.3MB（各带 `.sha256`）；包目录 `check-release` CLEAN、敏感扫描 0 命中、`DELIVERY_VERIFIED`；分发包隔离安装/检索/按需安装通过。
- 内容：常驻技能按使用习惯确认并持久化（`skills-resident.json`）、`skill-usage` 使用记录与晋升/降级建议、无注册包时按需技能自动发现（AUTO_LOAD/ASK_USE）、并行计划文档与运行前决定、真实召回命令、catalog 声明 `build-skills-index.cjs` 依赖。
- **升级路径真实缺陷（发布前抓到并修复）**：0.0.21→0.0.22 干净升级在暂存阶段失败并整批回滚——暂存客户端只复制“将变化的条目”，`build-skills-index.cjs` 未变更的依赖 `client-root.js` 未进暂存区，索引重建 require 失败。修法：`install-package.cjs` 在 `prepare` 计算 `stageDependencies`（变更脚本的依赖闭包中未变更的脚本），`apply` 时从现役客户端复制进暂存区；新增“技能+索引构建器同时变更”的回归用例。修后真实升级 `INSTALLED`、13 项更新、索引正常。
- 冲突保护实测：把现役 `rules-reminder.js` 改一行后再升级，返回 `ACTIVATION_BLOCKED`（exit 3），文件字节不变、整体不发布（检测而非覆盖）。
- **`check-release.js` CLI 契约**：以 `process.cwd()` 为包根、`process.argv[2]` 为 tag。`node .github/check-release.js <包目录> v0.0.22` 从仓库根跑会检查整个工作区（5573 文件、5061 条假 problems）；正确用法是 `cd <包目录> && node <repo>/.github/check-release.js v0.0.22`。
- 对抗审查 5 条线索：修复 2 条与发布宣称不符——`别用/不要用 X` 未识别为拒绝（拒绝词组补“用”）、全角冒号 `密码：` 与非 HTTP URL 凭据 `redis://:pass@` 未脱敏；`--preview` 是文档声明的工具/测试通道（非缺陷）；`skill-usage` 无记录不降级属设计边界；`DECISION_REQUIRED` 仅有静态断言属测试覆盖缺口。
- 现役漂移（发布前只读 `pkg-catalog drift`）：仓库口径 50 条 = 35 技能 / 13 脚本 / 2 命令；包目录口径 61 条，多出的 10 条是仅换行符差异（6 技能 live CRLF/包 LF、4 个 .ps1 反之），归一化后内容一致。
- **0.0.22 现役部署（2026-11-04，用户选择）**：三路比对（现役/0.0.21 worktree/0.0.22）后只更新 2 条可证明“现役=8faada2 旧版+本轮修复”的脚本（`parallel-context.cjs`、`capability-advisor.cjs`），补装 `parallel-write.cjs`、`install-package.cjs`；其余 43 条本地改动全部保留。部署前后 6138 文件哈希快照对比只变化这 4 个文件；索引 156（13 常驻 + 143 按需），CN 侧靠 junction/硬链接同源，`skills-doctor` CLEAN；现役探针：`别用/不要用 office-docs` 不再产生条目，`请使用 office-docs` 仍返回 KEEP authorized=true，`密码：`/`redis://:pass@` 脱敏生效。
- 基线获取：`git worktree add --detach <dir> v0.0.21` 可用；`git archive v0.0.21 | tar -x -C ...` 在本机 Git Bash 曾卡住（进程在、零输出、超时），改用 worktree。
- 回归：修复后全量隔离 565 tests / 564 pass / 1 POSIX skip / 0 fail；上一轮 main `9d86133` 的 CI 红在 Gate/build（版本元数据未同步），本轮已重生成全部元数据。验证方法见 feedback-release-verify-upgrade-path。

**0.0.23 / 0.0.24 发布与现役部署（2026-11-04）**：
- 0.0.23 于 2026-11-04 发布（4 个资产，核心约 3.1MB / 离线约 36.3MB，各带 `.sha256`）；0.0.24 由并行会话同日发布（含 0.0.23 大部分修复的演进版），GitHub Latest 保持 0.0.24，0.0.23 作为独立 Release 保留；发布后标签未再移动。
- **GitHub Actions 工作流坑**：`${{ runner.temp }}` 只能用于 step 级 env；放到 job 级 env 会让整份 workflow 在 0 秒失败（“workflow file issue”，无任何 job）。Windows runner 默认 `TEMP` 在 C:，CUA/迁移夹具要求非系统盘 → 在测试 step 设 `TEMP/TMP/TMPDIR: ${{ runner.temp }}`；冷启动 PowerShell 可超过 30s，迁移夹具给 60–120s。
- **发布并行冲突**：另一会话可能在发布途中推送 main 和新 tag；推送前先 `git fetch`，main 落后就合并（绝不 force），tag 只在没有任何 Release/资产之前允许重建，发布后不动。
- **现役部署（三路合并）**：`install-package.cjs` 只更新与旧包一致的条目，本地改动只报告；全量合并需手工三路。基线用 `~/.qoder/package-activation.json` 的 `catalogSha256` 反查上次激活提交，再以最近两个发布件作逐文件备选基线，避免把“新版本新增”误判成“本地删除”。`git merge-file` 的正退出码是冲突数（1..127），不是执行错误。
- **依赖与补装**：更新脚本时同批补其本地依赖 helper（`stop-gate-text.js`、`hook-targets.cjs`、`parallel-context-redact.cjs`、`pkg-catalog-score.cjs`），否则更新后的脚本 require 失败；技能内被引用但本地缺失的 reference 文件按引用补回。部署后按安装说明执行 `npm ci --ignore-scripts --prefix <客户端>/scripts/convention-runtime`。
- **本次落地（2026-11-04）**：用户选择“用 0.0.24 做全量三路合并”；33 项更新 + 8 项补装，0 冲突；drift 75→47（余量为保留的本地改动）；索引 156（13 常驻 / 143 按需）；现役 8 个相关测试套件 59/59、`skills-doctor` CLEAN；`settings.json` 未改；回滚用部署前归档与逐文件 `.bak`。

**0.0.28 拉取与现役部署（2026-11-06）**：
- 拉取：本地 `f4aa78f`（0.0.24 期）落后 origin/main 15 个提交，快进到 `4549f83`（VERSION `v0.0.28 / 2026-11-06`）；工作区里有另一会话 2026-11-05 的 22 个未提交改动，先存 `D:/tmp/qo-wip-20261105/wip.patch`，再 `git stash push -m wip-parallel-2026-11-05`（`stash@{0}` = `b216463f`，未删除，恢复用 `git stash apply b216463f`）。
- 发布事实：tag `v0.0.28` 指 `0af01a7`（main 之后又有一个只改 `.github/maintenance-loop.test.js` 的提交 `4549f83`，不入包）；tag 运行 source/windows/publish 全 success，发布提交的 main 推送曾有一次 windows 自测失败（已由 `4549f83` 修复）。从 `0af01a7` 本地重建的两 zip 与 Release 下载件 sha256 逐字节一致；739 文件、`DELIVERY_VERIFIED`、敏感扫描 0、包目录门禁 CLEAN；隔离消费者安装 62 项、索引 12。
- 现役部署（用户选择“安全更新+补装”，hook 保持现役）：保守判据＝现役与 v0.0.25/26/27 任一完全一致才算安全项 → 14 条更新（3 技能 + 11 脚本）+ 7 个运行脚本（其中 3 个由依赖闭包自动带入）；50 条本地改动保留、8 个测试文件不装；部署前后 6395 文件快照对比仅 23 个文件变化；索引 156（13 常驻 / 143 按需）、两侧索引同源、`skills-doctor` CLEAN；hook 冒烟 exit 0（context 1805 字符，含规则提醒与路由）；现役探针 `请使用 office-docs`→KEEP、`别用 office-docs`→无条目；`skill-reference-integrity` 0 缺失。
- **坑：不要用 `QODER_HOME=<.qoder-cn>` 生成技能索引**。CN 侧 `skills/`、`skills-library/` 是指向 `.qoder` 的 junction，索引收集器跳过符号链接目录 → 生成 0 条并覆盖 CN 索引。正确做法：以 `.qoder`（实体侧）生成 156 条索引，再让 `.qoder-cn/skills-index.json` 与它硬链接同源（`ln <q>/skills-index.json <cn>/skills-index.json`，同盘可用）。
- hook 接线结论：现役 UserPromptSubmit = continuity + rules-reminder(`--workflow-mode model`, `--client-root`) + session-budget + fact-ledger；Pre/PostToolUse 用 dispatcher 合并守卫，覆盖与 0.0.28 `hooks.example.json` 逐条模板完全一致（pre: edit/huge-output/commit-scope/cua/risky-match/win-path；post: cua/auth-lock/attempt-lock/tool-payload），多出 PreCompact/PostCompact continuity，属单独接线范围 → 保持现役即可，无需改 settings。

**0.0.29 发布与现役部署实录（2026-11-06）**：
- 版本：tag `v0.0.29` 在 `1bed181`；Release 非草稿；核心包 sha256 `1670359a…4090a1`、离线包 `b01706d1…73f0b3`；Actions run `42187746850` success。公开资产解压后 VERSION/catalog（292 条）/manifest 均 0.0.29；隔离 HOME 下 register/search/install 全 exit=0。匿名下载在本机网络被 release-assets 域名阻断，认证下载校验通过。
- 技能恢复：27 个按需技能回到 `skills-library`（含 MongoDB 7、Redis 5、小程序/游戏 4、Spring 2 等）；44 个确认无用项移入 `~/.qoder/.backups/2026-11-06-skill-restore/removed-useless/`（未删除），6 个保留在 `skills-disabled`；按需库 170、常驻 13、索引 183。
- 现役部署（用户选择「仅部署本次缺口」+ 逐项审查）：`capability-advisor.cjs`、`pkg-diff.cjs`、merge-inbound SKILL.md、20 个技能 SKILL.md + 21 个附属文件与包逐字节对齐；4 个技能 + 10 个脚本更新；`checkpoint` 与本地专有内容保持。drift 74 → 38（38 = 30 个本地专有/描述差异技能 + office-docs 本地 lock + 5 个仅换行脚本 + checkpoint + self-evolution 本机路径修正）。
- 坑：0.0.29 的 self-evolution 正文用裸相对路径 `scripts/evolution-candidates.cjs`，技能目录内无此文件 → `skills-doctor` 判 DANGLING-REF；改为 `~/.qoder/scripts/evolution-candidates.cjs` 后 CLEAN，提交 `787fe5a` 已推送。下个发布版本应带上该修正。
- 本地增强回写（同日晚，提交 `ac91598` 已推送）：9 个描述更强的技能（architecture-designer / awesome-design-md / cloudbase-wechat-integration / frontend-design-ui-ux / frontend-development / java-quality / redis-connections / typescript-pro / tailwindcss-animations）+ `python-dataviz` 描述与两篇参考。未同步：mysql（第三方 PlanetScale 促销）、encrypted-office（厂商名）、checkpoint（本机路径）、repo 已更新的 byok/java-architect/miniprogram/vue/local-reverse-proxy，以及仅换行差异项。校验：暂存包 verify CLEAN、secret 0/0、全量 683 项 0 fail。
- 验证：`session-budget` / `risky-match-guard` / `verification-trigger-core` 测试全 PASS；`pkg-diff --selftest` 15/15；`continuity-install` 23/23、`continuity-review` 22/22、`parallel-review` 30/30、`parallel-write` 24 pass + 2 skipped + 0 fail；`rules-weekly-audit` 仅 2 条既存告警。
- 差异报告：`D:/tmp/disabled-skill-audit/drift-diff-report.md`、`drift-diff-details.md`、`drift-final4.txt`；发布物：`D:/qoder-release-artifacts/release-0.0.29/`。

**0.1.0 拉取与全量三路合并部署（2026-11-09）**：
- 拉取：本地 `65c54a5` 落后 origin/main 9 个提交，快进到 `a7c2170`（VERSION `v0.1.0 / 2026-11-08`）。暂存区有并行会话的 context-governor 安装器 WIP（5 文件，与远端重叠）：先存 `D:/tmp/qo-wip-20261109/wip.patch` 再 `git stash push`（stash commit `bb3ac2cd`，未恢复未删除，属另一会话）；0.0.28 期的旧 stash `wip-parallel-2026-11-05` 仍在。
- 部署（用户选「全量三路合并」）：基线 worktree `v0.0.29`（package-activation.json 停在 0.0.21 期不可靠），按 catalog 逐文件三方比对（CRLF 归一化）：**14 更新**（现役==旧版：skills-router SKILL.md、11 脚本含 build-skills-index/install-package/pkg-catalog/rules-reminder/rules-weekly-audit/session-budget/skills-doctor/tier-skills 等、pkg-find/skill-load 两命令）+ **5 新增**（4 个 context-governor 脚本 + skills-router/references/route-commands.md）+ **1 合并**（python-dataviz SKILL.md：引用行取新版超集 `scripts/interactive.py or references/…`，保留本地空行与 `cd ~/.openclaw` 泛化）；16 KEEP-LOCAL + 36 LIVE-ONLY 不动；**118 文件既有缺口（44 技能 + 8 测试脚本）维持既往不装裁决**（0.0.16 起用户已选择不全装，不重复询问）。
- governor hook 只装脚本未接线：0.1.0 的 hooks 模板相对 0.0.29 无变化，settings.json 未动；并行会话的安装器 WIP 在 stash 里由其自行收尾。
- 验证：部署前后 6656 文件快照对比仅 20 文件变化（+15 逐文件 .bak，backup-file.js 保留策略剪 11 个旧 .bak）；索引 183（13 常驻 + 170 按需）、CN 硬链接同源；drift 55→41（余量全为本地保留）；测试全绿：context-governor/hook、rules-weekly-audit、skill-load、session-budget、activation-install、catalog-transaction、pkg-diff 15/15；skills-doctor CLEAN；rules-reminder 冒烟 exit 0（1770 字符）。现场与回滚证据：`D:/tmp/qo-deploy-20261109/`（plan/applied/快照/live-backup 归档/测试日志）。
- **坑：session-budget.test.js 两条「SessionStart 静默」用例不隔离看门狗台账**（`AUDIT_LEDGER` 读真实 CLIENT_ROOT/tmp/rules-audit/history.log，SB_STATE_DIR 沙不住）：真机周检超 10 天即假红，不是部署回归。跑一次 `rules-weekly-audit.js` 刷新心跳即全绿（本轮 warn=4 fixed=0）。测试隔离缺口未修（该测试是本地 KEEP-LOCAL 文件）。
- **坑：pkg-diff.cjs 不在 catalog 也不在 scripts/**，真源是 `skills/merge-inbound-qoder-package/scripts/pkg-diff.cjs`（技能附属脚本），selftest 要从技能路径跑；按记忆去 `~/.qoder/scripts/pkg-diff.cjs` 跑会 MODULE_NOT_FOUND。
- 周检心跳已刷新（2026-11-09）；既存 WARN 与本部署无关：CN 侧 PostToolUse 接线差异（0.0.21 起留待人工）、cua-driver 0.38→0.44 未升（当时未授权；同日已升到 0.44.0，见 `reference-cua-driver-installation`）。

**0.1.0 文档口径与修复同步（2026-11-09 第二轮）**：
- 口径同步（真源 ← 分享文档 0100c5a「sync shareable rules with 5.7.0」）：目标 ask-once（2026-11-07 用户裁决，机制脚本第一轮已部署）落 4 处——AGENTS.md:108/159、rules/long-task.md 目标化执行、rules/vibe-coding.md 目标与任务归属；记忆索引「<190 行目标 / 200 硬上限 / 预留 ≥10 行」细化落 AGENTS.md 记忆节。**本地提交口径冲突经弹窗用户拍板「同步制作端口径」**：验证后主动 commit 不等提醒（取代「须明确要求」），落 AGENTS.md 交付节+主动收尾条、rules/delivery-pr.md，记忆 feedback-commit-after-changes / feedback-local-commits-and-goal-handoff / feedback-proactive-wrap-up / rules-summary 及 MEMORY.md 三条钩子联改；push/PR/SVN/发布授权边界不变。
- 不同步项：分享包通用工作流标记块（接收者兜底，本机细则更全）、认证失败具体阈值段（本机在 feedback-database-safety）、rules/rule-enforcement.md 引用（制作端文件不在 catalog，本机对应内容在「让规则真正生效」节）、README/INDEX/安装说明（包面文档随 repo 拉取）。
- 修复核验：d82a13b 按脚本身份比对后命令形式假 WARN 消除；剩余 Pre/PostToolUse 两条 WARN 经 dispatcher 展开核实**功能等价**（非 CN dispatcher 与 CN 直挂守卫清单完全一致），属结构差异不动接线。验证：两侧 AGENTS.md sha256 一致、sync-global-config --check IN-SYNC（30 文件）、旧口径 grep 零残留、周检无新增 WARN、接线版 rules-reminder（--workflow-mode model）冒烟注入 ask-once 文本与文档一致。证据：`D:/tmp/qo-deploy-20261109/`（doc-sync-0100c5a.diff、audit-after-doc-sync.log、hook-smoke-model-mode.json）。

**0.1.0 审阅流程修复的三路合并部署（2026-11-09 第三轮）**：
- 背景：本地提交 `1a64b2b`（pkg-diff review + stop-gate R13 + 包内流程文档）后，用户选「全量三路合并」。基线 worktree `a7c2170`、新包 worktree `1a64b2b`、现役镜像（live 技能在 `skills-library/`，镜像用于对齐包内 `skills/` 相对路径）。
- 审阅：7 DIFFER = 6 TAKE-INBOUND + 1 BOTH-CHANGED；2 LOCAL-ONLY（技能内 `backup-config.cjs/.test.cjs`）不动。`commands/update-share-package.md` 的本地独有内容是「双语 README / 规范单节扩写与可失败验收」章节，合并稿 = 包内新 step 9 + 本地章节。7 文件备份后写入，sha256 与包内/合并稿对齐；两侧符号链接一处生效。
- **坑：`scripts/pack-share-docs.cjs --apply` 会按现役 `~/.qoder/rules/*.md` 全量重写分享文档第二节**，把机器路径（`D:\qoder-backups`）和「发现新版即升级」「多写手并行」等未批准口径带进公开包，并让 `.github/maintenance.test.js` 两条脱敏断言判红。正解：第一节取现役 AGENTS，第二节保留 0.1.0 的 curated 版；生成器已加防呆注释。下次发布不得直接 `--apply` 覆盖第二节。
- **pkg-diff review 新增 skills→skills-library 映射**：包内 `skills/<name>` 自动对本机 `skills-library/<name>`（否则按需层技能全被误报 NEW、永远走不到合并询问），输出标注「本机位置」；selftest 22/22。
- 验证：maintenance 135/135；stop-gate 362/362（R13 8 条）；pkg-diff selftest 22/22（repo+live）；skills-doctor CLEAN；sync-global-config IN-SYNC（30 文件）；索引 185（13 常驻 + 172 按需）；rules-reminder 冒烟 exit 0（4337 字符，含「允许质疑」）。提交 `1b64dc2`（文档第二节恢复）、`5be9424`（库层映射）、`db7491c`（changelog），本地未 push。
- drift 决策（2026-11-09）：42 条 = 24 条仅 CRLF 差异 + 14 条现役较新 + 3 条脚本/命令 + 1 条 lockfile。用户先要「差异清单」、再要「逐项完整 diff」，最终只批准 3 项小改：python-dataviz（`/home/matt` → `~/.openclaw`）、office-docs package-lock（+`"license": "MIT"`）、pack-share-docs 注释；其余 39 保留现役。更新后 drift 40（新增 `command:clean-temp` 属并行会话 WIP，不部署）。
- 并行会话：repo 工作区 `scripts/stop-gate.js` 被 R14 WIP 改出语法错误（git status M），在 repo 目录直接跑 `stop-gate.test.js` 会假红；用提交版本跑为 362/362。全量回归第二轮在无关 retry-family 用例卡死被停止，第一轮仅两条文档断言红（已修）。临时产物按用户批准清 42 项（两个 worktree + 今日 35 个 `qo-release-tests-*` + 审阅日志），负对照确认他任务产物都在。

相关：[[reference-qoder-global-setup]] [[reference-rule-enforcement-mechanisms]] feedback-share-package-ask-install-update
