---
name: reference-css-var-theme-trap
description: var() 在"声明所在元素"上解析：color: var(--ink) 写在 body 上时，子容器重定义 --ink 不会改变继承下来的颜色——昼夜/主题切换页眉页脚文字不变的根因与修法
metadata:
  type: reference
---

CSS 自定义属性做主题切换时的一个静默陷阱（一次夜景主题切换实测）：

- **现象**：`body.night .poster { --ink: #ece3cf }` 生效后，`.poster` 内按钮（`color: var(--ink)` 声明在 button 自身）正确变浅，但页眉/页脚文字仍是白天的深色——深色底上几乎不可读。
- **根因**：`body { color: var(--ink) }` 这条声明的 var() 在 **body 元素**上解析（body 处 --ink 仍是默认值），解析结果作为**已计算颜色**被后代继承；后代元素重定义 --ink 影响不到已经算完的继承值。声明在哪个元素，就在哪个元素查自定义属性。
- **正确做法**：把 `color: var(--ink)`（以及 background 等）声明在**重定义变量的那个容器**上（如 `.poster { color: var(--ink) }`），让后代继承容器解析后的值；或干脆每个用到颜色的元素各自声明 `color: var(--ink)`。
- **适用边界**：一切"局部作用域重定义主题变量 + 祖先元素声明 var()"的组合（暗色模式、卡片级换肤）。验证手法：切换主题后用 `getComputedStyle(header).color` 直接量计算值，不能只看截图猜。

相关：[[feedback-verify-fix-in-ui]]、[[feedback-frontend-craft-bar]]。
