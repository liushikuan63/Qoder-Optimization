---
name: reference-zip-chinese-filename-compat
description: zip 中文文件名兼容性：PowerShell Compress-Archive 产物在 MSYS unzip 下乱码；用 pack-folder.js 生成 Unix 来源 zip 解决
metadata:
  type: reference
---

# zip 中文文件名兼容性（2026-09-17 排查）

**现象**：PowerShell（无论 5.1 还是 7）`Compress-Archive` 生成的 zip，含中文文件名时——Windows 解压工具（资源管理器 / PowerShell Expand-Archive / 7-Zip）正常，但 MSYS/Git Bash 的 `unzip` 解出来的中文名全是乱码（如 `中文包名示例` → `中文õ+Õîû示例`）。

**根因**：zip 条目的"version made by"OS 字节 + UTF-8 标志位（bit 11）的组合差异：
- PowerShell 产物：DOS 来源（madeBy=0x14）+ UTF-8 标志。MSYS unzip 对 **DOS 来源**条目**忽略 UTF-8 标志**，按本地 OEM 代码页（GBK）二次转换 UTF-8 字节 → 乱码。
- Unix zip 工具产物：madeBy=0x314（Unix）+ UTF-8 标志 → unzip 按 UTF-8 直读 → 正常。

**正确做法**：要生成"哪都兼容"的 zip（尤其含中文名），用 `node ~/.qoder/scripts/pack-folder.js <文件夹> [输出.zip]`——该脚本按 Unix 来源 + UTF-8 标志 + 正斜杠 + 目录项手写 zip（含自实现 CRC32），已实测 Windows 工具链与 MSYS unzip 双通过。

**验证方法**（改打包工具后必做）：
1. `unzip -l` 或解压后用 node `fs.readdirSync` 读文件名（终端显示可能骗人）；
2. PowerShell `Expand-Archive` 解压后再用 node 读一遍；
3. `cmp` 对比解压文件与原文件内容。

**排除的弯路**：① 换 PowerShell 5.1→7 不解决（同为 DOS 来源）；② Windows 自带 bsdtar 产 Unix 来源但**不带** UTF-8 标志、按 GBK 存名 → unzip 也乱；③ 终端 `unzip -l` 的显示乱码不代表磁盘文件乱码，必须用程序读目录验证。

相关：[[feedback-auto-add-global-extensions]]
