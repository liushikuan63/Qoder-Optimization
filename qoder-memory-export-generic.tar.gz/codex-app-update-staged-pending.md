---
name: codex-app-update-staged-pending
description: Codex 桌面版(ChatGPT.exe)更新"失效"的机制：MSIX 更新分 Stage→Register，应用常驻运行会阻塞 Register，完全退出应用或重启后才生效
metadata:
  type: reference
---

**现象**：Codex 桌面版（Store/MSIX 渠道的 ChatGPT.exe）更新后版本不变，像是"更新失效"。2026-09-17 实例：新版 26.911.7940.0 已 Stage 完成，但打开仍是 26.908.9136.0。

**2026-09-18 00:37 解决记录**：注册成功（26.911.7940.0 对用户 Installed，旧版目录移入 `D:\WindowsApps\Deleted` 后被清理）。触发方式：**完全退出 Codex（所有进程）**后系统完成延迟注册（排队约 12 分钟后执行），**无需重启电脑**。此前"每次启动 Codex → 更新被置为 BlockedOnUser → 重扫取消"的循环在注册完成后自然终止。全程未影响会话/登录数据。

**根因**：Store/MSIX 应用更新分两步——Stage（下载并暂存到磁盘）+ Register（注册给用户生效）。Windows 会把 Register 推迟到应用完全退出之后（运行中的应用会阻塞部署，同类日志报 0x80073D02"需要关闭以下应用"）。ChatGPT.exe 常驻运行（含后台/托盘进程，一次有 12 个）时，注册一直不执行。

**判据/检查方法**：
- `Get-AppxPackage -AllUsers OpenAI.Codex`：新版显示 `Staged`（仅 S-1-5-18）、旧版显示 `Installed`（本人用户）= 卡在等注册。
- 事件日志 `Microsoft-Windows-AppXDeploymentServer/Operational`：搜 Codex，确认 Stage 已完成（Id=400/613）但之后没有对应 Register 成功记录（RegisterByPackageFamilyName / updateList）。

**正确做法**：完全退出 ChatGPT.exe（所有进程）→ 系统自动完成注册 → 重开即为新版；或重启电脑（最可靠）。兜底：`Add-AppxPackage -Register "D:\WindowsApps\OpenAI.Codex_<新版>\AppxManifest.xml"`（须先关闭应用）。

**本机相关事实**：Codex 包体在 `D:\WindowsApps\`（"新应用保存位置"设为 D:；`C:\Program Files\WindowsApps\` 下是符号链接）。2026-09-18 00:37 起生效版本 = 26.911.7940.0（旧版已清理）；旧的 CodexPetPatched 改版（基于 26.901）如需继续用须基于新版重做。

相关：[[codex-app-first-launch-runtime-staging]]
