---
name: feedback-use-existing-tools-first
description: 优先复用已有能力并按需加载，避免整库和重复正文消耗上下文；后续生成与新增也保持这一标准
metadata:
  type: feedback
---

优先查找并复用现成能力，但技能必须按当前任务按需加载，不能把“先查工具”变成全量读取。

**Why:** 已配置的能力应真正参与任务，而不是凭印象猜；同时要控制上下文，按需加载。

**How to apply:**
- 先检索，只读取当前任务单元命中的必要正文与引用；已加载且未变化的内容直接复用，编辑前的现状核对仍保留。
- 后续生成、新增或导入技能不自动扩大常驻上下文；按当前分层规则放置，只保留有明确必要性的常驻入口。
- 分发包收录、文件存在、已安装和已加载不是一回事，不为展示能力全量安装或注册。
- 安装、权限或连接变化仍按当前授权处理；此偏好不提供额外执行授权。

相关：[[feedback-auto-install-domain-tooling]]、[[feedback-auto-add-global-extensions]]、[[reference-qoder-global-setup]]
