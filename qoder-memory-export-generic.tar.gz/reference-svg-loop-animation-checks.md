---
name: reference-svg-loop-animation-checks
description: SVG/CSS 循环动画自检手法：轴心/接缝(含切线斜率)/dashoffset 整周期/轮速与地面速度一致性；`<use>` 影子树 CSS 动画真会跑但 getAnimations 不枚举、getBBox 不含 transform；读 keyframe 原文要遍历 CSSKeyframesRule
metadata:
  type: reference
---

纯 SVG + CSS keyframes 动画（无脚本）做"无限滚动"场景时，四类可失败的判据：

- **旋转/缩放轴心**：给 `<g>` 用 `transform-box: view-box` + `transform-origin: <x>px <y>px`（值为 viewBox 作者坐标），比 `fill-box` 猜包围盒中心可靠；嵌套变换（头摆动 + 喉囊缩放）各自独立取原点即可，不必换算。
- **平铺层接缝**：图层按周期 P 平铺、动画平移 -P。判据 = `getBBox().x <= 0` 且 `bbox.x + width - P >= viewBox 宽`。实心层（山脊/护栏/路面）必须成立，否则循环后段画面一侧会**整块消失**（护栏立柱铺到 1050、平移 450 后右侧 600–900 就空了）。稀疏装饰层（云）只需窗口内始终有内容。
- **虚线滚动**：`stroke-dashoffset` 终点必须是 `stroke-dasharray` 周期（各段之和）的**整数倍**，否则每轮跳一格。
- **平铺图形自身**：重复图形的起点与终点 y 必须相同，否则接缝处出现台阶（山脊 `L450 380` 收尾 → 与下一片 `M0 400` 差 20px）；进一步看**首尾切线斜率**是否一致，斜率翻转会在谷底留下 V 形折角（用 `C`/`S` 的控制点算方向向量即可：入 0.247 / 出 -0.38 即不连续）。
- **运动物理一致性（"打滑"判据）**：轮子驱动的场景必须满足 `2πr / 轮转周期 ≈ 地面平移距离 / 平移周期`。实测对照——轮径 65 / 0.72s = 567px/s vs 路面 1120/2.3s = 487px/s → 快 16%（一直在打滑）；轮径 52 / 0.7s = 467px/s vs 虚线 200/0.43s = 465px/s → 差 0.4%。纯计算判据，静态截图完全看不出。

**读不到值的坑**：`getComputedStyle(el).strokeDasharray` 返回 `"46px, 34px"`（按 `\s+` 切分会得 NaN）；`anim.effect.getKeyframes()` 里拿不到 `strokeDashoffset`。要读关键帧声明原文：遍历 `document.styleSheets[].cssRules` 取 `type===CSSRule.KEYFRAMES_RULE`，用 `r.cssText` 正则取值。

**"动画真在跑"的最小证据**：`document.getAnimations()` 的 running 计数 + 隔 ~260ms 两次采样 `getComputedStyle` 的 transform / dashoffset 必须不同。

**`<use>` 影子树里的 CSS 动画（2026-09-18 实测纠正）**：`<use href="#wheel">` 实例化出来的克隆体，其上的 CSS 动画**是真生效的**，但有两个"看起来没动"的假象陷阱：
- `document.getAnimations()` **不枚举** SVG use 影子树里的动画：实测某页 16 个动画恰好等于 light DOM 元素数，影子树目标数为 0；`use.shadowRoot` 是闭合的（返回 null），拿不到内部元素。**不能**据此判定"没在动"。
- `getBBox()` **不含元素自身与祖先的 transform**：实测 `<g transform="translate(200,100)"><g class=spin><rect x=0 y=-5 w=40 h=10/></g></g>` 的 `getBBox()` 仍是 `[0,-5,40,10]`——所以 bbox 既验不出轴心也验不出旋转，别用它做这道判据。
- **可行手法（注入式放大标记）**：往 `<svg>` 里 append 一条 `<style>`，把目标动画放慢（`.spokes{animation-duration:9s !important}`）并把组内一条**不对称**的 path 染成醒目色（`.spokes path:last-of-type{stroke:#e11d48 !important;stroke-width:7 !important}`），隔几秒两次截图对比：①标记是否始终距某圆心等距（验轴心）②角度是否变化（验在转）。实测该页红弧两次位置不同且始终距轮心 ≈51 → 动画在跑、轴心正确。对称图形（8 辐条有 45° 对称性）验不出角度，必须找组内唯一的不对称元素当标记。
